'use strict';

/**
 * 套用在「每一個網頁分頁」的 preload。
 * 不對網頁公開任何 API,只在使用者按下滑鼠 / 觸控時通知主程序:
 * 「我是被點到的那個分頁」,讓主程序把它設為使用中的分頁(網址列會跟著切換)。
 */
const { ipcRenderer } = require('electron');

function poke(event) {
  if (event && event.isTrusted === false) return; // 忽略網頁腳本偽造的事件
  ipcRenderer.send('tab:interact');
}

window.addEventListener('mousedown', poke, true);
window.addEventListener('touchstart', poke, { capture: true, passive: true });

'use strict';

// 新分頁頁面:時鐘、搜尋(支援 @g 之類的搜尋捷徑)、常用網站、自訂面板。
// 預設搜尋引擎若要更換,請與 main.js 的 SEARCH_URL 一起修改。
(function () {
  const ENGINES = {
    g:  { name: 'Google',      url: 'https://www.google.com/search?q=' },
    b:  { name: 'Bing',        url: 'https://www.bing.com/search?q=' },
    d:  { name: 'DuckDuckGo',  url: 'https://duckduckgo.com/?q=' },
    y:  { name: 'Yahoo!奇摩',   url: 'https://tw.search.yahoo.com/search?p=' },
    bd: { name: '百度',         url: 'https://www.baidu.com/s?wd=' },
    yt: { name: 'YouTube',     url: 'https://www.youtube.com/results?search_query=' },
    w:  { name: '維基百科',     url: 'https://zh.wikipedia.org/w/index.php?search=' },
    gh: { name: 'GitHub',      url: 'https://github.com/search?q=' },
  };
  const DEFAULT_ENGINE = 'g';

  const DEFAULTS = {
    name: 'Solov',
    sub: '我的起始頁',
    theme: 'aurora',
    tips: true,
    links: [
      { name: 'Google',   url: 'https://www.google.com/' },
      { name: 'YouTube',  url: 'https://www.youtube.com/' },
      { name: '維基百科',  url: 'https://zh.wikipedia.org/' },
      { name: 'GitHub',   url: 'https://github.com/' },
      { name: 'Reddit',   url: 'https://www.reddit.com/' },
      { name: 'Bing',     url: 'https://www.bing.com/' },
    ],
  };
  const THEMES = ['aurora', 'ocean', 'forest', 'rose', 'night'];
  const KEY = 'solov.newtab.v1';

  const $ = (id) => document.getElementById(id);
  const clone = (o) => JSON.parse(JSON.stringify(o));

  // ---------- 設定 ----------
  function load() {
    const cfg = clone(DEFAULTS);
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (raw && typeof raw === 'object') {
        if (typeof raw.name === 'string') cfg.name = raw.name;
        if (typeof raw.sub === 'string') cfg.sub = raw.sub;
        if (THEMES.includes(raw.theme)) cfg.theme = raw.theme;
        if (typeof raw.tips === 'boolean') cfg.tips = raw.tips;
        if (Array.isArray(raw.links)) {
          cfg.links = raw.links
            .filter((l) => l && typeof l.name === 'string' && typeof l.url === 'string' && /^https?:\/\//i.test(l.url))
            .slice(0, 12)
            .map((l) => ({ name: l.name, url: l.url }));
        }
      }
    } catch (_) { /* 沒有儲存空間時用預設值 */ }
    return cfg;
  }
  function save(cfg) {
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (_) { /* 忽略 */ }
  }
  let cfg = load();

  // ---------- 時鐘 ----------
  let lastMinute = '';
  function tick() {
    const d = new Date();
    const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    if (hm === lastMinute) return;
    lastMinute = hm;
    $('clock').textContent = hm;
    $('date').textContent = (d.getMonth() + 1) + '月' + d.getDate() + '日 星期' + '日一二三四五六'[d.getDay()];
  }
  tick();
  setInterval(tick, 1000);

  // ---------- 畫面 ----------
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch (_) { return url; }
  }
  function render() {
    document.body.dataset.theme = cfg.theme;
    $('greet').textContent = cfg.name.trim() ? 'Hi ' + cfg.name.trim() : 'Hi';
    $('sub').textContent = cfg.sub;
    $('sub').style.display = cfg.sub.trim() ? '' : 'none';
    $('tips').style.display = cfg.tips ? '' : 'none';

    const ul = $('links');
    ul.textContent = '';
    for (const l of cfg.links) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.className = 'glass';
      a.href = l.url;
      const ico = document.createElement('span');
      ico.className = 'ico';
      ico.textContent = (Array.from(l.name.trim())[0] || '?').toUpperCase();
      const txt = document.createElement('span');
      txt.className = 'txt';
      const b = document.createElement('b');
      b.textContent = l.name;
      const s = document.createElement('small');
      s.textContent = hostOf(l.url);
      txt.append(b, s);
      a.append(ico, txt);
      li.append(a);
      ul.append(li);
    }
  }

  // 搜尋捷徑提示
  function buildChips() {
    const ul = $('chips');
    for (const key of Object.keys(ENGINES)) {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'glass';
      btn.textContent = '@' + key + ' ' + ENGINES[key].name;
      btn.addEventListener('click', () => {
        const q = $('q');
        q.value = '@' + key + ' ';
        q.focus();
        updatePlaceholder();
      });
      li.append(btn);
      ul.append(li);
    }
  }
  buildChips();

  // ---------- 搜尋 ----------
  function parseShortcut(s) {
    const m = /^@([a-z]+)(?:\s+(.*))?$/i.exec(s.trim());
    if (!m) return null;
    const key = m[1].toLowerCase();
    return ENGINES[key] ? { key, engine: ENGINES[key], text: (m[2] || '').trim() } : null;
  }

  function updatePlaceholder() {
    const sc = parseShortcut($('q').value);
    $('q').placeholder = sc && $('q').value.trim() ? '用 ' + sc.engine.name + ' 搜尋' : '用 Google 搜尋,或輸入網址';
  }

  function toUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return null;
    const sc = parseShortcut(s);
    if (sc) {
      if (sc.text) return sc.engine.url + encodeURIComponent(sc.text);
      return new URL(sc.engine.url).origin + '/';
    }
    if (/^(https?|file|about|data|view-source):/i.test(s)) return s;
    if (!/\s/.test(s)) {
      if (/^localhost(:\d{1,5})?([/?#].*)?$/i.test(s)) return 'http://' + s;
      if (/^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?([/?#].*)?$/.test(s)) return 'http://' + s;
      if (/^([a-z0-9¡-￿-]+\.)+[a-z¡-￿]{2,}(:\d{1,5})?([/?#].*)?$/i.test(s)) {
        return 'https://' + s;
      }
    }
    return ENGINES[DEFAULT_ENGINE].url + encodeURIComponent(s);
  }

  $('q').addEventListener('input', updatePlaceholder);
  $('search').addEventListener('submit', (e) => {
    e.preventDefault();
    const url = toUrl($('q').value);
    if (url) location.href = url;
  });

  // ---------- 自訂面板 ----------
  function addRow(l) {
    const row = document.createElement('div');
    row.className = 'row';
    const n = document.createElement('input');
    n.type = 'text'; n.placeholder = '名稱'; n.maxLength = 20; n.value = l.name;
    const u = document.createElement('input');
    u.type = 'text'; u.placeholder = 'https://example.com'; u.value = l.url;
    const del = document.createElement('button');
    del.type = 'button'; del.className = 'btn small'; del.textContent = '刪除';
    del.addEventListener('click', () => row.remove());
    row.append(n, u, del);
    $('c-links').append(row);
  }
  function fillPanel(c) {
    $('c-name').value = c.name;
    $('c-sub').value = c.sub;
    $('c-theme').value = c.theme;
    $('c-tips').checked = c.tips;
    $('c-links').textContent = '';
    c.links.forEach(addRow);
  }
  function openPanel() { fillPanel(cfg); $('overlay').classList.add('open'); $('c-name').focus(); }
  function closePanel() { $('overlay').classList.remove('open'); }

  function normalizeUrl(s) {
    s = s.trim();
    if (!s) return null;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'https://' + s;
    try {
      const u = new URL(s);
      return /^https?:$/.test(u.protocol) ? u.href : null;
    } catch (_) { return null; }
  }

  $('customize').addEventListener('click', openPanel);
  $('c-cancel').addEventListener('click', closePanel);
  $('overlay').addEventListener('mousedown', (e) => { if (e.target === $('overlay')) closePanel(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });
  $('c-add').addEventListener('click', () => {
    if ($('c-links').children.length >= 12) return;
    addRow({ name: '', url: '' });
    $('c-links').lastChild.firstChild.focus();
  });
  $('c-reset').addEventListener('click', () => fillPanel(DEFAULTS));
  $('c-save').addEventListener('click', () => {
    const links = [];
    for (const row of $('c-links').children) {
      const [n, u] = row.querySelectorAll('input');
      const url = normalizeUrl(u.value);
      if (!url) continue;
      links.push({ name: n.value.trim() || hostOf(url), url });
    }
    cfg = {
      name: $('c-name').value,
      sub: $('c-sub').value,
      theme: $('c-theme').value,
      tips: $('c-tips').checked,
      links,
    };
    save(cfg);
    render();
    closePanel();
  });

  render();
  $('q').focus();
})();

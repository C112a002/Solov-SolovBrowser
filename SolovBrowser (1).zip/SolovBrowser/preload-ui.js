'use strict';

/**
 * 瀏覽器介面(分頁列、工具列、擴充功能面板)用的 preload。
 * 只公開白名單內的操作,不把 ipcRenderer 整個交給頁面。
 */
const { contextBridge, ipcRenderer } = require('electron');

const send = (channel, ...args) => ipcRenderer.send(channel, ...args);
const listen = (channel, cb) => {
  ipcRenderer.on(channel, (_event, payload) => cb(payload));
};

contextBridge.exposeInMainWorld('mv', {
  // 初始化與主程序推送
  ready: () => ipcRenderer.invoke('ui:ready'),
  onState: (cb) => listen('state', cb),
  onScripts: (cb) => listen('scripts', cb),
  onFocusAddress: (cb) => listen('focus-address', () => cb()),
  onNote: (cb) => listen('note', cb),

  // 分頁
  newTab: () => send('tab:new'),
  closeTab: (id) => send('tab:close', id),
  activateTab: (id, toggle) => send('tab:activate', id, !!toggle),
  toggleShown: (id) => send('tab:toggle-shown', id),
  tabMenu: (id) => send('tab:menu', id),
  muteTab: (id) => send('tab:mute', id),
  autoRefresh: (id, sec) => send('tab:auto-refresh', id, Number(sec) || 0),
  maximize: (id) => send('view:maximize', typeof id === 'number' ? id : null),

  // 導覽
  go: (text) => send('nav:go', String(text == null ? '' : text)),
  back: () => send('nav:back'),
  forward: () => send('nav:forward'),
  reload: () => send('nav:reload'),
  stop: () => send('nav:stop'),

  // 版面 / 面板
  setLayout: (layout) => send('layout:set', layout),
  setPanel: (open) => send('panel:set', !!open),

  // 擴充功能(使用者腳本)
  scripts: {
    save: (script) => ipcRenderer.invoke('scripts:save', script),
    remove: (id) => send('scripts:remove', id),
    toggle: (id, enabled) => send('scripts:toggle', id, !!enabled),
    run: (id) => send('scripts:run', id),
    importFiles: () => send('scripts:import'),
    reloadShown: () => send('tabs:reload-shown'),
  },
});

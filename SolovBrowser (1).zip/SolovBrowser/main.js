'use strict';

/**
 * Solov Browser — 主程序
 *
 * 每個分頁都是一個獨立的 WebContentsView(原生檢視,不是 iframe / <webview>),
 * 直接疊在視窗上,所以同一個畫面可以真正同時顯示多個分頁。
 * 分頁列、工具列、方塊標題列、擴充功能面板則畫在視窗本身的 UI 頁面(renderer/)。
 */

const {
  app, BrowserWindow, WebContentsView, ipcMain, Menu, session, shell, dialog, clipboard, nativeTheme,
} = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

const { computeLayout, METRICS } = require('./lib/layout');
const { normalizeInput, isNewTabUrl, isRunnableUrl } = require('./lib/urlutil');
const { wrapUserCode, ERR_PREFIX } = require('./lib/scriptwrap');
const { matchesUrl, parseUserscriptHeader } = require('./lib/match');

/* ───────────────────────── 可自行調整的設定 ───────────────────────── */
const APP_TITLE = 'Solov Browser';
const SEARCH_URL = 'https://www.google.com/search?q='; // 位址列輸入的不是網址時,用這個搜尋
const MAX_RESTORE_TABS = 40;
const BG_IMAGE_EXTS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.avif', '.bmp', '.svg'];
const BG_VIDEO_EXTS = ['.mp4', '.webm', '.m4v', '.ogv', '.mov'];
const BG_MAX_BYTES = 500 * 1024 * 1024; // 背景檔案大小上限

/* ───────────────────────── 版面常數(會一併傳給 UI) ───────────────────────── */
const TAB_H = 38;                 // 分頁列高度
const BAR_H = 44;                 // 工具列(網址列)高度
const CHROME_H = TAB_H + BAR_H;   // 網頁區域從這個高度開始
const PANEL_W = 420;              // 擴充功能面板寬度

const LAYOUTS = ['single', 'grid', 'cols', 'rows'];
const REFRESH_CHOICES = [10, 30, 60, 300, 900]; // 自動重新整理可選的秒數
const NEWTAB_FILE = path.join(__dirname, 'renderer', 'newtab.html');
const INDEX_FILE = path.join(__dirname, 'renderer', 'index.html');
const PRELOAD_UI = path.join(__dirname, 'preload-ui.js');
const PRELOAD_TAB = path.join(__dirname, 'preload-tab.js');
const ICON_FILE = path.join(__dirname, 'assets', 'icon.png');

const DEMO_SCRIPT = {
  id: 'demo-badge',
  name: '範例:在每個分頁右下角顯示網域標籤',
  enabled: false,
  code:
    '// 範例腳本:啟用後,畫面上每個分頁的右下角都會出現一個標籤。\n' +
    '// 這段程式可以重複執行,不會產生重複的標籤。\n' +
    "const ID = '__multiview_demo_badge';\n" +
    'document.getElementById(ID)?.remove();\n' +
    "const badge = document.createElement('div');\n" +
    'badge.id = ID;\n' +
    "badge.textContent = '✔ ' + location.hostname;\n" +
    "badge.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:2147483647;padding:6px 10px;" +
    "border-radius:8px;background:#0b7f8c;color:#fff;font:600 13px system-ui,sans-serif;" +
    "box-shadow:0 2px 8px rgba(0,0,0,.35);pointer-events:none';\n" +
    'document.documentElement.appendChild(badge);\n',
};

/* ───────────────────────── 狀態 ───────────────────────── */
let win = null;
let tabs = [];            // 依分頁列順序
let nextTabId = 1;
let activeId = null;
let layout = 'grid';      // single | grid | cols | rows
let panelOpen = false;
let maximized = false;    // 暫時只顯示使用中的分頁(放大單一方塊),配置本身不變
let audioTimer = null;    // 定時檢查各分頁是否正在發出聲音
let scripts = [];         // { id, name, code, enabled, rev, status }
let lastTiles = [];       // 傳給 UI 畫方塊外框 / 標題列用
let config = {};
let closedTabs = [];      // 供「重新開啟已關閉的分頁」
let CONFIG_FILE = '';
let SCRIPTS_FILE = '';
let BG_DIR = '';   // 起始頁自訂背景(圖片 / 影片)存放的資料夾

process.on('uncaughtException', (err) => console.error('[uncaughtException]', err));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));

/* ───────────────────────── 小工具 ───────────────────────── */
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const alive = (w) => !!w && !w.isDestroyed();
const uiAlive = () => alive(win) && alive(win.webContents);

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function writeJson(file, data) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  } catch (err) {
    console.error('[save]', err.message);
  }
}

function copyText(text) {
  try {
    // Electron 44 起 clipboard 的寫入變成非同步;包一層 Promise 讓新舊版本都能用
    Promise.resolve(clipboard.writeText(String(text))).catch(() => {});
  } catch (_) { /* ignore */ }
}

function buildUserAgent() {
  const major = String(process.versions.chrome || '140').split('.')[0];
  let platform = 'X11; Linux x86_64';
  if (process.platform === 'win32') platform = 'Windows NT 10.0; Win64; x64';
  else if (process.platform === 'darwin') platform = 'Macintosh; Intel Mac OS X 10_15_7';
  // 拿掉預設 UA 裡的 "Electron/x.y.z" 與應用程式名稱,讓網站把它當成一般 Chrome
  return `Mozilla/5.0 (${platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Safari/537.36`;
}

/* ───────────────────────── 設定檔 ───────────────────────── */
let saveTimer = null;

function saveConfigSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveConfig, 600);
}

function saveConfig() {
  clearTimeout(saveTimer);
  saveTimer = null;
  if (!alive(win) || !CONFIG_FILE) return;
  const b = win.getNormalBounds();
  // 只存「下次開啟能還原」的分頁(新分頁頁面與 http/https/file),「使用中」的索引也以過濾後的清單為準
  const keep = tabs.filter((t) => t.internal || !t.url || /^(https?|file):/i.test(t.url));
  config = {
    layout,
    window: { width: b.width, height: b.height, maximized: win.isMaximized() },
    tabs: keep.map((t) => ({ url: t.internal ? '' : t.url, shown: t.shown, refresh: t.refreshSec || 0 })),
    active: Math.max(0, keep.findIndex((t) => t.id === activeId)),
  };
  writeJson(CONFIG_FILE, config);
}

function persistScripts() {
  if (!SCRIPTS_FILE) return;
  writeJson(SCRIPTS_FILE, scripts.map((s) => ({
    id: s.id, name: s.name, code: s.code, enabled: s.enabled, match: s.match,
  })));
}

/* ───────────────────────── 權限(相機 / 麥克風 / 定位…) ───────────────────────── */
const PERMISSION_ALLOW = new Set(['fullscreen', 'pointerLock', 'keyboardLock', 'clipboard-sanitized-write']);
const PERMISSION_ASK = {
  media: '使用你的攝影機或麥克風',
  geolocation: '取得你的位置',
  notifications: '傳送通知給你',
  'clipboard-read': '讀取你的剪貼簿',
  'display-capture': '擷取你的螢幕畫面',
};
const permissionMemory = new Map(); // "host|permission" → boolean(只在本次執行期間記住)
const permissionPending = new Map();

function showBox(options) {
  return alive(win) ? dialog.showMessageBox(win, options) : dialog.showMessageBox(options);
}

function hostOf(url) {
  try {
    return new URL(url).host || '';
  } catch (_) {
    return '';
  }
}

function setupPermissions(ses) {
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    if (PERMISSION_ALLOW.has(permission)) return callback(true);
    const what = PERMISSION_ASK[permission];
    if (!what) return callback(false);

    const host = hostOf((details && details.requestingUrl) || (wc && wc.getURL()) || '') || '此網站';
    const key = `${host}|${permission}`;
    if (permissionMemory.has(key)) return callback(permissionMemory.get(key));

    let pending = permissionPending.get(key);
    if (!pending) {
      pending = showBox({
        type: 'question',
        buttons: ['允許', '封鎖'],
        defaultId: 1,
        cancelId: 1,
        noLink: true,
        title: '網站權限要求',
        message: `${host} 想要${what}`,
      })
        .then((r) => r.response === 0)
        .catch(() => false)
        .finally(() => permissionPending.delete(key));
      permissionPending.set(key, pending);
    }
    pending.then((allowed) => {
      permissionMemory.set(key, allowed);
      callback(allowed);
    });
    return undefined;
  });

  ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
    if (PERMISSION_ALLOW.has(permission)) return true;
    return permissionMemory.get(`${hostOf(requestingOrigin)}|${permission}`) === true;
  });
}

/* ───────────────────────── 使用者腳本引擎 ───────────────────────── */
const freshStatus = () => ({ runs: 0, errors: 0, lastAt: 0, lastOk: null, lastError: '', lastTab: '' });

function hydrateScript(s) {
  return {
    id: String(s.id || crypto.randomUUID()),
    name: String(s.name || '未命名腳本').slice(0, 120),
    code: String(s.code == null ? '' : s.code).slice(0, 1000000),
    enabled: !!s.enabled,
    match: String(s.match == null ? '' : s.match).trim().slice(0, 2000), // 網址限定規則;空白 = 所有分頁
    rev: 1,                 // 程式碼或網址限定改變 / 重新啟用時 +1,代表「需要重新套用」
    status: freshStatus(),
  };
}

function publicScripts() {
  return scripts.map((s) => ({
    id: s.id, name: s.name, code: s.code, enabled: s.enabled, match: s.match, status: s.status,
  }));
}

let scriptsTimer = null;
function sendScripts(immediate = false) {
  if (!uiAlive()) return;
  const push = () => {
    scriptsTimer = null;
    if (uiAlive()) win.webContents.send('scripts', publicScripts());
  };
  if (immediate) {
    clearTimeout(scriptsTimer);
    push();
  } else if (!scriptsTimer) {
    scriptsTimer = setTimeout(push, 120);
  }
}

function note(text) {
  if (uiAlive()) win.webContents.send('note', String(text));
}

/** 在單一分頁執行單一腳本;不會拋出例外 */
async function execOnTab(tab, script) {
  const result = { ok: false, skipped: false, error: '' };
  const wc = tab.wc;
  const url = alive(wc) ? wc.getURL() : '';
  if (!alive(wc) || !tab.domReady || !isRunnableUrl(url) || !matchesUrl(script.match, url)) {
    result.skipped = true; // 還沒載入完成、不是一般網頁,或不符合這個腳本的網址限定
    return result;
  }
  try {
    const ret = await wc.executeJavaScript(wrapUserCode(script.code), false);
    if (typeof ret === 'string' && ret.startsWith(ERR_PREFIX)) {
      result.error = ret.slice(ERR_PREFIX.length).split('\n')[0] || '腳本執行時發生錯誤';
    } else {
      result.ok = true;
    }
  } catch (err) {
    result.error = String((err && err.message) || err).split('\n')[0];
  }
  return result;
}

function record(script, tab, res) {
  if (res.skipped) return;
  const st = script.status;
  st.runs += 1;
  st.lastAt = Date.now();
  st.lastOk = res.ok;
  if (!res.ok) {
    st.errors += 1;
    st.lastError = res.error;
    st.lastTab = tab.title || tab.url || '';
  }
  sendScripts();
}

/** 只套用「已啟用、而且這次載入還沒套用過目前版本」的腳本 */
function applyScripts(tab) {
  if (!alive(tab.wc) || !tab.domReady) return;
  for (const s of scripts) {
    if (!s.enabled || tab.applied.get(s.id) === s.rev) continue;
    tab.applied.set(s.id, s.rev);
    execOnTab(tab, s).then((res) => record(s, tab, res));
  }
}

function applyScriptsToDisplayed() {
  if (!scripts.some((s) => s.enabled)) return;
  for (const tab of displayedTabs()) applyScripts(tab);
}

/** 手動「立即執行」:忽略已套用紀錄,對畫面上所有顯示中的分頁各跑一次 */
function runScriptNow(script) {
  script.status = freshStatus();
  const jobs = displayedTabs().map((tab) => {
    tab.applied.set(script.id, script.rev);
    return execOnTab(tab, script).then((res) => {
      record(script, tab, res);
      return res;
    });
  });
  sendScripts(true);
  Promise.all(jobs).then((results) => {
    if (!results.some((r) => !r.skipped)) {
      note(script.match
        ? '畫面上沒有符合這個腳本網址限定、且已載入完成的分頁。'
        : '畫面上沒有已載入完成的網頁分頁可以執行。');
    }
  });
}

/* ───────────────────────── 分頁 ───────────────────────── */
function getTab(id) {
  return tabs.find((t) => t.id === id) || null;
}

function tabByWebContentsId(id) {
  return tabs.find((t) => alive(t.wc) && t.wc.id === id) || null;
}

function shownCount() {
  return tabs.filter((t) => t.shown).length;
}

/** 目前畫面上實際顯示的分頁(依分頁列順序) */
function displayedTabs() {
  const act = getTab(activeId);
  if (!act) return [];
  if (layout === 'single' || maximized) return [act];
  return tabs.filter((t) => t.shown);
}

function isDisplayed(tab) {
  return displayedTabs().includes(tab);
}

function navCan(wc, dir) {
  try {
    const nh = wc.navigationHistory;
    if (nh) return dir === 'back' ? nh.canGoBack() : nh.canGoForward();
    return dir === 'back' ? wc.canGoBack() : wc.canGoForward();
  } catch (_) {
    return false;
  }
}

function navGo(wc, dir) {
  try {
    const nh = wc.navigationHistory;
    if (nh) {
      if (dir === 'back') nh.goBack(); else nh.goForward();
    } else if (dir === 'back') wc.goBack();
    else wc.goForward();
  } catch (_) { /* ignore */ }
}

function syncMeta(tab) {
  const wc = tab.wc;
  if (!alive(wc)) return;
  tab.url = wc.getURL();
  tab.internal = isNewTabUrl(tab.url);
  tab.canGoBack = navCan(wc, 'back');
  tab.canGoForward = navCan(wc, 'forward');
  tab.loading = wc.isLoading();
}

function ensureInvariants() {
  if (!tabs.length) {
    activeId = null;
    return;
  }
  let act = getTab(activeId);
  if (!act) {
    act = tabs[0];
    activeId = act.id;
  }
  act.shown = true; // 使用中的分頁一定會顯示
  if (maximized && (layout === 'single' || shownCount() < 2)) maximized = false; // 只剩一個:沒有東西可以還原了
}

function focusAddress() {
  if (!uiAlive()) return;
  win.webContents.focus();
  win.webContents.send('focus-address');
}

function createTab(target, opts = {}) {
  const { activate = true, afterId = null, shown = true, focus = true } = opts;

  const view = new WebContentsView({
    webPreferences: {
      preload: PRELOAD_TAB,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  const wc = view.webContents;
  const tab = {
    id: nextTabId++,
    view,
    wc,
    title: '',
    url: '',
    favicon: '',
    loading: false,
    canGoBack: false,
    canGoForward: false,
    shown,
    internal: false,
    domReady: false,
    applied: new Map(),
    fullscreen: false,
    audible: false,       // 正在發出聲音
    muted: false,         // 已被靜音
    refreshSec: 0,        // 自動重新整理間隔(秒),0 = 關閉
    refreshTimer: null,
  };

  let at = tabs.length;
  if (afterId != null) {
    const i = tabs.findIndex((t) => t.id === afterId);
    if (i >= 0) at = i + 1;
  }
  tabs.splice(at, 0, tab);

  win.contentView.addChildView(view);
  view.setVisible(false);
  wireTab(tab);

  const blank = !target;
  if (blank) wc.loadFile(NEWTAB_FILE).catch(() => {});
  else wc.loadURL(target).catch(() => {});
  syncMeta(tab); // 立刻帶入「待載入」的網址,位址列不用等頁面提交導覽才更新

  if (activate || activeId == null) setActive(tab.id, { force: true });
  else relayout();

  if (activate && blank) focusAddress();
  else if (activate && focus) wc.focus();
  return tab;
}

function setActive(id, opts = {}) {
  const tab = getTab(id);
  if (!tab) return;
  const same = activeId === id && tab.shown;
  activeId = id;
  tab.shown = true;
  if (!same || opts.force) relayout();
  if (opts.focus && alive(tab.wc)) tab.wc.focus();
}

/** 使用者直接點到網頁內容時(由 preload / focus 事件觸發) */
function activateByPage(tab) {
  if (!tabs.includes(tab)) return;
  if (activeId === tab.id && tab.shown) return;
  setActive(tab.id);
}

/** 從 rightStart 往右、leftStart 往左,依距離交錯找出最近的「顯示中」分頁 */
function nearestShown(rightStart, leftStart) {
  for (let d = 0; d < tabs.length; d++) {
    const r = tabs[rightStart + d];
    if (r && r.shown) return r;
    const l = tabs[leftStart - d];
    if (l && l.shown) return l;
  }
  return null;
}

function closeTab(id) {
  const index = tabs.findIndex((t) => t.id === id);
  if (index < 0) return;
  const tab = tabs[index];

  if (!tab.internal && tab.url) {
    closedTabs.push({ url: tab.url, shown: tab.shown });
    if (closedTabs.length > 20) closedTabs.shift();
  }

  tabs.splice(index, 1);
  clearInterval(tab.refreshTimer);
  if (tab.fullscreen && alive(win) && win.isFullScreen()) win.setFullScreen(false);
  try {
    win.contentView.removeChildView(tab.view);
  } catch (_) { /* ignore */ }
  if (alive(tab.wc)) {
    try {
      tab.wc.close();
    } catch (_) { /* ignore */ }
  }

  if (!tabs.length) {
    activeId = null;
    createTab(null);
    return;
  }
  if (activeId === id) {
    // 關掉後,tabs[index] 就是原本右邊的鄰居:優先右邊,其次左邊
    const next = nearestShown(index, index - 1) || tabs[Math.min(index, tabs.length - 1)];
    activeId = next.id;
    next.shown = true;
    relayout();
    if (alive(next.wc)) next.wc.focus();
  } else {
    relayout();
  }
}

function reopenClosedTab() {
  const last = closedTabs.pop();
  if (last) createTab(last.url, { shown: last.shown });
}

function toggleShown(id) {
  const tab = getTab(id);
  if (!tab) return;
  if (tab.shown) {
    if (shownCount() <= 1) return; // 至少要留一個
    tab.shown = false;
    if (activeId === id) {
      const pos = tabs.indexOf(tab);
      const next = nearestShown(pos + 1, pos - 1) || tabs.find((t) => t.shown);
      if (next) activeId = next.id;
    }
  } else {
    tab.shown = true;
  }
  relayout();
}

function cycleTab(dir) {
  let pool = layout === 'single' ? tabs : displayedTabs();
  if (pool.length < 2) pool = tabs;
  if (pool.length < 2) return;
  const i = pool.findIndex((t) => t.id === activeId);
  const next = pool[(i + dir + pool.length) % pool.length];
  setActive(next.id, { focus: true });
}

function gotoTabNumber(n) {
  if (!tabs.length) return;
  const target = n >= 9 ? tabs[tabs.length - 1] : tabs[n - 1];
  if (target) setActive(target.id, { focus: true });
}

function navigateActive(text) {
  const tab = getTab(activeId);
  if (!tab || !alive(tab.wc)) return;
  const target = normalizeInput(text, SEARCH_URL);
  if (!target) return;
  tab.wc.loadURL(target).catch(() => {});
  syncMeta(tab); // 位址列馬上顯示輸入的網址,不會先閃回舊網址
  scheduleState(true);
  tab.wc.focus();
}

function zoomActive(delta) {
  const tab = getTab(activeId);
  if (!tab || !alive(tab.wc)) return;
  const wc = tab.wc;
  wc.setZoomLevel(delta === 0 ? 0 : clamp(wc.getZoomLevel() + delta, -5, 5));
}

function toggleDevTools(tab) {
  if (!tab || !alive(tab.wc)) return;
  if (tab.wc.isDevToolsOpened()) tab.wc.closeDevTools();
  else tab.wc.openDevTools({ mode: 'detach' });
}

function setLayout(next) {
  if (!LAYOUTS.includes(next)) return;
  if (next === layout && !maximized) return;
  layout = next;
  maximized = false; // 明確選了配置 → 離開「放大」
  relayout();
}

/** 放大 / 還原:暫時只顯示使用中的分頁(滿版),再按一次回到原本的並排 */
function toggleMaximize(force) {
  const next = typeof force === 'boolean' ? force : !maximized;
  if (next === maximized) return;
  if (next && (layout === 'single' || shownCount() < 2)) return; // 沒有東西可以放大
  maximized = next;
  relayout();
}

/* ───────────────────────── 聲音:靜音與播放指示 ───────────────────────── */
function readAudio(tab) {
  const wc = tab.wc;
  if (!alive(wc)) return false;
  let audible = false;
  let muted = false;
  try {
    audible = !!wc.isCurrentlyAudible();
    muted = !!wc.isAudioMuted();
  } catch (_) { /* ignore */ }
  const changed = audible !== tab.audible || muted !== tab.muted;
  tab.audible = audible;
  tab.muted = muted;
  return changed;
}

function pollAudio() {
  let changed = false;
  for (const tab of tabs) if (readAudio(tab)) changed = true;
  if (changed) scheduleState();
}

function toggleMute(id) {
  const tab = getTab(id);
  if (!tab || !alive(tab.wc)) return;
  tab.wc.setAudioMuted(!tab.wc.isAudioMuted());
  readAudio(tab);
  scheduleState(true);
}

/** 只讓這個分頁出聲,其他分頁全部靜音 */
function soloAudio(id) {
  for (const t of tabs) {
    if (!alive(t.wc)) continue;
    t.wc.setAudioMuted(t.id !== id);
    readAudio(t);
  }
  scheduleState(true);
}

function unmuteAll() {
  for (const t of tabs) {
    if (!alive(t.wc)) continue;
    t.wc.setAudioMuted(false);
    readAudio(t);
  }
  scheduleState(true);
}

/* ───────────────────────── 自動重新整理 ───────────────────────── */
const refreshText = (sec) => (sec < 60 ? `${sec} 秒` : `${sec / 60} 分鐘`);

function setAutoRefresh(id, sec) {
  const tab = getTab(id);
  if (!tab) return;
  clearInterval(tab.refreshTimer);
  tab.refreshTimer = null;
  tab.refreshSec = REFRESH_CHOICES.includes(sec) ? sec : 0;
  if (tab.refreshSec) {
    tab.refreshTimer = setInterval(() => tickRefresh(tab), tab.refreshSec * 1000);
    if (tab.refreshTimer.unref) tab.refreshTimer.unref();
  }
  scheduleState(true);
}

/** 時間到:只重新整理「畫面上顯示中、沒在載入、不是全螢幕」的分頁(收起來的分頁不浪費流量) */
function tickRefresh(tab) {
  if (!tabs.includes(tab) || !alive(tab.wc)) {
    clearInterval(tab.refreshTimer);
    return;
  }
  if (tab.internal || tab.fullscreen || tab.wc.isLoading() || !isDisplayed(tab)) return;
  if (alive(win) && win.isMinimized()) return;
  tab.wc.reload();
}

function setPanel(open) {
  if (panelOpen === open) return;
  panelOpen = open;
  relayout();
}

/* ───────────────────────── 版面 / 狀態推送 ───────────────────────── */
function relayout() {
  if (!alive(win)) return;
  ensureInvariants();

  const [W, H] = win.getContentSize();
  const fsTab = tabs.find((t) => t.fullscreen);

  if (fsTab) {
    // 網頁進入 HTML 全螢幕(例如影片):該分頁鋪滿整個視窗,其餘隱藏
    for (const t of tabs) {
      if (t === fsTab) {
        t.view.setBounds({ x: 0, y: 0, width: W, height: H });
        t.view.setVisible(true);
      } else {
        t.view.setVisible(false);
      }
    }
    lastTiles = [];
  } else {
    const displayed = displayedTabs();
    const lay = computeLayout({
      width: W,
      height: H,
      chromeH: CHROME_H,
      panelW: panelOpen ? PANEL_W : 0,
      count: displayed.length,
      layout,
    });
    const visible = new Set();
    displayed.forEach((t, i) => {
      const r = lay.tiles[i].view;
      t.view.setBounds({ x: r.x, y: r.y, width: r.w, height: r.h });
      t.view.setVisible(true);
      visible.add(t.id);
    });
    for (const t of tabs) if (!visible.has(t.id)) t.view.setVisible(false);

    lastTiles = lay.split
      ? lay.tiles.map((tile, i) => ({
        id: displayed[i].id,
        x: tile.outer.x,
        y: tile.outer.y,
        w: tile.outer.w,
        h: tile.outer.h,
      }))
      : [];
  }

  applyScriptsToDisplayed();
  scheduleState(true);
}

function buildState() {
  return {
    tabs: tabs.map((t) => ({
      id: t.id,
      title: t.title,
      url: t.internal ? '' : t.url,
      favicon: t.favicon,
      loading: t.loading,
      shown: t.shown,
      internal: t.internal,
      canGoBack: t.canGoBack,
      canGoForward: t.canGoForward,
      audible: t.audible,
      muted: t.muted,
      refreshSec: t.refreshSec,
    })),
    activeId,
    layout,
    maximized,
    panelOpen,
    tiles: lastTiles,
    displayedCount: displayedTabs().length,
    metrics: {
      tabH: TAB_H,
      barH: BAR_H,
      chromeH: CHROME_H,
      panelW: PANEL_W,
      headH: METRICS.HEAD_H,
      frame: METRICS.FRAME,
    },
  };
}

let stateTimer = null;
function scheduleState(immediate = false) {
  if (!uiAlive()) return;
  if (immediate) {
    clearTimeout(stateTimer);
    stateTimer = null;
    sendState();
  } else if (!stateTimer) {
    stateTimer = setTimeout(() => {
      stateTimer = null;
      sendState();
    }, 40);
  }
}

function sendState() {
  if (!uiAlive()) return;
  win.webContents.send('state', buildState());
  const act = getTab(activeId);
  win.setTitle(act && act.title ? `${act.title} - ${APP_TITLE}` : APP_TITLE);
  saveConfigSoon();
}

/* ───────────────────────── 快速鍵 / 選單 ───────────────────────── */
function handleShortcut(event, input) {
  if (input.type !== 'keyDown') return;
  const ctrl = input.control || input.meta;
  const key = String(input.key || '').toLowerCase();
  const stop = () => event.preventDefault();
  const act = getTab(activeId);

  if (ctrl && !input.alt) {
    if (key === 't' && !input.shift) { stop(); createTab(null); return; }
    if (key === 't' && input.shift) { stop(); reopenClosedTab(); return; }
    if (key === 'w' || key === 'f4') { stop(); if (act) closeTab(act.id); return; }
    if (key === 'tab') { stop(); cycleTab(input.shift ? -1 : 1); return; }
    if (key === 'pagedown') { stop(); cycleTab(1); return; }
    if (key === 'pageup') { stop(); cycleTab(-1); return; }
    if (key === 'l') { stop(); focusAddress(); return; }
    if (key === 'r' || key === 'f5') {
      stop();
      if (act && alive(act.wc)) (input.shift || key === 'f5' ? act.wc.reloadIgnoringCache() : act.wc.reload());
      return;
    }
    if (key === '=' || key === '+') { stop(); zoomActive(0.5); return; }
    if (key === '-' || key === '_') { stop(); zoomActive(-0.5); return; }
    if (key === '0') { stop(); zoomActive(0); return; }
    if (/^[1-9]$/.test(key)) { stop(); gotoTabNumber(Number(key)); return; }
    if (input.shift && key === 'x') { stop(); setPanel(!panelOpen); return; }
    if (input.shift && key === 'i') { stop(); toggleDevTools(act); return; }
    if (input.shift && key === 'g') {
      stop();
      setLayout(LAYOUTS[(LAYOUTS.indexOf(layout) + 1) % LAYOUTS.length]);
      return;
    }
    if (input.shift && key === 'enter') { stop(); toggleMaximize(); return; }
    return;
  }

  if (input.alt && !ctrl) {
    if (key === 'arrowleft') { stop(); if (act) navGo(act.wc, 'back'); return; }
    if (key === 'arrowright') { stop(); if (act) navGo(act.wc, 'forward'); return; }
    if (key === 'd') { stop(); focusAddress(); return; }
    return;
  }

  if (key === 'f5') { stop(); if (act && alive(act.wc)) act.wc.reload(); return; }
  if (key === 'f6') { stop(); focusAddress(); return; }
  if (key === 'f12') { stop(); toggleDevTools(act); return; }
  if (key === 'f11') { stop(); if (alive(win)) win.setFullScreen(!win.isFullScreen()); }
}

function setupMenu() {
  if (process.platform === 'darwin') {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' },
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }
}

function showTabMenu(id) {
  const tab = getTab(id);
  if (!tab) return;
  const index = tabs.indexOf(tab);
  const split = layout !== 'single';
  const tpl = [];

  if (split) {
    tpl.push({
      label: tab.shown ? '從畫面隱藏這個分頁' : '顯示在畫面上',
      enabled: !tab.shown || shownCount() > 1,
      click: () => toggleShown(id),
    });
    tpl.push({
      label: '只顯示這個分頁',
      enabled: shownCount() > 1 || !tab.shown,
      click: () => {
        tabs.forEach((t) => { t.shown = t === tab; });
        activeId = id;
        relayout();
      },
    });
    tpl.push({
      label: '顯示所有分頁',
      enabled: shownCount() < tabs.length,
      click: () => {
        tabs.forEach((t) => { t.shown = true; });
        relayout();
      },
    });
    tpl.push({
      label: maximized ? '還原並排顯示' : '放大這個分頁',
      enabled: maximized || shownCount() + (tab.shown ? 0 : 1) >= 2,
      click: () => {
        if (maximized) {
          toggleMaximize(false);
        } else {
          setActive(id);
          toggleMaximize(true);
        }
      },
    });
    tpl.push({ type: 'separator' });
  }
  tpl.push(
    { label: tab.muted ? '取消靜音' : '靜音這個分頁', click: () => toggleMute(id) },
    { label: '只播放這個分頁的聲音', enabled: tabs.length > 1, click: () => soloAudio(id) },
    { label: '取消所有分頁的靜音', enabled: tabs.some((t) => t.muted), click: () => unmuteAll() },
    {
      label: '自動重新整理',
      enabled: !tab.internal,
      submenu: [
        { label: '關閉', type: 'radio', checked: !tab.refreshSec, click: () => setAutoRefresh(id, 0) },
        ...REFRESH_CHOICES.map((sec) => ({
          label: `每 ${refreshText(sec)}`,
          type: 'radio',
          checked: tab.refreshSec === sec,
          click: () => setAutoRefresh(id, sec),
        })),
      ],
    },
    { type: 'separator' },
    { label: '重新整理', click: () => alive(tab.wc) && tab.wc.reload() },
    {
      label: '複製分頁',
      enabled: !tab.internal && !!tab.url,
      click: () => createTab(tab.url, { afterId: id }),
    },
    {
      label: '複製網址',
      enabled: !tab.internal && !!tab.url,
      click: () => copyText(tab.url),
    },
    { type: 'separator' },
    { label: '關閉分頁', click: () => closeTab(id) },
    {
      label: '關閉其他分頁',
      enabled: tabs.length > 1,
      click: () => tabs.filter((t) => t.id !== id).forEach((t) => closeTab(t.id)),
    },
    {
      label: '關閉右側分頁',
      enabled: index < tabs.length - 1,
      click: () => tabs.slice(index + 1).forEach((t) => closeTab(t.id)),
    },
  );
  Menu.buildFromTemplate(tpl).popup({ window: win });
}

function showPageContextMenu(tab, params) {
  const wc = tab.wc;
  const flags = params.editFlags || {};
  const tpl = [];

  if (params.linkURL) {
    tpl.push(
      { label: '在新分頁開啟連結', click: () => createTab(params.linkURL, { afterId: tab.id }) },
      { label: '複製連結網址', click: () => copyText(params.linkURL) },
      { type: 'separator' },
    );
  }
  if (params.mediaType === 'image' && params.srcURL) {
    tpl.push(
      { label: '在新分頁開啟圖片', click: () => createTab(params.srcURL, { afterId: tab.id }) },
      { label: '另存圖片…', click: () => wc.downloadURL(params.srcURL) },
      { label: '複製圖片網址', click: () => copyText(params.srcURL) },
      { type: 'separator' },
    );
  }
  if (params.isEditable) {
    tpl.push(
      { label: '復原', enabled: !!flags.canUndo, click: () => wc.undo() },
      { label: '重做', enabled: !!flags.canRedo, click: () => wc.redo() },
      { type: 'separator' },
      { label: '剪下', enabled: !!flags.canCut, click: () => wc.cut() },
      { label: '複製', enabled: !!flags.canCopy, click: () => wc.copy() },
      { label: '貼上', enabled: !!flags.canPaste, click: () => wc.paste() },
      { label: '全選', enabled: !!flags.canSelectAll, click: () => wc.selectAll() },
      { type: 'separator' },
    );
  } else if (params.selectionText) {
    const text = params.selectionText.trim();
    const short = text.length > 18 ? `${text.slice(0, 18)}…` : text;
    tpl.push(
      { label: '複製', click: () => wc.copy() },
      {
        label: `搜尋「${short}」`,
        click: () => createTab(SEARCH_URL + encodeURIComponent(text), { afterId: tab.id }),
      },
      { type: 'separator' },
    );
  }
  tpl.push(
    { label: '返回', enabled: navCan(wc, 'back'), click: () => navGo(wc, 'back') },
    { label: '前進', enabled: navCan(wc, 'forward'), click: () => navGo(wc, 'forward') },
    { label: '重新整理', click: () => wc.reload() },
    { type: 'separator' },
    { label: '檢查元素', click: () => wc.inspectElement(params.x, params.y) },
  );
  Menu.buildFromTemplate(tpl).popup({ window: win });
}

/* ───────────────────────── 分頁事件綁定 ───────────────────────── */
function wireTab(tab) {
  const wc = tab.wc;

  // window.open / target=_blank / Ctrl+點擊 → 一律開成本瀏覽器的新分頁
  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (/^(https?|file):/i.test(url)) {
      createTab(url, { activate: disposition !== 'background-tab', afterId: tab.id });
    } else if (/^(mailto|tel):/i.test(url)) {
      shell.openExternal(url).catch(() => {});
    }
    return { action: 'deny' };
  });

  wc.on('page-title-updated', (_e, title) => {
    tab.title = title;
    scheduleState();
  });
  wc.on('page-favicon-updated', (_e, favicons) => {
    tab.favicon = (favicons && favicons[0]) || '';
    scheduleState();
  });
  wc.on('audio-state-changed', () => {
    if (readAudio(tab)) scheduleState();
  });
  wc.on('did-start-loading', () => {
    tab.loading = true;
    scheduleState();
  });
  wc.on('did-stop-loading', () => {
    syncMeta(tab);
    scheduleState();
  });
  wc.on('did-navigate', () => {
    tab.domReady = false;
    tab.favicon = '';
    syncMeta(tab);
    scheduleState();
  });
  wc.on('did-navigate-in-page', (_e, _url, isMainFrame) => {
    if (isMainFrame === false) return;
    syncMeta(tab);
    scheduleState();
  });
  wc.on('did-fail-load', (_e, code, _desc, _url, isMainFrame) => {
    if (isMainFrame === false || code === -3) return; // -3 = 使用者自己中止載入
    syncMeta(tab);
    scheduleState();
  });
  wc.on('dom-ready', () => {
    tab.domReady = true;
    tab.applied = new Map(); // 新的文件:之前的套用紀錄作廢
    syncMeta(tab);
    if (isDisplayed(tab)) applyScripts(tab);
    scheduleState();
  });
  wc.on('render-process-gone', () => {
    tab.domReady = false;
    tab.loading = false;
    scheduleState();
  });

  // 點到哪個分頁,哪個就成為使用中的分頁
  wc.on('focus', () => activateByPage(tab));

  wc.on('before-input-event', handleShortcut);
  wc.on('context-menu', (_e, params) => showPageContextMenu(tab, params));

  // 網頁要求 HTML 全螢幕(例如 YouTube 全螢幕)
  wc.on('enter-html-full-screen', () => {
    tab.fullscreen = true;
    relayout();
  });
  wc.on('leave-html-full-screen', () => {
    tab.fullscreen = false;
    relayout();
  });

  // 頁面的 beforeunload 會擋住導覽;沒有處理的話使用者會無法離開該頁
  wc.on('will-prevent-unload', (event) => {
    const choice = dialog.showMessageBoxSync(alive(win) ? win : undefined, {
      type: 'question',
      buttons: ['離開', '留在這一頁'],
      defaultId: 1,
      cancelId: 1,
      noLink: true,
      title: '要離開這個頁面嗎?',
      message: '這個網站可能不會儲存你所做的變更。',
    });
    if (choice === 0) event.preventDefault();
  });
}

/* ───────────────────────── 視窗 ───────────────────────── */
function createWindow() {
  const saved = config.window || {};
  win = new BrowserWindow({
    width: clamp(Number(saved.width) || 1440, 760, 10000),
    height: clamp(Number(saved.height) || 880, 520, 10000),
    minWidth: 760,
    minHeight: 520,
    show: false,
    title: APP_TITLE,
    backgroundColor: nativeTheme.shouldUseDarkColors ? '#14171a' : '#e8ebee',
    icon: ICON_FILE,
    autoHideMenuBar: true,
    webPreferences: {
      preload: PRELOAD_UI,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  if (saved.maximized) win.maximize();

  const ui = win.webContents;
  try {
    // 介面層不可縮放(Ctrl+滾輪),否則方塊外框會和網頁對不齊
    Promise.resolve(ui.setVisualZoomLevelLimits(1, 1)).catch(() => {});
  } catch (_) { /* ignore */ }
  ui.setWindowOpenHandler(() => ({ action: 'deny' }));
  ui.on('will-navigate', (e) => e.preventDefault()); // 把檔案拖進工具列時,不要讓 UI 頁面被導走
  ui.on('before-input-event', handleShortcut);
  win.on('page-title-updated', (e) => e.preventDefault());

  win.once('ready-to-show', () => win.show());
  setTimeout(() => { if (alive(win) && !win.isVisible()) win.show(); }, 2500);

  let resizeTimer = null;
  const later = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(relayout, 60);
  };
  win.on('resize', relayout);
  win.on('maximize', later);
  win.on('unmaximize', later);
  win.on('enter-full-screen', later);
  win.on('leave-full-screen', later);
  win.on('restore', later);

  win.on('close', () => saveConfig());
  win.on('closed', () => {
    for (const t of tabs) {
      if (alive(t.wc)) {
        try {
          t.wc.close();
        } catch (_) { /* ignore */ }
      }
    }
    clearInterval(audioTimer);
    for (const t of tabs) clearInterval(t.refreshTimer);
    tabs = [];
    win = null;
  });

  win.loadFile(INDEX_FILE);
  if (process.env.SOLOV_DEBUG) ui.openDevTools({ mode: 'detach' });
}

function restoreSession(extraUrl) {
  const saved = Array.isArray(config.tabs) ? config.tabs.slice(0, MAX_RESTORE_TABS) : [];
  for (const s of saved) {
    const url = s && typeof s.url === 'string' ? s.url : '';
    if (url && !/^(https?|file):/i.test(url)) continue;
    const tab = createTab(url || null, { activate: false, shown: !s || s.shown !== false, focus: false });
    if (s && REFRESH_CHOICES.includes(s.refresh)) setAutoRefresh(tab.id, s.refresh);
  }
  if (tabs.length) {
    const idx = clamp(Number.isInteger(config.active) ? config.active : 0, 0, tabs.length - 1);
    setActive(tabs[idx].id, { force: true });
  }
  if (extraUrl) createTab(extraUrl);
  else if (!tabs.length) createTab(null);
}

/* ───────────────────────── IPC ───────────────────────── */
function onUI(channel, fn) {
  ipcMain.on(channel, (event, ...args) => {
    if (!uiAlive() || event.sender !== win.webContents) return;
    try {
      fn(...args);
    } catch (err) {
      console.error(`[ipc ${channel}]`, err);
    }
  });
}

function handleUI(channel, fn) {
  ipcMain.handle(channel, (event, ...args) => {
    if (!uiAlive() || event.sender !== win.webContents) throw new Error('forbidden');
    return fn(...args);
  });
}

async function importScripts() {
  const options = {
    title: '匯入 JavaScript 腳本',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'JavaScript', extensions: ['js'] }, { name: '所有檔案', extensions: ['*'] }],
  };
  const res = alive(win) ? await dialog.showOpenDialog(win, options) : await dialog.showOpenDialog(options);
  if (res.canceled || !res.filePaths.length) return;

  let count = 0;
  for (const file of res.filePaths.slice(0, 20)) {
    try {
      const code = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
      if (code.length > 1000000) continue;
      const meta = parseUserscriptHeader(code);
      scripts.push(hydrateScript({ name: meta.name || path.basename(file), code, enabled: false, match: meta.match }));
      count += 1;
    } catch (_) { /* 略過讀不到的檔案 */ }
  }
  persistScripts();
  sendScripts(true);
  note(count ? `已匯入 ${count} 個腳本(預設停用,確認內容後再啟用)` : '沒有匯入任何腳本');
}

/* ───────────────────────── 起始頁自訂背景 ───────────────────────── */
function isNewTabSender(event) {
  const wc = event && event.sender;
  if (!wc || typeof wc.getURL !== 'function' || !isNewTabUrl(wc.getURL())) return false;
  // 只接受頂層頁面,不接受 iframe
  if (event.senderFrame && wc.mainFrame && event.senderFrame !== wc.mainFrame) return false;
  return true;
}

/** 選一個圖片或影片,複製到資料夾,回傳可直接給起始頁使用的 file:// 網址 */
async function pickBackground() {
  const exts = (list) => list.map((e) => e.slice(1));
  const options = {
    title: '選擇背景圖片或影片',
    properties: ['openFile'],
    filters: [
      { name: '圖片或影片', extensions: exts(BG_IMAGE_EXTS.concat(BG_VIDEO_EXTS)) },
      { name: '圖片', extensions: exts(BG_IMAGE_EXTS) },
      { name: '影片', extensions: exts(BG_VIDEO_EXTS) },
    ],
  };
  const res = alive(win) ? await dialog.showOpenDialog(win, options) : await dialog.showOpenDialog(options);
  if (res.canceled || !res.filePaths || !res.filePaths.length) return { ok: false, canceled: true };

  const src = res.filePaths[0];
  const ext = path.extname(src).toLowerCase();
  const kind = BG_IMAGE_EXTS.includes(ext) ? 'image' : BG_VIDEO_EXTS.includes(ext) ? 'video' : null;
  if (!kind) return { ok: false, error: '不支援這種檔案格式(支援圖片:jpg、png、gif、webp、avif、bmp、svg;影片:mp4、webm、m4v、ogv、mov)' };

  try {
    const st = await fs.promises.stat(src);
    if (!st.isFile()) return { ok: false, error: '找不到這個檔案' };
    if (st.size > BG_MAX_BYTES) return { ok: false, error: '檔案太大(上限 500 MB)' };
    await fs.promises.mkdir(BG_DIR, { recursive: true });
    const dest = path.join(BG_DIR, 'bg-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex') + ext);
    await fs.promises.copyFile(src, dest);
    return { ok: true, kind, name: path.basename(src), url: pathToFileURL(dest).href };
  } catch (err) {
    return { ok: false, error: '無法讀取這個檔案:' + (err && err.message ? err.message : err) };
  }
}

/** 刪掉背景資料夾裡「不是 keepUrl」的舊檔案(keepUrl 為空 = 全部刪除) */
async function pruneBackgrounds(keepUrl) {
  let names = [];
  try {
    names = await fs.promises.readdir(BG_DIR);
  } catch (_) {
    return 0;
  }
  let removed = 0;
  for (const name of names) {
    if (!/^bg-\d+-[0-9a-f]+\.[a-z0-9]+$/i.test(name)) continue; // 只動自己建立的檔案
    const full = path.join(BG_DIR, name);
    if (keepUrl && pathToFileURL(full).href === keepUrl) continue;
    try {
      await fs.promises.unlink(full);
      removed += 1;
    } catch (_) { /* 影片可能還在播放而被佔用,下次再清 */ }
  }
  return removed;
}

function registerIpc() {
  // 來自起始頁(newtab.html)的背景設定;只接受「顯示起始頁的分頁」發來的請求
  ipcMain.handle('newtab:bg-pick', (event) => {
    if (!isNewTabSender(event)) throw new Error('forbidden');
    return pickBackground();
  });
  ipcMain.handle('newtab:bg-prune', (event, keepUrl) => {
    if (!isNewTabSender(event)) throw new Error('forbidden');
    return pruneBackgrounds(typeof keepUrl === 'string' ? keepUrl : '');
  });

  handleUI('ui:ready', () => ({ state: buildState(), scripts: publicScripts() }));

  // 來自網頁分頁(preload):使用者點到了這個分頁
  ipcMain.on('tab:interact', (event) => {
    const tab = tabByWebContentsId(event.sender.id);
    if (tab) activateByPage(tab);
  });

  onUI('tab:new', () => createTab(null));
  onUI('tab:close', (id) => closeTab(id));
  onUI('tab:activate', (id, toggle) => {
    const tab = getTab(id);
    if (!tab) return;
    if (toggle && layout !== 'single') {
      toggleShown(id);
      if (getTab(id) && getTab(id).shown) setActive(id, { focus: true });
      return;
    }
    setActive(id, { focus: true });
  });
  onUI('tab:toggle-shown', (id) => toggleShown(id));
  onUI('tab:menu', (id) => showTabMenu(id));

  onUI('nav:go', (text) => navigateActive(text));
  onUI('nav:back', () => { const t = getTab(activeId); if (t) navGo(t.wc, 'back'); });
  onUI('nav:forward', () => { const t = getTab(activeId); if (t) navGo(t.wc, 'forward'); });
  onUI('nav:reload', () => { const t = getTab(activeId); if (t && alive(t.wc)) t.wc.reload(); });
  onUI('nav:stop', () => { const t = getTab(activeId); if (t && alive(t.wc)) t.wc.stop(); });

  onUI('layout:set', (next) => setLayout(next));
  onUI('panel:set', (open) => setPanel(!!open));
  onUI('view:maximize', (id) => {
    if (typeof id === 'number' && getTab(id)) setActive(id); // 雙擊哪個方塊的標題列,就放大哪一個
    toggleMaximize();
  });
  onUI('tab:mute', (id) => toggleMute(id));
  onUI('tab:auto-refresh', (id, sec) => setAutoRefresh(id, Number(sec) || 0));

  // 使用者腳本
  handleUI('scripts:save', (payload) => {
    const p = payload || {};
    const name = String(p.name || '').trim().slice(0, 120) || '未命名腳本';
    const code = String(p.code == null ? '' : p.code).slice(0, 1000000);
    let s = p.id ? scripts.find((x) => x.id === p.id) : null;
    const match = String(p.match == null ? (s ? s.match : '') : p.match).trim().slice(0, 2000);

    if (!s) {
      s = hydrateScript({ name, code, enabled: p.enabled !== false, match });
      scripts.push(s);
    } else {
      const changed = s.code !== code || s.match !== match;
      s.name = name;
      s.code = code;
      s.match = match;
      if (typeof p.enabled === 'boolean') s.enabled = p.enabled;
      if (changed) {
        s.rev += 1; // 程式碼或網址限定改了:已啟用的話會重新套用到畫面上的分頁
        s.status = freshStatus();
      }
    }
    persistScripts();
    sendScripts(true);
    applyScriptsToDisplayed();
    return { id: s.id, enabled: s.enabled };
  });

  onUI('scripts:remove', (id) => {
    scripts = scripts.filter((s) => s.id !== id);
    for (const t of tabs) t.applied.delete(id);
    persistScripts();
    sendScripts(true);
  });

  onUI('scripts:toggle', (id, enabled) => {
    const s = scripts.find((x) => x.id === id);
    if (!s) return;
    s.enabled = !!enabled;
    if (s.enabled) {
      s.rev += 1; // 重新啟用 → 重新套用
      s.status = freshStatus();
    } else {
      for (const t of tabs) t.applied.delete(id);
    }
    persistScripts();
    sendScripts(true);
    if (s.enabled) applyScriptsToDisplayed();
  });

  onUI('scripts:run', (id) => {
    const s = scripts.find((x) => x.id === id);
    if (s) runScriptNow(s);
  });

  onUI('scripts:import', () => {
    importScripts().catch((err) => note(`匯入失敗:${err.message}`));
  });

  onUI('tabs:reload-shown', () => {
    for (const t of displayedTabs()) if (alive(t.wc)) t.wc.reload();
  });
}

/* ───────────────────────── 啟動 ───────────────────────── */
function urlFromArgv(argv) {
  return (argv || []).find((a) => /^https?:\/\//i.test(a)) || null;
}

function start() {
  app.setAppUserModelId('local.solov.browser');

  const userData = app.getPath('userData');
  try {
    fs.mkdirSync(userData, { recursive: true });
  } catch (_) { /* ignore */ }
  CONFIG_FILE = path.join(userData, 'config.json');
  SCRIPTS_FILE = path.join(userData, 'scripts.json');
  BG_DIR = path.join(userData, 'backgrounds');

  config = readJson(CONFIG_FILE, {}) || {};
  if (LAYOUTS.includes(config.layout)) layout = config.layout;

  const stored = readJson(SCRIPTS_FILE, null);
  if (Array.isArray(stored)) {
    scripts = stored.filter((s) => s && typeof s === 'object').map(hydrateScript);
  } else {
    scripts = [hydrateScript(DEMO_SCRIPT)]; // 第一次執行:放一個(停用的)範例腳本
    persistScripts();
  }

  const ua = buildUserAgent();
  app.userAgentFallback = ua;
  session.defaultSession.setUserAgent(ua);
  setupPermissions(session.defaultSession);
  setupMenu();
  registerIpc();
  createWindow();
  audioTimer = setInterval(pollAudio, 1500);
  if (audioTimer.unref) audioTimer.unref();
  win.webContents.once('did-finish-load', () => restoreSession(urlFromArgv(process.argv.slice(1))));
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_event, argv) => {
    if (!alive(win)) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    const url = urlFromArgv(argv);
    createTab(url || null);
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => saveConfig());
  app.whenReady().then(start);
}

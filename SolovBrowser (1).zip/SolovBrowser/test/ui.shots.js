'use strict';
/* 在無頭 Chromium 載入真正的 renderer/index.html,用假的 window.mv 餵狀態,
 * 檢查:畫面排版(輸出截圖)、事件有沒有接對、有沒有 console 錯誤。 */
const { chromium } = require('playwright');
const assert = require('assert');
const path = require('path');
const { computeLayout } = require('../lib/layout');

const ROOT = path.resolve(__dirname, '..');
const INDEX = 'file://' + path.join(ROOT, 'renderer', 'index.html');
const NEWTAB = 'file://' + path.join(ROOT, 'renderer', 'newtab.html');
const OUT = process.argv[2] || '/home/claude/shots';
const metrics = { tabH: 38, barH: 44, chromeH: 82, panelW: 420, headH: 30, frame: 2 };

const mk = (id, title, o = {}) => ({ id, title, url: o.internal ? '' : `https://site${id}.example/path`, favicon: '', loading: false, shown: true, internal: false, canGoBack: true, canGoForward: false, audible: false, muted: false, refreshSec: 0, ...o });
function build({ W, H, tabs, activeId, layout, panelOpen = false, maximized = false }) {
  const displayed = layout === 'single' || maximized ? tabs.filter((t) => t.id === activeId) : tabs.filter((t) => t.shown);
  const lay = computeLayout({ width: W, height: H, chromeH: metrics.chromeH, panelW: panelOpen ? metrics.panelW : 0, count: displayed.length, layout });
  const tiles = lay.split ? lay.tiles.map((t, i) => ({ id: displayed[i].id, x: t.outer.x, y: t.outer.y, w: t.outer.w, h: t.outer.h })) : [];
  const views = lay.tiles.map((t, i) => ({ ...t.view, title: displayed[i].title }));
  return { state: { tabs, activeId, layout, maximized, panelOpen, tiles, displayedCount: displayed.length, metrics }, views };
}

const now = Date.now();
const SCRIPTS = [
  { id: 's1', name: '隱藏頁面上的廣告區塊', code: 'document.querySelectorAll(".ad").forEach(e => e.remove());', enabled: true, match: '', status: { runs: 6, errors: 0, lastAt: now, lastOk: true, lastError: '', lastTab: '' } },
  { id: 's2', name: '自動捲到留言區並展開全部回覆(名稱很長很長很長很長很長很長很長)', code: '', enabled: true, match: 'youtube.com, !youtube.com/shorts/*', status: { runs: 3, errors: 1, lastAt: now, lastOk: true, lastError: 'TypeError: Cannot read properties of null (reading "scrollIntoView")', lastTab: 'YouTube - 影片牆' } },
  { id: 's3', name: '範例:在每個分頁右下角顯示網域標籤', code: '// demo', enabled: false, match: '', status: { runs: 0, errors: 0, lastAt: 0, lastOk: null, lastError: '', lastTab: '' } },
  { id: 's4', name: '剛啟用、等待網頁載入', code: '', enabled: true, match: '', status: { runs: 0, errors: 0, lastAt: 0, lastOk: null, lastError: '', lastTab: '' } },
];

const STUB = ({ state, scripts }) => {
  const cbs = { state: [], scripts: [], focus: [], note: [] };
  window.__calls = [];
  const rec = (name) => (...a) => { window.__calls.push([name, ...a]); };
  window.mv = {
    ready: () => Promise.resolve({ state, scripts }),
    onState: (cb) => cbs.state.push(cb), onScripts: (cb) => cbs.scripts.push(cb), onFocusAddress: (cb) => cbs.focus.push(cb), onNote: (cb) => cbs.note.push(cb),
    newTab: rec('newTab'), closeTab: rec('closeTab'), activateTab: rec('activateTab'), toggleShown: rec('toggleShown'), tabMenu: rec('tabMenu'),
    go: rec('go'), back: rec('back'), forward: rec('forward'), reload: rec('reload'), stop: rec('stop'),
    setLayout: rec('setLayout'), setPanel: rec('setPanel'),
    muteTab: rec('muteTab'), autoRefresh: rec('autoRefresh'), maximize: rec('maximize'),
    scripts: {
      save: async (s) => { window.__calls.push(['save', s]); return { id: 'new', enabled: s.enabled !== false }; },
      remove: rec('remove'), toggle: rec('toggle'), run: rec('run'), importFiles: rec('importFiles'), reloadShown: rec('reloadShown'),
    },
  };
  window.__push = (s) => cbs.state.forEach((cb) => cb(s));
  window.__pushScripts = (s) => cbs.scripts.forEach((cb) => cb(s));
  window.__focusAddr = () => cbs.focus.forEach((cb) => cb());
  window.__note = (t) => cbs.note.forEach((cb) => cb(t));
};

function paintFakeViews(views) {
  document.querySelectorAll('.fakeview').forEach((e) => e.remove());
  const panel = document.getElementById('panel');
  views.forEach((v) => {
    const d = document.createElement('div');
    d.className = 'fakeview';
    d.style.cssText = `position:absolute;left:${v.x}px;top:${v.y}px;width:${v.w}px;height:${v.h}px;background:#fff;color:#222;overflow:hidden;font:14px/1.6 system-ui;padding:18px 22px;box-sizing:border-box`;
    d.innerHTML = `<div style="font-size:20px;font-weight:700;margin-bottom:8px">${v.title}</div>` +
      '<div style="height:9px;background:#e3e6ea;border-radius:5px;margin:9px 0;width:92%"></div>'.repeat(4) +
      '<div style="height:60px;background:#eef1f4;border-radius:8px;margin:14px 0"></div>' +
      '<div style="height:9px;background:#e3e6ea;border-radius:5px;margin:9px 0;width:70%"></div>'.repeat(3);
    document.getElementById('app').insertBefore(d, panel);
  });
}

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  let checks = 0;
  const ok = (m) => { checks++; console.log('  ok  ' + m); };

  async function open(name, { W = 1440, H = 860, scheme = 'light', data, scripts = SCRIPTS }) {
    const ctx = await browser.newContext({ viewport: { width: W, height: H }, colorScheme: scheme });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => problems.push(`[${name}] pageerror: ${e.message}`));
    page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) problems.push(`[${name}] console.${m.type()}: ${m.text()}`); });
    await page.addInitScript(STUB, { state: data.state, scripts });
    await page.goto(INDEX);
    await page.waitForSelector('.tab');
    await page.evaluate(paintFakeViews, data.views);
    return { page, ctx, shot: (suffix) => page.screenshot({ path: path.join(OUT, `${name}${suffix || ''}.png`) }) };
  }
  const calls = (page) => page.evaluate(() => window.__calls.splice(0));

  const T5 = [
    mk(1, 'Hacker News'), mk(2, 'YouTube - 影片牆', { favicon: '' }), mk(3, '維基百科,自由的百科全書'),
    mk(4, 'GitHub: Let’s build from here', { loading: true }), mk(5, '已收起的分頁(從畫面隱藏)', { shown: false }),
  ];

  /* ---- 1. 單一分頁 + 新分頁頁面 ---- */
  for (const scheme of ['light', 'dark']) {
    const d = build({ W: 1440, H: 860, tabs: [mk(1, '新分頁', { internal: true, canGoBack: false })], activeId: 1, layout: 'grid' });
    const { page, ctx, shot } = await open(`1-single-${scheme}`, { scheme, data: d });
    await shot(); await ctx.close();
  }

  /* ---- 2. 網格(5 個分頁,1 個收起,1 個載入中) ---- */
  for (const scheme of ['light', 'dark']) {
    const d = build({ W: 1440, H: 860, tabs: T5, activeId: 2, layout: 'grid' });
    const { page, ctx, shot } = await open(`2-grid-${scheme}`, { scheme, data: d });
    await shot();

    if (scheme === 'light') {
      // 事件接線
      assert.strictEqual(await page.locator('.tab').count(), 5);
      assert.strictEqual(await page.locator('.tile').count(), 4);
      assert.strictEqual(await page.locator('.tab.active').count(), 1);
      assert.strictEqual(await page.locator('.tile.active').count(), 1);
      assert.strictEqual(await page.locator('.tab.parked').count(), 1);
      assert.strictEqual(await page.locator('.tab.onscreen').count(), 4);
      assert.strictEqual(await page.locator('.tile.loading').count(), 1);
      assert.strictEqual(await page.locator('.layouts button.on').getAttribute('data-layout'), 'grid');
      assert.strictEqual(await page.locator('#btn-back').isDisabled(), false);
      assert.strictEqual(await page.locator('#btn-forward').isDisabled(), true);
      assert.strictEqual(await page.locator('#btn-restore').isHidden(), true, 'restore button only exists while maximized');
      assert.strictEqual(await page.locator('#addr').inputValue(), 'https://site2.example/path');
      ok('grid: 5 tabs, 4 tiles, one active, one parked, one loading; address bar shows the active tab');

      await page.locator('.tab').nth(2).click();                 // mousedown → activate
      await page.locator('.tab').nth(0).click({ modifiers: ['Control'] });
      await page.locator('.tab').nth(4).hover();
      await page.locator('.tab').nth(4).locator('.eye').click();
      await page.locator('.tab').nth(1).locator('.close').click();
      await page.locator('.tab').nth(3).click({ button: 'right' });
      await page.locator('.tab').nth(3).click({ button: 'middle' });
      await page.locator('#btn-newtab').click();
      await page.locator('.layouts button[data-layout="cols"]').click();
      await page.locator('#btn-reload').click();
      await page.locator('#btn-back').click();
      const c = await calls(page);
      assert.deepStrictEqual(c.filter((x) => x[0] === 'activateTab'), [['activateTab', 3, false], ['activateTab', 1, true]]);
      assert(c.some((x) => x[0] === 'toggleShown' && x[1] === 5), 'eye on the parked tab');
      assert(c.some((x) => x[0] === 'closeTab' && x[1] === 2), 'close button');
      assert(c.some((x) => x[0] === 'tabMenu' && x[1] === 4), 'right click → native tab menu');
      assert(c.some((x) => x[0] === 'closeTab' && x[1] === 4), 'middle click closes');
      assert(c.some((x) => x[0] === 'newTab') && c.some((x) => x[0] === 'setLayout' && x[1] === 'cols'));
      assert(c.some((x) => x[0] === 'reload') && c.some((x) => x[0] === 'back'));
      ok('tab strip / toolbar clicks reach the main process with the right ids (incl. Ctrl+click, middle, right click)');

      await page.locator('.tile').nth(0).locator('.head').click();
      await page.locator('.tile').nth(1).locator('.hide').click();
      await page.locator('.tile').nth(2).locator('.close').click();
      const c2 = await calls(page);
      assert.deepStrictEqual(c2, [['activateTab', 1, false], ['toggleShown', 2], ['closeTab', 3]]);
      ok('tile header: click activates, eye hides from view, × closes the tab');

      // 位址列
      const addr = page.locator('#addr');
      await addr.click();
      assert.strictEqual(await page.evaluate(() => window.getSelection().toString() || document.activeElement.value.substring(document.activeElement.selectionStart, document.activeElement.selectionEnd)), 'https://site2.example/path');
      await addr.fill('example.com'); await addr.press('Enter');
      assert.deepStrictEqual((await calls(page)).filter((x) => x[0] === 'go'), [['go', 'example.com']]);
      assert.strictEqual(await addr.inputValue(), 'example.com', 'keeps what was typed after Enter (no flash back)');
      await addr.click(); await addr.fill('abc'); await addr.press('Escape');
      assert.strictEqual(await addr.inputValue(), 'https://site2.example/path');
      ok('address bar: select-all on focus, Enter navigates, Escape reverts');
      // 輸入中不被推送覆蓋
      await addr.click(); await addr.fill('typing…');
      await page.evaluate((s) => window.__push(s), { ...d.state, tabs: d.state.tabs.map((t) => ({ ...t, title: t.title + '!' })) });
      assert.strictEqual(await addr.inputValue(), 'typing…');
      await addr.press('Escape');
      ok('a state push does not overwrite what the user is typing in the address bar');

      // 版面按鈕 / 面板按鈕
      assert.strictEqual(await page.locator('.layouts button').count(), 4);
      await page.locator('#btn-ext').click();
      assert.deepStrictEqual((await calls(page)).filter((x) => x[0] === 'setPanel'), [['setPanel', true]]);
      ok('layout buttons and the extensions button call main');
    }
    await ctx.close();
  }

  /* ---- 3. 面板 + 腳本清單 ---- */
  for (const scheme of ['light', 'dark']) {
    const d = build({ W: 1440, H: 860, tabs: T5, activeId: 2, layout: 'grid', panelOpen: true });
    const { page, ctx, shot } = await open(`3-panel-${scheme}`, { scheme, data: d });
    await shot();

    if (scheme === 'light') {
      assert.strictEqual(await page.locator('#panel').isVisible(), true);
      assert.strictEqual(await page.locator('.script').count(), 4);
      assert.strictEqual(await page.locator('#ext-badge').textContent(), '3');
      assert.strictEqual(await page.locator('#btn-ext.on').count(), 1);
      assert.match(await page.locator('#panel-sub').textContent(), /4 個分頁/);
      assert.strictEqual(await page.locator('.script .status.err').count(), 1);
      assert.strictEqual(await page.locator('.script .status.ok').count(), 1);
      assert.strictEqual(await page.locator('.script .scope:visible').count(), 1);
      assert.match(await page.locator('.script .scope:visible').textContent(), /^限定:youtube\.com, !youtube\.com\/shorts\/\*$/);
      assert.match(await page.locator('.script .status.err').textContent(), /出錯 1\/3 次.*scrollIntoView.*YouTube/);
      assert.strictEqual(await page.locator('#script-empty').isVisible(), false);
      ok('panel: 4 scripts, badge counts the 3 enabled ones, errors are red and name the tab, sub-title shows displayed tab count');

      await page.locator('.script').nth(2).locator('.sw').check({ force: true });
      await page.locator('.script').nth(0).locator('.run').click();
      assert.deepStrictEqual(await calls(page), [['toggle', 's3', true], ['run', 's1']]);
      ok('switch toggles and ▶ run reach main');

      // 兩段式刪除
      const del = page.locator('.script').nth(1).locator('.del');
      await del.click();
      assert.strictEqual((await del.textContent()).trim(), '確定刪除');
      assert.deepStrictEqual(await calls(page), []);
      await del.click();
      assert.deepStrictEqual(await calls(page), [['remove', 's2']]);
      ok('delete needs a second click to confirm');

      // 新增 → 編輯器
      await page.locator('#btn-add').click();
      assert.strictEqual(await page.locator('#view-edit').isVisible(), true);
      assert.strictEqual(await page.locator('#view-list').isVisible(), false);
      assert.strictEqual(await page.locator('#panel-title').textContent(), '新增腳本');
      assert.match(await page.locator('#edit-code').inputValue(), /Solov Browser 腳本執行中/);
      await page.locator('#edit-name').fill('我的腳本');
      await page.locator('#edit-match').fill('example.com, !example.com/login*');
      await page.locator('#edit-code').click();
      await page.keyboard.press('Control+A');
      await page.keyboard.type('const a = 1;');
      await page.keyboard.press('Enter');
      await page.keyboard.press('Tab');
      await page.keyboard.type('console.log(a);');
      assert.strictEqual(await page.locator('#edit-code').inputValue(), 'const a = 1;\n  console.log(a);');
      await shot('-editor');
      await page.keyboard.press('Control+S');
      await page.waitForTimeout(50);
      const saved = (await calls(page)).find((x) => x[0] === 'save');
      assert.deepStrictEqual(saved[1], { id: null, name: '我的腳本', match: 'example.com, !example.com/login*', code: 'const a = 1;\n  console.log(a);', enabled: true });
      assert.strictEqual(await page.locator('#view-list').isVisible(), true);
      assert.match(await page.locator('#panel-note').textContent(), /已儲存/);
      ok('editor: template, Tab inserts spaces, Ctrl+S saves {name, code, enabled:true} and returns to the list');

      // 編輯既有腳本 / 取消
      await page.locator('.script').nth(0).locator('.edit').click();
      assert.strictEqual(await page.locator('#panel-title').textContent(), '編輯腳本');
      assert.strictEqual(await page.locator('#edit-name').inputValue(), '隱藏頁面上的廣告區塊');
      await page.locator('#edit-save').click(); await page.waitForTimeout(30);
      assert.strictEqual((await calls(page)).find((x) => x[0] === 'save')[1].id, 's1');
      await page.locator('.script').nth(0).locator('.edit').click();
      await page.locator('#edit-cancel').click();
      assert.deepStrictEqual(await calls(page), []);
      assert.strictEqual(await page.locator('#view-list').isVisible(), true);
      ok('editing an existing script keeps its id; cancel leaves nothing behind');

      // 已有網址限定的腳本:編輯器要帶出原本的規則
      await page.locator('.script').nth(1).locator('.edit').click();
      assert.strictEqual(await page.locator('#edit-match').inputValue(), 'youtube.com, !youtube.com/shorts/*');
      await page.locator('#edit-cancel').click();
      await page.locator('#btn-add').click();
      assert.strictEqual(await page.locator('#edit-match').inputValue(), '', 'new scripts start with no URL limit');
      await page.locator('#edit-cancel').click();
      ok('URL-limit field: shown in the list, loaded into the editor, empty for new scripts');

      // 推送:腳本清單更新、空狀態
      await page.evaluate(() => window.__pushScripts([]));
      assert.strictEqual(await page.locator('.script').count(), 0);
      assert.strictEqual(await page.locator('#script-empty').isVisible(), true);
      assert.strictEqual(await page.locator('#ext-badge').isHidden(), true);
      await page.evaluate((s) => window.__pushScripts(s), SCRIPTS);
      assert.strictEqual(await page.locator('.script').count(), 4);
      await page.evaluate(() => window.__note('已匯入 2 個腳本(預設停用,確認內容後再啟用)'));
      assert.match(await page.locator('#panel-note').textContent(), /已匯入 2/);
      ok('script list pushes (empty state, repopulate) and notes render');

      // 面板關閉
      await page.locator('#panel-close').click();
      assert.deepStrictEqual(await calls(page), [['setPanel', false]]);
    }
    await ctx.close();
  }

  /* ---- 6. 聲音 / 自動重新整理 / 放大 ---- */
  for (const scheme of ['light', 'dark']) {
    const tabs = [
      mk(1, 'Hacker News'), mk(2, 'YouTube - 影片牆', { audible: true }),
      mk(3, '儀表板:伺服器狀態', { refreshSec: 30 }), mk(4, '直播(已靜音)', { audible: true, muted: true, refreshSec: 300 }),
    ];
    const d = build({ W: 1440, H: 860, tabs, activeId: 3, layout: 'grid' });
    const { page, ctx, shot } = await open(`6-audio-refresh-${scheme}`, { scheme, data: d });
    await shot();

    if (scheme === 'light') {
      assert.strictEqual(await page.locator('.tab.audio').count(), 2);
      assert.strictEqual(await page.locator('.tile.audio').count(), 2);
      assert.strictEqual(await page.locator('.tile.auto').count(), 2);
      assert.strictEqual(await page.locator('.tab .sound:visible').count(), 2, 'speaker only on tabs with sound');
      assert.strictEqual(await page.locator('.tile .sound:visible').count(), 2);
      assert.deepStrictEqual(await page.$$eval('.tile.auto .rf', (els) => els.map((e) => e.textContent)), ['30秒', '5分']);
      assert.strictEqual(await page.locator('.tab').nth(1).locator('.sound.live').count(), 1, 'audible + not muted is highlighted');
      assert.strictEqual(await page.locator('.tab').nth(3).locator('.sound.live').count(), 0, 'muted is not highlighted');
      assert.match(await page.locator('.tab').nth(3).locator('.sound').getAttribute('title'), /取消靜音/);
      assert.match(await page.locator('.tile').nth(2).locator('.refresh').getAttribute('title'), /每 30 秒.*點一下關閉/);
      assert.match(await page.locator('.tile').nth(3).locator('.refresh').getAttribute('title'), /每 5 分鐘/);
      ok('sound and auto-refresh indicators appear only where relevant, with the right labels');

      await calls(page);
      await page.locator('.tile').nth(1).locator('.sound').click();
      await page.locator('.tab').nth(3).locator('.sound').click();
      await page.locator('.tile').nth(2).locator('.refresh').click();
      await page.locator('.tile').nth(0).locator('.max').click();
      assert.deepStrictEqual(await calls(page), [['muteTab', 2], ['muteTab', 4], ['autoRefresh', 3, 0], ['maximize', 1]]);
      ok('speaker / refresh tag / enlarge buttons call main — and clicking a tab\'s speaker does not switch tabs');

      await page.locator('.tile').nth(2).locator('.head').dblclick({ position: { x: 120, y: 12 } });
      const dbl = (await calls(page)).filter((x) => x[0] === 'maximize');
      assert.deepStrictEqual(dbl, [['maximize', 3]]);
      await page.locator('.tile').nth(2).locator('.hide').dblclick();
      assert.deepStrictEqual((await calls(page)).filter((x) => x[0] === 'maximize'), [], 'double-clicking a header button is not a maximize');
      ok('double-clicking a tile header maximizes it (but not when double-clicking its buttons)');
    }
    await ctx.close();
  }

  /* ---- 7. 放大單一方塊後 ---- */
  for (const scheme of ['light', 'dark']) {
    const d = build({ W: 1440, H: 860, tabs: T5, activeId: 2, layout: 'grid', maximized: true });
    const { page, ctx, shot } = await open(`7-maximized-${scheme}`, { scheme, data: d });
    await shot();
    if (scheme === 'light') {
      assert.strictEqual(await page.locator('#btn-restore').isVisible(), true);
      assert.strictEqual(await page.locator('.tile').count(), 0);
      assert.strictEqual(await page.evaluate(() => document.body.classList.contains('split')), false);
      assert.strictEqual(await page.locator('.tab.onscreen').count(), 0);
      assert.strictEqual(await page.locator('.tab.parked').count(), 0);
      assert.strictEqual(await page.locator('.layouts button.on').getAttribute('data-layout'), 'grid', 'the chosen layout is still shown');
      await page.locator('#btn-restore').click();
      assert.deepStrictEqual(await calls(page), [['maximize', null]]);
      ok('maximized: tiles disappear, “還原並排” appears in the toolbar and asks main to restore');
    }
    await ctx.close();
  }

  /* ---- 4. 窄視窗 + 上下堆疊 + 很長的標題 ---- */
  {
    const tabs = [mk(1, '這是一個標題非常非常非常非常長長長長長長長長長長長的分頁,用來測試截斷'), mk(2, 'B'), mk(3, 'C'), mk(4, 'D'), mk(5, 'E'), mk(6, 'F'), mk(7, 'G'), mk(8, 'H')];
    const d = build({ W: 1000, H: 640, tabs, activeId: 1, layout: 'rows' });
    const { page, ctx, shot } = await open('4-narrow-rows', { W: 1000, H: 640, data: d });
    await shot();
    const overflow = await page.evaluate(() => ({ x: document.documentElement.scrollWidth - document.documentElement.clientWidth, y: document.documentElement.scrollHeight - document.documentElement.clientHeight }));
    assert.deepStrictEqual(overflow, { x: 0, y: 0 });
    const widths = await page.$$eval('.tab', (els) => els.map((e) => Math.round(e.getBoundingClientRect().width)));
    assert(widths.every((w) => w >= 96), 'tabs keep a minimum width: ' + widths);
    ok('narrow window: no page overflow; with 8 tabs the strip scrolls instead of squashing tabs');
    await ctx.close();
  }

  /* ---- 5. 新分頁頁面 ---- */
  for (const scheme of ['light', 'dark']) {
    const ctx = await browser.newContext({ viewport: { width: 1000, height: 700 }, colorScheme: scheme });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => problems.push(`[newtab] pageerror: ${e.message}`));
    page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) problems.push(`[newtab] console.${m.type()}: ${m.text()}`); });
    await page.goto(NEWTAB);
    await page.screenshot({ path: path.join(OUT, `5-newtab-${scheme}.png`) });
    if (scheme === 'light') {
      await page.locator('#q').fill('今天天氣');
      const nav = page.waitForRequest((r) => r.url().includes('google.com/search'), { timeout: 3000 }).catch(() => null);
      await page.locator('#q').press('Enter');
      const req = await nav;
      assert(req && req.url().includes(encodeURIComponent('今天天氣')), 'search goes to the search engine');
      ok('new-tab page: search box navigates to the search URL');
    }
    await ctx.close();
  }

  await browser.close();
  const csp = problems.filter((p) => /Content Security Policy|Refused/i.test(p));
  console.log(`\n${checks} checks passed`);
  const real = problems.filter((p) => !/net::ERR_|Failed to load resource/.test(p));
  if (real.length) { console.log('\nPROBLEMS:\n' + real.join('\n')); process.exit(1); }
  if (csp.length) { console.log('CSP:\n' + csp.join('\n')); process.exit(1); }
  console.log('no console errors / page errors / CSP violations');
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });

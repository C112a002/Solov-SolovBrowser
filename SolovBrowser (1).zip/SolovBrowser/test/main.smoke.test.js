'use strict';
/* 用「假的 electron 模組」把 main.js 實際跑一遍,驗證主程序流程(不需要真的 Electron)。 */
const assert = require('assert');
const Module = require('module');
const EventEmitter = require('events');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { pathToFileURL } = require('url');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mv-smoke-'));
const { computeLayout } = require('../lib/layout');
const { ERR_PREFIX } = require('../lib/scriptwrap');

let wcSeq = 1;
class FakeWC extends EventEmitter {
  constructor() {
    super();
    this.id = wcSeq++; this._url = ''; this._title = ''; this._loading = false; this._destroyed = false;
    this.executed = []; this.sent = []; this.loaded = []; this.zoom = 0; this.reloads = 0; this.nextResult = undefined;
    this.navigationHistory = { canGoBack: () => false, canGoForward: () => false, goBack() {}, goForward() {} };
  }
  isDestroyed() { return this._destroyed; }
  getURL() { return this._url; } getTitle() { return this._title; } isLoading() { return this._loading; }
  loadURL(u) { this._url = u; this._loading = true; this.loaded.push(u); return Promise.resolve(); }
  loadFile(f) { this._url = pathToFileURL(f).href; this._loading = true; this.loaded.push(f); return Promise.resolve(); }
  setWindowOpenHandler(fn) { this.openHandler = fn; }
  executeJavaScript(code) { this.executed.push(code); return Promise.resolve(this.nextResult); }
  focus() { this.focused = true; this.emit('focus'); }
  close() { this._destroyed = true; }
  send(ch, payload) { this.sent.push([ch, payload]); }
  setZoomLevel(z) { this.zoom = z; } getZoomLevel() { return this.zoom; }
  reload() { this.reloads++; } reloadIgnoringCache() { this.reloads++; } stop() {}
  setVisualZoomLevelLimits() { return Promise.resolve(); }
  isCurrentlyAudible() { return !!this._audible; } isAudioMuted() { return !!this._muted; } setAudioMuted(v) { this._muted = !!v; }
  isDevToolsOpened() { return !!this.devtools; } openDevTools() { this.devtools = true; } closeDevTools() { this.devtools = false; }
  inspectElement() {} copy() {} cut() {} paste() {} undo() {} redo() {} selectAll() {} downloadURL() {}
}
class FakeView { constructor(o) { this.opts = o; this.webContents = new FakeWC(); this.bounds = null; this.visible = true; }
  setBounds(b) { this.bounds = b; } setVisible(v) { this.visible = v; } }
const windows = [];
class FakeWin extends EventEmitter {
  constructor(o) {
    super(); this.opts = o; this.webContents = new FakeWC(); this.children = []; this._size = [1400, 860]; this._destroyed = false;
    this.contentView = { addChildView: (v) => this.children.push(v), removeChildView: (v) => { this.children = this.children.filter((c) => c !== v); } };
    windows.push(this);
  }
  isDestroyed() { return this._destroyed; } getContentSize() { return this._size; }
  loadFile(f) { this.loaded = f; return Promise.resolve(); }
  show() { this.shown = true; } isVisible() { return !!this.shown; }
  maximize() {} isMaximized() { return false; } isMinimized() { return !!this.min; } restore() {} focus() {}
  getNormalBounds() { return { x: 0, y: 0, width: this._size[0], height: this._size[1] }; }
  setTitle(t) { this.title = t; } isFullScreen() { return !!this.fs; } setFullScreen(v) { this.fs = v; }
}
const ipcOn = new Map(); const ipcHandle = new Map();
let lastMenu = null; const boxes = []; let permHandler = null;
const fake = {
  app: Object.assign(new EventEmitter(), {
    whenReady: () => Promise.resolve(), getPath: () => tmp, requestSingleInstanceLock: () => true,
    quit() { this.quitted = true; }, setAppUserModelId() {}, userAgentFallback: '',
  }),
  BrowserWindow: FakeWin, WebContentsView: FakeView,
  ipcMain: { on: (c, f) => ipcOn.set(c, f), handle: (c, f) => ipcHandle.set(c, f) },
  Menu: { setApplicationMenu() {}, buildFromTemplate: (tpl) => ({ tpl, popup() { lastMenu = tpl; } }) },
  session: { defaultSession: { setUserAgent(ua) { this.ua = ua; }, setPermissionRequestHandler(f) { permHandler = f; }, setPermissionCheckHandler() {} } },
  shell: { openExternal: () => Promise.resolve() },
  dialog: {
    showMessageBox: (...a) => { boxes.push(a); return Promise.resolve({ response: 0 }); },
    showMessageBoxSync: () => 0, showOpenDialog: () => Promise.resolve({ canceled: true, filePaths: [] }),
  },
  clipboard: { copied: [], writeText(t) { this.copied.push(t); return Promise.resolve(); } },
  nativeTheme: { shouldUseDarkColors: false },
};
const origLoad = Module._load;
Module._load = function (req) { return req === 'electron' ? fake : origLoad.apply(this, arguments); };

const flush = (ms = 200) => new Promise((r) => setTimeout(r, ms));
const send = (win, ch, ...a) => { const f = ipcOn.get(ch); assert(f, 'no ipc ' + ch); f({ sender: win.webContents }, ...a); };
const invoke = (win, ch, ...a) => ipcHandle.get(ch)({ sender: win.webContents }, ...a);
const lastState = (win) => { const s = win.webContents.sent.filter(([c]) => c === 'state'); return s[s.length - 1][1]; };
const lastScripts = (win) => { const s = win.webContents.sent.filter(([c]) => c === 'scripts'); return s.length ? s[s.length - 1][1] : null; };
let checks = 0; const ok = (name) => { checks++; console.log('  ok  ' + name); };
const key = (k, o = {}) => ({ type: 'keyDown', key: k, control: false, meta: false, shift: false, alt: false, ...o });
const press = (wc, input) => { let prevented = false; wc.emit('before-input-event', { preventDefault() { prevented = true; } }, input); return prevented; };

(async () => {
  require('../main.js');
  await flush(50);
  const win = windows[0];
  assert(win, 'window created');
  assert.strictEqual(win.opts.webPreferences.contextIsolation, true);
  assert.strictEqual(win.opts.webPreferences.sandbox, true);
  assert.strictEqual(win.opts.webPreferences.nodeIntegration, false);
  assert(!/Electron\//.test(fake.session.defaultSession.ua) && /Chrome\/\d+/.test(fake.session.defaultSession.ua));
  ok('window created with isolated/sandboxed UI and a clean user agent');

  const init = await invoke(win, 'ui:ready');
  assert.strictEqual(init.state.tabs.length, 0);
  assert.strictEqual(init.scripts.length, 1);
  assert.strictEqual(init.scripts[0].enabled, false);
  assert(init.scripts[0].code.includes('__multiview_demo_badge'));
  ok('first run seeds one disabled demo script');

  // 其他來源的 IPC 要被擋下
  ipcOn.get('tab:new')({ sender: new FakeWC() });
  await flush(30);
  assert.strictEqual(windows[0].children.length, 0);
  ok('IPC from a non-UI sender is ignored');

  win.webContents.emit('did-finish-load');   // → restoreSession
  await flush(50);
  assert.strictEqual(win.children.length, 1);
  let st = lastState(win);
  assert.strictEqual(st.tabs.length, 1);
  assert.deepStrictEqual(win.children[0].bounds, { x: 0, y: 82, width: 1400, height: 778 });
  assert.strictEqual(st.tiles.length, 0);
  ok('first tab fills the whole content area (no tile frame when only one tab)');

  // 新增分頁 → grid 自動並排
  send(win, 'tab:new');
  await flush(50);
  st = lastState(win);
  assert.strictEqual(st.tabs.length, 2);
  assert.strictEqual(st.tiles.length, 2);
  let lay = computeLayout({ width: 1400, height: 860, chromeH: 82, panelW: 0, count: 2, layout: 'grid' });
  win.children.forEach((v, i) => {
    assert.deepStrictEqual(v.bounds, { x: lay.tiles[i].view.x, y: lay.tiles[i].view.y, width: lay.tiles[i].view.w, height: lay.tiles[i].view.h });
    assert.strictEqual(v.visible, true);
  });
  assert(lay.tiles[0].view.x + lay.tiles[0].view.w < lay.tiles[1].view.x, 'side by side');
  ok('second tab auto-tiles next to the first (native views, side by side)');

  const [v1, v2] = win.children; const t1 = v1.webContents; const t2 = v2.webContents;
  assert.strictEqual(st.activeId, st.tabs[1].id);

  // 位址列導覽
  send(win, 'nav:go', 'example.com');
  assert.strictEqual(t2.loaded[t2.loaded.length - 1], 'https://example.com');
  assert.strictEqual(lastState(win).tabs.find((x) => x.id === lastState(win).activeId).url, 'https://example.com', 'pending URL is shown right away');
  send(win, 'nav:go', 'hello world');
  assert(t2.loaded[t2.loaded.length - 1].startsWith('https://www.google.com/search?q=hello%20world'));
  ok('address bar navigates the active tab (URL or search)');

  // 點到網頁內容 → 該分頁成為使用中
  const idOf = (wc) => lastState(win).tabs[win.children.findIndex((v) => v.webContents === wc)].id;
  ipcOn.get('tab:interact')({ sender: t1 });
  await flush(30);
  assert.strictEqual(lastState(win).activeId, idOf(t1));
  t2.emit('focus');
  assert.strictEqual(lastState(win).activeId, idOf(t2));
  ok('clicking/focusing a page makes that tab the active one');

  // 腳本:停用時不執行;啟用後套用到所有「顯示中、可執行」的分頁
  t1._url = 'https://a.example/'; t1.emit('did-navigate'); t1.emit('dom-ready');
  t2._url = 'https://b.example/'; t2.emit('did-navigate'); t2.emit('dom-ready');
  await flush(50);
  assert.strictEqual(t1.executed.length + t2.executed.length, 0);
  ok('disabled scripts do not run');

  send(win, 'scripts:toggle', 'demo-badge', true);
  await flush(200);
  assert.strictEqual(t1.executed.length, 1);
  assert.strictEqual(t2.executed.length, 1);
  assert(t1.executed[0].includes('__multiview_demo_badge') && t1.executed[0].startsWith('(async () => {'));
  assert.strictEqual(lastScripts(win)[0].status.runs, 2);
  assert.strictEqual(lastScripts(win)[0].status.lastOk, true);
  ok('enabling a script runs it immediately on every displayed tab');

  win.emit('resize'); win.emit('resize'); await flush(50);
  assert.strictEqual(t1.executed.length, 1);
  ok('layout changes / resizes do not re-run scripts that already ran');

  // 第三個分頁:載入完成後自動套用
  send(win, 'tab:new'); await flush(50);
  const t3 = win.children[2].webContents;
  assert.strictEqual(lastState(win).tiles.length, 3);
  assert.strictEqual(t3.executed.length, 0, 'internal new-tab page is skipped');
  t3.emit('dom-ready'); await flush(50);
  assert.strictEqual(t3.executed.length, 0);
  t3._url = 'https://c.example/'; t3.emit('did-navigate'); t3.emit('dom-ready'); await flush(150);
  assert.strictEqual(t3.executed.length, 1);
  ok('a newly loaded page gets enabled scripts automatically; the built-in new-tab page is skipped');

  // 換頁(重新載入)→ 重新套用
  t1.emit('did-navigate'); t1.emit('dom-ready'); await flush(150);
  assert.strictEqual(t1.executed.length, 2);
  ok('navigating/reloading re-applies enabled scripts to that tab');

  // 編輯程式碼 → 已啟用腳本重新套用到所有顯示中的分頁
  const base = [t1, t2, t3].map((t) => t.executed.length);
  const res = await invoke(win, 'scripts:save', { id: 'demo-badge', name: 'demo', code: 'console.log(1)' });
  assert.strictEqual(res.enabled, true);
  await flush(200);
  [t1, t2, t3].forEach((t, i) => assert.strictEqual(t.executed.length, base[i] + 1));
  assert(t1.executed[t1.executed.length - 1].includes('console.log(1)'));
  ok('saving new code re-runs the script on all displayed tabs');

  // 新增腳本(預設啟用)
  const created = await invoke(win, 'scripts:save', { id: null, name: '', code: 'document.title += "!"', enabled: true });
  await flush(200);
  const list = lastScripts(win);
  assert.strictEqual(list.length, 2);
  assert.strictEqual(list[1].name, '未命名腳本');
  assert.strictEqual(t3.executed.length, base[2] + 2);
  ok('a new script is created, persisted and applied right away');
  const persisted = JSON.parse(fs.readFileSync(path.join(tmp, 'scripts.json'), 'utf8'));
  assert.strictEqual(persisted.length, 2);
  ok('scripts are written to scripts.json');

  // 錯誤回報
  t1.nextResult = ERR_PREFIX + 'ReferenceError: foo is not defined\n    at <anonymous>:1:1';
  send(win, 'scripts:run', created.id); await flush(200);
  let s2 = lastScripts(win).find((s) => s.id === created.id);
  assert(s2.status.lastError.startsWith('ReferenceError: foo is not defined'));
  assert(s2.status.errors >= 1 && s2.status.runs > s2.status.errors, 'one tab failed, the others succeeded');
  assert(s2.status.lastTab, 'remembers which tab failed');
  t1.nextResult = undefined;
  ok('script errors are surfaced to the panel');

  // 停用 → 不再自動套用;再啟用 → 重新套用
  send(win, 'scripts:toggle', created.id, false); await flush(50);
  const n3 = t3.executed.length;
  t3.emit('did-navigate'); t3.emit('dom-ready'); await flush(100);
  assert.strictEqual(t3.executed.length, n3 + 1, 'only the other (still enabled) script runs');
  send(win, 'scripts:toggle', created.id, true); await flush(150);
  assert.strictEqual(t3.executed.length, n3 + 2);
  ok('disable stops auto-apply; re-enable applies again');

  // 版面切換:single 只顯示使用中的分頁
  const act = lastState(win).activeId;
  send(win, 'layout:set', 'single'); await flush(50);
  st = lastState(win);
  assert.strictEqual(st.layout, 'single'); assert.strictEqual(st.tiles.length, 0);
  const visibleNow = win.children.filter((v) => v.visible);
  assert.strictEqual(visibleNow.length, 1);
  assert.strictEqual(win.children.findIndex((v) => v.visible), st.tabs.findIndex((t) => t.id === act));
  assert.deepStrictEqual(visibleNow[0].bounds, { x: 0, y: 82, width: 1400, height: 778 });
  ok('single layout shows only the active tab, full size');

  // 在 single 底下,被隱藏的分頁不會被套用腳本
  const hiddenWc = win.children.find((v) => !v.visible).webContents;
  const hn = hiddenWc.executed.length;
  hiddenWc.emit('did-navigate'); hiddenWc.emit('dom-ready'); await flush(100);
  assert.strictEqual(hiddenWc.executed.length, hn);
  ok('scripts are NOT applied to tabs that are not displayed');
  // 切回 grid → 這個分頁變成顯示 → 補套用
  send(win, 'layout:set', 'grid'); await flush(150);
  assert.strictEqual(win.children.every((v) => v.visible), true);
  assert(hiddenWc.executed.length > hn);
  ok('when a tab becomes displayed, enabled scripts are applied to it');

  // 從畫面隱藏 / 顯示
  const idB = lastState(win).tabs[0].id;
  send(win, 'tab:toggle-shown', idB); await flush(50);
  st = lastState(win);
  assert.strictEqual(st.tabs[0].shown, false);
  assert.strictEqual(win.children[0].visible, false);
  assert.strictEqual(st.tiles.length, 2);
  send(win, 'tab:toggle-shown', idB); await flush(50);
  assert.strictEqual(lastState(win).tabs[0].shown, true);
  ok('hide-from-view / show-in-view works');
  // 最後一個顯示中的分頁不能被隱藏
  send(win, 'layout:set', 'cols');
  lastState(win).tabs.forEach((t) => send(win, 'tab:toggle-shown', t.id)); await flush(50);
  assert.strictEqual(lastState(win).tabs.filter((t) => t.shown).length, 1);
  send(win, 'tab:menu', lastState(win).tabs[0].id);
  assert(lastMenu.some((i) => i.label === '顯示所有分頁' && i.enabled));
  lastMenu.find((i) => i.label === '顯示所有分頁').click(); await flush(50);
  assert.strictEqual(lastState(win).tabs.every((t) => t.shown), true);
  ok('cannot hide the last displayed tab; context menu can show all again');

  // 擴充功能面板開啟 → 版面讓出 420px
  send(win, 'layout:set', 'grid');
  send(win, 'panel:set', true); await flush(50);
  assert.strictEqual(lastState(win).panelOpen, true);
  lay = computeLayout({ width: 1400, height: 860, chromeH: 82, panelW: 420, count: 3, layout: 'grid' });
  win.children.forEach((v, i) => assert.strictEqual(v.bounds.x + v.bounds.width <= 1400 - 420, true));
  assert.deepStrictEqual(win.children[0].bounds, { x: lay.tiles[0].view.x, y: lay.tiles[0].view.y, width: lay.tiles[0].view.w, height: lay.tiles[0].view.h });
  send(win, 'panel:set', false); await flush(30);
  ok('opening the extensions panel shrinks the tiled area (pages stay visible next to it)');

  // 全螢幕影片
  const fsWc = win.children[1].webContents;
  fsWc.emit('enter-html-full-screen'); await flush(30);
  assert.deepStrictEqual(win.children[1].bounds, { x: 0, y: 0, width: 1400, height: 860 });
  assert.deepStrictEqual(win.children.map((v) => v.visible), [false, true, false]);
  fsWc.emit('leave-html-full-screen'); await flush(30);
  assert.strictEqual(win.children.every((v) => v.visible), true);
  ok('HTML fullscreen: that tab covers the window, others hidden, then restored');

  // 快速鍵
  const n0 = win.children.length;
  assert.strictEqual(press(win.webContents, key('t', { control: true })), true); await flush(30);
  assert.strictEqual(win.children.length, n0 + 1);
  const fresh = win.children[win.children.length - 1].webContents;   // Ctrl+T 開的分頁會成為使用中
  fresh._url = 'https://closeme.example/'; fresh.emit('did-navigate');
  assert.strictEqual(press(win.children[0].webContents, key('w', { control: true })), true); await flush(30);
  assert.strictEqual(win.children.length, n0, 'Ctrl+W closes the ACTIVE tab');
  assert(!win.children.some((v) => v.webContents === fresh));
  const a1 = lastState(win).activeId;
  press(win.webContents, key('Tab', { control: true })); await flush(30);
  assert.notStrictEqual(lastState(win).activeId, a1);
  press(win.webContents, key('Tab', { control: true, shift: true })); await flush(30);
  assert.strictEqual(lastState(win).activeId, a1);
  press(win.webContents, key('x', { control: true, shift: true })); await flush(30);
  assert.strictEqual(lastState(win).panelOpen, true);
  press(win.webContents, key('x', { control: true, shift: true })); await flush(30);
  assert.strictEqual(lastState(win).panelOpen, false);
  press(win.webContents, key('g', { control: true, shift: true })); await flush(30);
  assert.strictEqual(lastState(win).layout, 'cols');
  press(win.webContents, key('t', { control: true, shift: true })); await flush(30);
  assert.strictEqual(win.children.length, n0 + 1, 'reopen closed tab');
  assert.strictEqual(win.children[win.children.length - 1].webContents.loaded[0], 'https://closeme.example/');
  assert.strictEqual(press(win.webContents, key('a', { control: true })), false);
  ok('shortcuts: new/close/cycle/panel/layout/reopen; unrelated keys are left alone');
  send(win, 'layout:set', 'grid');

  // window.open → 新分頁
  const n1 = win.children.length;
  const ret = t1.openHandler({ url: 'https://popup.example/', disposition: 'foreground-tab' });
  assert.deepStrictEqual(ret, { action: 'deny' });
  await flush(30);
  assert.strictEqual(win.children.length, n1 + 1);
  const strip = lastState(win).tabs;
  const opener = strip.findIndex((x) => x.id === idOf(t1));
  assert.strictEqual(strip[opener + 1].url, 'https://popup.example/', 'popup tab sits right after its opener in the tab strip');
  t1.openHandler({ url: 'javascript:alert(1)', disposition: 'foreground-tab' });
  assert.strictEqual(win.children.length, n1 + 1);
  ok('window.open / target=_blank opens a new tab next to the opener; javascript: is refused');

  // 右鍵選單
  t1.emit('context-menu', {}, { linkURL: 'https://l.example/', x: 3, y: 4, editFlags: {} });
  assert(lastMenu.some((i) => i.label === '在新分頁開啟連結') && lastMenu.some((i) => i.label === '檢查元素'));
  const c0 = win.children.length;
  lastMenu.find((i) => i.label === '在新分頁開啟連結').click();
  assert.strictEqual(win.children.length, c0 + 1);
  lastMenu.find((i) => i.label === '複製連結網址') || t1.emit('context-menu', {}, { linkURL: 'https://l.example/', x: 0, y: 0, editFlags: {} });
  lastMenu.find((i) => i.label === '複製連結網址').click();
  await flush(10);
  assert.deepStrictEqual(fake.clipboard.copied, ['https://l.example/']);
  ok('page context menu: open link in new tab / copy link');

  // 權限
  let answered = []; permHandler(t1, 'media', (v) => answered.push(v), { requestingUrl: 'https://meet.example/x' }); await flush(30);
  permHandler(t1, 'media', (v) => answered.push(v), { requestingUrl: 'https://meet.example/y' }); await flush(30);
  permHandler(t1, 'usb', (v) => answered.push(v), { requestingUrl: 'https://meet.example/y' });
  permHandler(t1, 'fullscreen', (v) => answered.push(v), { requestingUrl: 'https://meet.example/y' });
  assert.deepStrictEqual(answered, [true, true, false, true]);
  assert.strictEqual(boxes.length, 1, 'asked once, then remembered');
  ok('permissions: ask once for camera/mic, deny unknown ones, allow fullscreen');

  // ── 匯入腳本(檔案對話框)
  const importFile = path.join(tmp, 'my-script.js');
  fs.writeFileSync(importFile, '\uFEFF// ==UserScript==\n// @name  從檔案匯入的腳本\n// ==/UserScript==\nconsole.log("hi");');
  fake.dialog.showOpenDialog = () => Promise.resolve({ canceled: false, filePaths: [importFile] });
  const nBefore = lastScripts(win).length;
  send(win, 'scripts:import'); await flush(300);
  const afterImport = lastScripts(win);
  assert.strictEqual(afterImport.length, nBefore + 1);
  const imp = afterImport[afterImport.length - 1];
  assert.strictEqual(imp.name, '從檔案匯入的腳本');
  assert.strictEqual(imp.enabled, false, 'imported scripts start disabled');
  assert(!imp.code.startsWith('\uFEFF'), 'BOM stripped');
  assert(win.webContents.sent.some(([c, m]) => c === 'note' && /已匯入 1 個腳本/.test(m)));
  const tBefore = win.children.map((v) => v.webContents.executed.length);
  await flush(100);
  assert.deepStrictEqual(win.children.map((v) => v.webContents.executed.length), tBefore, 'imported script did not run by itself');
  ok('import .js: BOM stripped, @name used, starts disabled and does not run until enabled');

  // ── 分頁右鍵選單的每個項目
  while (win.children.length > 1) send(win, 'tab:close', lastState(win).tabs[0].id);
  for (let i = 0; i < 3; i++) { send(win, 'tab:new'); await flush(20); }
  lastState(win).tabs.forEach((tb, i) => {
    const w = win.children[i].webContents; w._url = `https://m${i}.example/`; w.emit('did-navigate'); w.emit('dom-ready');
  });
  await flush(60);
  const ids = lastState(win).tabs.map((x) => x.id);
  send(win, 'tab:menu', ids[1]);
  ['重新整理', '複製分頁', '複製網址', '關閉分頁', '關閉其他分頁', '關閉右側分頁', '只顯示這個分頁', '顯示所有分頁'].forEach((label) => assert(lastMenu.some((i) => i.label === label), 'menu has ' + label));
  const nTabs = win.children.length;
  lastMenu.find((i) => i.label === '複製分頁').click(); await flush(30);
  assert.strictEqual(win.children.length, nTabs + 1);
  const dupIdx = lastState(win).tabs.findIndex((x) => x.id === ids[1]) + 1;
  assert.strictEqual(lastState(win).tabs[dupIdx].url, 'https://m1.example/', 'duplicate sits next to the original');
  send(win, 'tab:menu', ids[1]);
  lastMenu.find((i) => i.label === '複製網址').click(); await flush(10);
  assert.strictEqual(fake.clipboard.copied.pop(), 'https://m1.example/');
  send(win, 'tab:menu', ids[1]);
  lastMenu.find((i) => i.label === '只顯示這個分頁').click(); await flush(30);
  assert.deepStrictEqual(lastState(win).tabs.filter((x) => x.shown).map((x) => x.id), [ids[1]]);
  assert.strictEqual(lastState(win).activeId, ids[1]);
  send(win, 'tab:menu', ids[1]);
  lastMenu.find((i) => i.label === '關閉右側分頁').click(); await flush(30);
  assert.strictEqual(lastState(win).tabs.length, 2);
  send(win, 'tab:menu', ids[1]);
  lastMenu.find((i) => i.label === '關閉其他分頁').click(); await flush(30);
  assert.deepStrictEqual(lastState(win).tabs.map((x) => x.id), [ids[1]]);
  ok('tab context menu: duplicate, copy URL, show only this, close right, close others');

  // ── 網頁右鍵選單:圖片 / 輸入框 / 選取文字
  const pw = win.children[0].webContents;
  pw.emit('context-menu', {}, { mediaType: 'image', srcURL: 'https://i.example/a.png', x: 1, y: 2, editFlags: {} });
  ['在新分頁開啟圖片', '另存圖片…', '複製圖片網址', '返回', '前進', '重新整理', '檢查元素'].forEach((l) => assert(lastMenu.some((i) => i.label === l), l));
  lastMenu.find((i) => i.label === '另存圖片…').click();
  pw.emit('context-menu', {}, { isEditable: true, x: 0, y: 0, editFlags: { canCopy: true, canPaste: true } });
  ['復原', '重做', '剪下', '複製', '貼上', '全選'].forEach((l) => assert(lastMenu.some((i) => i.label === l), l));
  assert.strictEqual(lastMenu.find((i) => i.label === '貼上').enabled, true);
  assert.strictEqual(lastMenu.find((i) => i.label === '剪下').enabled, false);
  ['貼上', '複製', '全選', '復原', '重做', '剪下'].forEach((l) => lastMenu.find((i) => i.label === l).click());
  pw.emit('context-menu', {}, { selectionText: 'hello world', x: 0, y: 0, editFlags: {} });
  const searchItem = lastMenu.find((i) => i.label === '搜尋「hello world」');
  assert(searchItem);
  const cb = win.children.length; searchItem.click();
  assert.strictEqual(win.children.length, cb + 1);
  assert(win.children[win.children.length - 1].webContents.loaded[0].endsWith('hello%20world'));
  lastMenu.find((i) => i.label === '重新整理') || pw.emit('context-menu', {}, { x: 0, y: 0, editFlags: {} });
  lastMenu.find((i) => i.label === '檢查元素').click();
  ok('page context menu: image / editable field / selected text variants all build and run');

  // ── 其餘分頁事件:不該丟例外
  pw.emit('page-title-updated', {}, '新標題');
  pw.emit('page-favicon-updated', {}, ['https://x.example/favicon.ico']);
  pw.emit('did-start-loading'); pw.emit('did-stop-loading');
  pw.emit('did-navigate-in-page', {}, 'https://m1.example/#a', true);
  pw.emit('did-navigate-in-page', {}, 'https://m1.example/frame', false);
  pw.emit('did-fail-load', {}, -3, 'ABORTED', 'https://x', true);
  pw.emit('did-fail-load', {}, -105, 'NAME_NOT_RESOLVED', 'https://nope.invalid/', true);
  pw.emit('render-process-gone', {}, { reason: 'crashed' });
  await flush(120);
  const sNow = lastState(win).tabs.find((x) => x.id === lastState(win).activeId) || lastState(win).tabs[0];
  assert(lastState(win).tabs.some((x) => x.title === '新標題' && x.favicon === 'https://x.example/favicon.ico'));
  let allowed = false;
  pw.emit('will-prevent-unload', { preventDefault() { allowed = true; } });
  assert.strictEqual(allowed, true, 'beforeunload: user chose to leave → unload is allowed');
  ok('title/favicon/loading/in-page/failed-load/crash events and the beforeunload prompt are handled');

  // ── 第二個執行個體 + 命令列網址
  const c1 = win.children.length;
  fake.app.emit('second-instance', {}, ['SolovBrowser.exe', 'https://second.example/']);
  await flush(30);
  assert.strictEqual(win.children.length, c1 + 1);
  assert.strictEqual(win.children[win.children.length - 1].webContents.loaded[0], 'https://second.example/');
  ok('second instance with a URL opens it in a new tab of the running window');

  /* ════════ 新功能:腳本網址限定 / 放大方塊 / 靜音 / 自動重新整理 ════════ */
  const clearScripts = async () => { for (const sc of lastScripts(win) || []) send(win, 'scripts:remove', sc.id); await flush(30); };
  const closeAllButOne = async () => {
    while (win.children.length > 1) { send(win, 'tab:close', lastState(win).tabs[0].id); await flush(5); }
  };
  const makeTabs = async (urls) => {
    await clearScripts();          // 乾淨的起點:先前測試留下的已啟用腳本不能影響這裡的計數
    await closeAllButOne();
    while (win.children.length < urls.length) { send(win, 'tab:new'); await flush(10); }
    const wcs = win.children.map((v) => v.webContents);
    wcs.forEach((w, i) => { w._loading = false; w._url = urls[i]; w.executed.length = 0; w.emit('did-navigate'); w.emit('dom-ready'); });
    await flush(60);
    return wcs;
  };

  // ── 腳本網址限定
  {
    const [yt, ex, nw] = await makeTabs(['https://www.youtube.com/watch?v=1', 'https://example.com/', 'https://news.example.org/a']);
    send(win, 'layout:set', 'grid');
    await clearScripts();
    const sv = await invoke(win, 'scripts:save', { id: null, name: 'yt only', code: 'console.log(1)', enabled: true, match: 'youtube.com' });
    await flush(150);
    assert.deepStrictEqual([yt, ex, nw].map((w) => w.executed.length), [1, 0, 0]);
    assert.strictEqual(lastScripts(win)[0].match, 'youtube.com');
    assert.strictEqual(lastScripts(win)[0].status.runs, 1, 'skipped tabs are not counted as runs');
    ok('a script limited to youtube.com runs only on the matching displayed tab');

    await invoke(win, 'scripts:save', { id: sv.id, name: 'not yt', code: 'console.log(1)', match: '!youtube.com' });
    await flush(150);
    assert.deepStrictEqual([yt, ex, nw].map((w) => w.executed.length), [1, 1, 1]);
    ok('editing the URL rules re-applies the script, now to the other tabs');

    // 載入新頁面時重新比對
    yt._url = 'https://example.com/other'; yt.emit('did-navigate'); yt.emit('dom-ready'); await flush(100);
    assert.strictEqual(yt.executed.length, 2, 'navigating to a matching URL applies the script');
    nw._url = 'https://www.youtube.com/'; nw.emit('did-navigate'); nw.emit('dom-ready'); await flush(100);
    assert.strictEqual(nw.executed.length, 1, 'navigating to an excluded URL does not');
    ok('URL rules are re-evaluated when a tab loads a new page');

    // 手動執行:沒有符合時要告訴使用者
    await invoke(win, 'scripts:save', { id: sv.id, name: 'none', code: 'console.log(2)', match: 'nomatch.example' });
    await flush(100);
    const notesBefore = win.webContents.sent.filter(([c]) => c === 'note').length;
    const runsBefore = [yt, ex, nw].map((w) => w.executed.length);
    send(win, 'scripts:run', sv.id); await flush(100);
    assert.deepStrictEqual([yt, ex, nw].map((w) => w.executed.length), runsBefore, 'nothing matched → nothing executed');
    const notes = win.webContents.sent.filter(([c]) => c === 'note');
    assert(notes.length === notesBefore + 1 && /沒有符合這個腳本網址限定/.test(notes[notes.length - 1][1]));
    assert.strictEqual(JSON.parse(fs.readFileSync(path.join(tmp, 'scripts.json'), 'utf8'))[0].match, 'nomatch.example');
    ok('manual run respects the URL rules, explains when nothing matched, and the rules are persisted');

    // 匯入:帶入 @match / @exclude
    const f2 = path.join(tmp, 'userscript.js');
    fs.writeFileSync(f2, '// ==UserScript==\n// @name  YT helper\n// @match https://*.youtube.com/*\n// @exclude https://www.youtube.com/shorts/*\n// ==/UserScript==\nconsole.log(3)');
    fake.dialog.showOpenDialog = () => Promise.resolve({ canceled: false, filePaths: [f2] });
    send(win, 'scripts:import'); await flush(200);
    const imp2 = lastScripts(win).find((x) => x.name === 'YT helper');
    assert(imp2 && imp2.enabled === false);
    assert.strictEqual(imp2.match, 'https://*.youtube.com/*, !https://www.youtube.com/shorts/*');
    ok('import: @match / @exclude from a userscript header become the URL rules');
  }

  // ── 放大單一方塊
  {
    const [a, b, c] = await makeTabs(['https://a.example/', 'https://b.example/', 'https://c.example/']);
    send(win, 'layout:set', 'grid'); await clearScripts();
    await invoke(win, 'scripts:save', { id: null, name: 'all', code: '1', enabled: true, match: '' });
    await flush(150);
    assert.deepStrictEqual([a, b, c].map((w) => w.executed.length), [1, 1, 1]);
    const ids = lastState(win).tabs.map((x) => x.id);

    send(win, 'view:maximize', ids[1]); await flush(50);
    let st = lastState(win);
    assert.strictEqual(st.maximized, true); assert.strictEqual(st.activeId, ids[1]); assert.strictEqual(st.tiles.length, 0);
    assert.strictEqual(st.layout, 'grid', 'layout itself is unchanged');
    assert.deepStrictEqual(win.children.map((v) => v.visible), [false, true, false]);
    assert.deepStrictEqual(win.children[1].bounds, { x: 0, y: 82, width: 1400, height: 778 });
    assert.strictEqual(st.displayedCount, 1);
    ok('double-clicking a tile header maximizes that tab: full area, others hidden, layout unchanged');

    // 放大時,沒顯示的分頁不會被套用腳本;還原後補套用
    a.emit('did-navigate'); a.emit('dom-ready'); await flush(100);
    assert.strictEqual(a.executed.length, 1, 'hidden by maximize → not applied');
    press(win.webContents, key('Enter', { control: true, shift: true })); await flush(80);
    st = lastState(win);
    assert.strictEqual(st.maximized, false); assert.strictEqual(st.tiles.length, 3);
    assert(win.children.every((v) => v.visible));
    assert.strictEqual(a.executed.length, 2, 'restored → applied now');
    ok('Ctrl+Shift+Enter restores the tiling; scripts catch up on tabs that were hidden meanwhile');

    // 放大時切換分頁仍維持放大;面板開啟時仍會讓位
    send(win, 'view:maximize', ids[0]); await flush(30);
    press(win.webContents, key('Tab', { control: true })); await flush(30);
    assert.strictEqual(lastState(win).maximized, true);
    assert.strictEqual(lastState(win).activeId, ids[1]);
    send(win, 'tab:activate', ids[2], false); await flush(30);
    assert.strictEqual(lastState(win).activeId, ids[2]); assert.strictEqual(lastState(win).maximized, true);
    send(win, 'panel:set', true); await flush(30);
    assert.deepStrictEqual(win.children[2].bounds, { x: 0, y: 82, width: 1400 - 420, height: 778 });
    send(win, 'panel:set', false);
    ok('while maximized, switching tabs keeps it maximized and the side panel still takes its space');

    // 選配置(即使和現在相同)= 離開放大
    send(win, 'layout:set', 'grid'); await flush(30);
    assert.strictEqual(lastState(win).maximized, false); assert.strictEqual(lastState(win).tiles.length, 3);
    send(win, 'view:maximize', ids[0]); await flush(30);
    send(win, 'tab:menu', ids[0]);
    assert(lastMenu.some((i) => i.label === '還原並排顯示' && i.enabled));
    lastMenu.find((i) => i.label === '還原並排顯示').click(); await flush(30);
    assert.strictEqual(lastState(win).maximized, false);
    send(win, 'tab:menu', ids[2]);
    lastMenu.find((i) => i.label === '放大這個分頁').click(); await flush(30);
    assert.strictEqual(lastState(win).maximized, true); assert.strictEqual(lastState(win).activeId, ids[2]);
    send(win, 'layout:set', 'cols'); await flush(30);
    assert.strictEqual(lastState(win).maximized, false);
    ok('picking a layout exits maximize; the tab menu offers 放大 / 還原');

    // 沒東西可放大:單一分頁配置、或畫面上只有一個
    send(win, 'layout:set', 'single'); send(win, 'view:maximize', ids[0]); await flush(30);
    assert.strictEqual(lastState(win).maximized, false);
    send(win, 'layout:set', 'grid');
    ids.slice(1).forEach((id) => send(win, 'tab:toggle-shown', id)); await flush(30);
    assert.strictEqual(lastState(win).tabs.filter((x) => x.shown).length, 1);
    send(win, 'view:maximize', ids[0]); await flush(30);
    assert.strictEqual(lastState(win).maximized, false);
    send(win, 'tab:menu', ids[0]);
    assert.strictEqual(lastMenu.find((i) => i.label === '放大這個分頁').enabled, false);
    ids.slice(1).forEach((id) => send(win, 'tab:toggle-shown', id)); await flush(30);
    ok('nothing to maximize in single layout or with only one tab on screen');

    // 放大期間把其他分頁關到只剩一個 → 自動離開放大
    send(win, 'view:maximize', ids[0]); await flush(30);
    assert.strictEqual(lastState(win).maximized, true);
    send(win, 'tab:close', ids[1]); await flush(30);
    assert.strictEqual(lastState(win).maximized, true, 'two tabs left: still maximized');
    send(win, 'tab:close', ids[2]); await flush(30);
    assert.strictEqual(lastState(win).maximized, false, 'one tab left: nothing to restore');
    assert.strictEqual(lastState(win).tabs.length, 1);
    ok('closing tabs until only one is left leaves maximize automatically');
  }

  // ── 靜音與聲音指示
  {
    const [a, b, c] = await makeTabs(['https://a.example/', 'https://b.example/', 'https://c.example/']);
    send(win, 'layout:set', 'grid'); await flush(30);
    const ids = lastState(win).tabs.map((x) => x.id);
    b._audible = true; c._audible = true;
    await flush(1800);                                  // 定時檢查(每 1.5 秒)
    let st = lastState(win);
    assert.deepStrictEqual(st.tabs.map((x) => x.audible), [false, true, true]);
    assert.deepStrictEqual(st.tabs.map((x) => x.muted), [false, false, false]);
    ok('audio polling marks tabs that are making sound');

    send(win, 'tab:mute', ids[1]); await flush(30);
    assert.strictEqual(b._muted, true);
    assert.strictEqual(lastState(win).tabs[1].muted, true);
    send(win, 'tab:mute', ids[1]); await flush(30);
    assert.strictEqual(b._muted, false); assert.strictEqual(lastState(win).tabs[1].muted, false);
    ok('mute toggles the tab\'s audio');

    send(win, 'tab:menu', ids[2]);
    assert(lastMenu.some((i) => i.label === '靜音這個分頁'));
    lastMenu.find((i) => i.label === '只播放這個分頁的聲音').click(); await flush(30);
    assert.deepStrictEqual([a, b, c].map((w) => w._muted), [true, true, false]);
    assert.deepStrictEqual(lastState(win).tabs.map((x) => x.muted), [true, true, false]);
    send(win, 'tab:menu', ids[0]);
    assert(lastMenu.some((i) => i.label === '取消靜音'));
    lastMenu.find((i) => i.label === '取消所有分頁的靜音').click(); await flush(30);
    assert.deepStrictEqual([a, b, c].map((w) => w._muted), [false, false, false]);
    ok('“only play this tab” mutes the rest; “unmute all” undoes it');

    c._audible = false; c.emit('audio-state-changed'); await flush(80);
    assert.strictEqual(lastState(win).tabs[2].audible, false);
    ok('the audio-state-changed event updates the indicator immediately');
  }

  // ── 自動重新整理
  {
    const [a, b, c] = await makeTabs(['https://a.example/', 'https://b.example/', 'https://c.example/']);
    send(win, 'layout:set', 'grid'); await flush(30);
    const ids = lastState(win).tabs.map((x) => x.id);
    const captured = []; const realSI = global.setInterval;
    global.setInterval = (fn, ms) => { const h = realSI(() => {}, 2147483647); captured.push({ fn, ms, h }); return h; };
    try {
      send(win, 'tab:menu', ids[0]);
      const sub = lastMenu.find((i) => i.label === '自動重新整理');
      assert(sub && sub.enabled && sub.submenu.length === 6);
      assert.deepStrictEqual(sub.submenu.map((i) => i.label), ['關閉', '每 10 秒', '每 30 秒', '每 1 分鐘', '每 5 分鐘', '每 15 分鐘']);
      assert(sub.submenu[0].checked && sub.submenu.slice(1).every((i) => !i.checked));
      sub.submenu[2].click(); await flush(30);
      assert.strictEqual(lastState(win).tabs[0].refreshSec, 30);
      assert.strictEqual(captured.length, 1); assert.strictEqual(captured[0].ms, 30000);
      send(win, 'tab:menu', ids[0]);
      assert(lastMenu.find((i) => i.label === '自動重新整理').submenu[2].checked, 'current choice is checked');
      ok('tab menu → auto refresh: choices, current value checked, interval created');

      const tick = () => captured[captured.length - 1].fn();
      a._loading = false;
      const r0 = a.reloads; tick(); assert.strictEqual(a.reloads, r0 + 1, 'reloads a displayed, idle tab');
      a._loading = true; tick(); assert.strictEqual(a.reloads, r0 + 1, 'not while it is still loading'); a._loading = false;
      win.min = true; tick(); assert.strictEqual(a.reloads, r0 + 1, 'not while the window is minimized'); win.min = false;
      a.emit('enter-html-full-screen'); await flush(20); tick(); assert.strictEqual(a.reloads, r0 + 1, 'not in HTML fullscreen'); a.emit('leave-html-full-screen'); await flush(20);
      send(win, 'tab:toggle-shown', ids[0]); await flush(20); tick();
      assert.strictEqual(a.reloads, r0 + 1, 'not while the tab is hidden from the screen');
      send(win, 'tab:toggle-shown', ids[0]); await flush(20);
      send(win, 'layout:set', 'single'); send(win, 'tab:activate', ids[1], false); await flush(30); tick();
      assert.strictEqual(a.reloads, r0 + 1, 'not while it is not displayed (single layout)');
      send(win, 'layout:set', 'grid'); await flush(30); tick();
      assert.strictEqual(a.reloads, r0 + 2, 'resumes once displayed again');
      ok('ticks reload only displayed, idle tabs (not loading / minimized / fullscreen / hidden)');

      // 在新頁面載入後,腳本照常重新套用
      send(win, 'layout:set', 'grid');
      await clearScripts();
      await invoke(win, 'scripts:save', { id: null, name: 'auto', code: '1', enabled: true, match: '' }); await flush(100);
      const e0 = a.executed.length; a.emit('did-navigate'); a.emit('dom-ready'); await flush(80);
      assert.strictEqual(a.executed.length, e0 + 1);
      ok('after an auto reload the user scripts are applied again');

      // 存檔、關閉、無效秒數
      win.emit('close');
      const cfg = JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8'));
      assert.deepStrictEqual(cfg.tabs.map((x) => x.refresh), [30, 0, 0]);
      ok('auto-refresh interval is saved per tab');
      send(win, 'tab:auto-refresh', ids[1], 7); await flush(20);
      assert.strictEqual(lastState(win).tabs[1].refreshSec, 0, 'unsupported interval is ignored');
      send(win, 'tab:auto-refresh', ids[1], 900); await flush(20);
      assert.strictEqual(lastState(win).tabs[1].refreshSec, 900);
      send(win, 'tab:auto-refresh', ids[1], 0); await flush(20);
      assert.strictEqual(lastState(win).tabs[1].refreshSec, 0);
      const staleTick = tick; const rBefore = a.reloads;
      send(win, 'tab:close', ids[0]); await flush(20);
      staleTick(); assert.strictEqual(a.reloads, rBefore, 'a closed tab is never reloaded');
      ok('invalid seconds are ignored, turning it off works, and closing a tab stops its timer');

      // 新分頁頁面不能設定
      send(win, 'tab:new'); await flush(30);
      const nid = lastState(win).tabs[lastState(win).tabs.length - 1].id;
      send(win, 'tab:menu', nid);
      assert.strictEqual(lastMenu.find((i) => i.label === '自動重新整理').enabled, false);
      ok('the built-in new-tab page cannot be auto-refreshed');
    } finally { global.setInterval = realSI; }
  }

  // 關到剩一個、再關掉最後一個 → 自動開新分頁
  while (win.children.length > 1) send(win, 'tab:close', lastState(win).tabs[0].id);
  await flush(30);
  send(win, 'tab:close', lastState(win).tabs[0].id); await flush(50);
  assert.strictEqual(win.children.length, 1);
  assert.strictEqual(lastState(win).tabs[0].internal, true);
  ok('closing the last tab opens a fresh new-tab page instead of leaving nothing');

  // 起始頁自訂背景(選圖片 / 影片、清理舊檔)
  {
    const pick = ipcHandle.get('newtab:bg-pick'); const prune = ipcHandle.get('newtab:bg-prune');
    assert(pick && prune, 'background IPC handlers are registered');
    const newtabWc = win.children[0].webContents;
    assert(/renderer\/newtab\.html$/.test(newtabWc.getURL()));
    const bgDir = path.join(tmp, 'backgrounds');
    const realOpen = fake.dialog.showOpenDialog;
    const choose = (file) => { fake.dialog.showOpenDialog = () => Promise.resolve(file ? { canceled: false, filePaths: [file] } : { canceled: true, filePaths: [] }); };
    try {
      // 只有「顯示起始頁」的頂層分頁可以呼叫
      const web = new FakeWC(); web._url = 'https://example.com/';
      assert.throws(() => pick({ sender: web }), /forbidden/);
      assert.throws(() => prune({ sender: web }, ''), /forbidden/);
      assert.throws(() => pick({ sender: win.webContents }), /forbidden/);
      const sub = newtabWc; sub.mainFrame = { top: true };
      assert.throws(() => pick({ sender: sub, senderFrame: { top: false } }), /forbidden/);
      ok('background IPC refuses web pages, the toolbar UI and iframes');

      choose(null);
      assert.deepStrictEqual(await pick({ sender: newtabWc, senderFrame: sub.mainFrame }), { ok: false, canceled: true });
      ok('cancelling the file dialog changes nothing');

      const bad = path.join(tmp, 'virus.exe'); fs.writeFileSync(bad, 'x');
      choose(bad);
      let r = await pick({ sender: newtabWc });
      assert.strictEqual(r.ok, false); assert(r.error && !fs.existsSync(bgDir) || fs.readdirSync(bgDir).length === 0);
      ok('unsupported file types are rejected');

      const png = path.join(tmp, 'wall.PNG'); fs.writeFileSync(png, Buffer.from([1, 2, 3, 4]));
      const mp4 = path.join(tmp, 'loop.mp4'); fs.writeFileSync(mp4, Buffer.from([9, 8, 7]));
      choose(png);
      const img = await pick({ sender: newtabWc });
      assert.strictEqual(img.ok, true); assert.strictEqual(img.kind, 'image'); assert.strictEqual(img.name, 'wall.PNG');
      assert(/^file:\/\/\/?/.test(img.url) && /\/backgrounds\/bg-\d+-[0-9a-f]+\.png$/.test(img.url));
      const imgFile = require('url').fileURLToPath(img.url);
      assert.deepStrictEqual(fs.readFileSync(imgFile), fs.readFileSync(png));
      choose(mp4);
      const vid = await pick({ sender: newtabWc });
      assert.strictEqual(vid.ok, true); assert.strictEqual(vid.kind, 'video');
      assert.notStrictEqual(vid.url, img.url);
      ok('picked image / video is copied into the backgrounds folder and returned as a file:// URL');

      fs.writeFileSync(path.join(bgDir, 'notes.txt'), 'keep me');
      assert.strictEqual(await prune({ sender: newtabWc }, img.url), 1);
      assert(fs.existsSync(imgFile) && !fs.existsSync(require('url').fileURLToPath(vid.url)));
      assert(fs.existsSync(path.join(bgDir, 'notes.txt')), 'files we did not create are never touched');
      assert.strictEqual(await prune({ sender: newtabWc }, ''), 1);
      assert(!fs.existsSync(imgFile));
      ok('pruning keeps only the background in use, and removes everything when none is in use');
    } finally { fake.dialog.showOpenDialog = realOpen; }
  }

  // 存檔
  win.emit('close');
  const cfg = JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8'));
  assert.strictEqual(cfg.layout, 'grid'); assert(Array.isArray(cfg.tabs) && cfg.tabs.length === 1);
  ok('window size / layout / open tabs are saved on close');

  console.log(`\n${checks} checks passed`);
  process.exit(0);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });

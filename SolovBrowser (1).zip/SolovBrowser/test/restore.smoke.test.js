'use strict';
/* 第二次開啟:還原上次的視窗大小、版面、分頁(含「收起」狀態)與使用中的分頁。 */
const assert = require('assert');
const Module = require('module');
const EventEmitter = require('events');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { pathToFileURL } = require('url');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mv-restore-'));
const { computeLayout } = require('../lib/layout');
const { ERR_PREFIX } = require('../lib/scriptwrap');

let wcSeq = 1;
class FakeWC extends EventEmitter {
  constructor() {
    super();
    this.id = wcSeq++; this._url = ''; this._title = ''; this._loading = false; this._destroyed = false;
    this.executed = []; this.sent = []; this.loaded = []; this.zoom = 0; this.reloads = 0; this.nextResult = undefined;
    this.navigationHistory = { canGoBack: () => false, canGoForward: () => false, goBack() {}, goForward() {} };
  }
  isDestroyed() { return this._destroyed; }
  getURL() { return this._url; } getTitle() { return this._title; } isLoading() { return this._loading; }
  loadURL(u) { this._url = u; this._loading = true; this.loaded.push(u); return Promise.resolve(); }
  loadFile(f) { this._url = pathToFileURL(f).href; this._loading = true; this.loaded.push(f); return Promise.resolve(); }
  setWindowOpenHandler(fn) { this.openHandler = fn; }
  executeJavaScript(code) { this.executed.push(code); return Promise.resolve(this.nextResult); }
  focus() { this.focused = true; this.emit('focus'); }
  close() { this._destroyed = true; }
  send(ch, payload) { this.sent.push([ch, payload]); }
  setZoomLevel(z) { this.zoom = z; } getZoomLevel() { return this.zoom; }
  reload() { this.reloads++; } reloadIgnoringCache() { this.reloads++; } stop() {}
  setVisualZoomLevelLimits() { return Promise.resolve(); }
  isDevToolsOpened() { return !!this.devtools; } openDevTools() { this.devtools = true; } closeDevTools() { this.devtools = false; }
  inspectElement() {} copy() {} cut() {} paste() {} undo() {} redo() {} selectAll() {} downloadURL() {}
}
class FakeView { constructor(o) { this.opts = o; this.webContents = new FakeWC(); this.bounds = null; this.visible = true; }
  setBounds(b) { this.bounds = b; } setVisible(v) { this.visible = v; } }
const windows = [];
class FakeWin extends EventEmitter {
  constructor(o) {
    super(); this.opts = o; this.webContents = new FakeWC(); this.children = []; this._size = [1400, 860]; this._destroyed = false;
    this.contentView = { addChildView: (v) => this.children.push(v), removeChildView: (v) => { this.children = this.children.filter((c) => c !== v); } };
    windows.push(this);
  }
  isDestroyed() { return this._destroyed; } getContentSize() { return this._size; }
  loadFile(f) { this.loaded = f; return Promise.resolve(); }
  show() { this.shown = true; } isVisible() { return !!this.shown; }
  maximize() {} isMaximized() { return false; } isMinimized() { return false; } restore() {} focus() {}
  getNormalBounds() { return { x: 0, y: 0, width: this._size[0], height: this._size[1] }; }
  setTitle(t) { this.title = t; } isFullScreen() { return !!this.fs; } setFullScreen(v) { this.fs = v; }
}
const ipcOn = new Map(); const ipcHandle = new Map();
let lastMenu = null; const boxes = []; let permHandler = null;
const fake = {
  app: Object.assign(new EventEmitter(), {
    whenReady: () => Promise.resolve(), getPath: () => tmp, requestSingleInstanceLock: () => true,
    quit() { this.quitted = true; }, setAppUserModelId() {}, userAgentFallback: '',
  }),
  BrowserWindow: FakeWin, WebContentsView: FakeView,
  ipcMain: { on: (c, f) => ipcOn.set(c, f), handle: (c, f) => ipcHandle.set(c, f) },
  Menu: { setApplicationMenu() {}, buildFromTemplate: (tpl) => ({ tpl, popup() { lastMenu = tpl; } }) },
  session: { defaultSession: { setUserAgent(ua) { this.ua = ua; }, setPermissionRequestHandler(f) { permHandler = f; }, setPermissionCheckHandler() {} } },
  shell: { openExternal: () => Promise.resolve() },
  dialog: {
    showMessageBox: (...a) => { boxes.push(a); return Promise.resolve({ response: 0 }); },
    showMessageBoxSync: () => 0, showOpenDialog: () => Promise.resolve({ canceled: true, filePaths: [] }),
  },
  clipboard: { copied: [], writeText(t) { this.copied.push(t); return Promise.resolve(); } },
  nativeTheme: { shouldUseDarkColors: false },
};
const origLoad = Module._load;
Module._load = function (req) { return req === 'electron' ? fake : origLoad.apply(this, arguments); };

const flush = (ms = 200) => new Promise((r) => setTimeout(r, ms));
const send = (win, ch, ...a) => { const f = ipcOn.get(ch); assert(f, 'no ipc ' + ch); f({ sender: win.webContents }, ...a); };
const invoke = (win, ch, ...a) => ipcHandle.get(ch)({ sender: win.webContents }, ...a);
const lastState = (win) => { const s = win.webContents.sent.filter(([c]) => c === 'state'); return s[s.length - 1][1]; };
const lastScripts = (win) => { const s = win.webContents.sent.filter(([c]) => c === 'scripts'); return s.length ? s[s.length - 1][1] : null; };
let checks = 0; const ok = (name) => { checks++; console.log('  ok  ' + name); };
const key = (k, o = {}) => ({ type: 'keyDown', key: k, control: false, meta: false, shift: false, alt: false, ...o });
const press = (wc, input) => { let prevented = false; wc.emit('before-input-event', { preventDefault() { prevented = true; } }, input); return prevented; };


fs.writeFileSync(path.join(tmp, 'config.json'), JSON.stringify({
  layout: 'cols',
  window: { width: 1200, height: 800, maximized: false },
  tabs: [
    { url: 'https://a.example/', shown: true, refresh: 30 },
    { url: 'https://b.example/', shown: false, refresh: 7 },
    { url: '', shown: true },
    { url: 'javascript:alert(1)', shown: true },
    { url: 'https://d.example/', shown: true },
  ],
  active: 4,
}));
fs.writeFileSync(path.join(tmp, 'scripts.json'), JSON.stringify([{ id: 'k', name: '舊腳本', code: 'x', enabled: true }]));

const captured = []; const realSI = global.setInterval;
global.setInterval = (fn, ms) => { const h = realSI(fn, ms); captured.push({ fn, ms, h }); return h; };

(async () => {
  require('../main.js');
  await flush(50);
  const win = windows[0];
  assert.strictEqual(win.opts.width, 1200); assert.strictEqual(win.opts.height, 800);
  win.webContents.emit('did-finish-load'); await flush(80);
  const st = lastState(win);
  assert.strictEqual(st.layout, 'cols');
  assert.deepStrictEqual(st.tabs.map((t) => [t.url, t.shown]), [['https://a.example/', true], ['https://b.example/', false], ['', true], ['https://d.example/', true]]);
  assert.strictEqual(st.activeId, st.tabs[3].id, 'restores the active tab (index is of the saved list, unsafe URLs skipped)');
  assert.strictEqual(st.tiles.length, 3, 'the hidden tab stays hidden');
  assert.strictEqual(win.children[1].visible, false);
  assert.deepStrictEqual(st.tabs.map((t) => t.refreshSec), [30, 0, 0, 0], 'auto-refresh restored; an unsupported value is dropped');
  assert.strictEqual(captured.filter((c) => c.ms === 30000).length, 1);
  const init = await invoke(win, 'ui:ready');
  assert.deepStrictEqual(init.scripts.map((s) => [s.id, s.enabled]), [['k', true]], 'existing scripts are loaded, no demo re-seeded');
  ok('restores window size, layout, tabs (incl. hidden state), active tab and scripts; skips non-web URLs');

  // 存檔時,索引以「可還原的分頁」為準
  const popup = win.children[0].webContents.openHandler({ url: 'https://p.example/', disposition: 'foreground-tab' });
  await flush(30);
  const t = lastState(win).tabs.find((x) => x.url === 'https://p.example/');
  const pw = win.children[win.children.length - 1].webContents;
  pw._url = 'about:blank'; pw.emit('did-navigate'); await flush(30);        // 這個分頁變成不可還原的 about:blank,而且是使用中
  win.children[3].webContents.emit('focus'); await flush(30);                // 使用中改回最後一個可還原的分頁
  win.emit('close');
  const cfg = JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8'));
  assert(cfg.tabs.every((x) => x.url === '' || /^https?:/.test(x.url)), JSON.stringify(cfg.tabs));
  assert(!cfg.tabs.some((x) => x.url === 'about:blank'));
  assert.strictEqual(cfg.tabs[0].refresh, 30, 'refresh interval is written back');
  assert.strictEqual(cfg.tabs[cfg.active].url, 'https://d.example/', 'active index points at the right tab after filtering');
  ok('saved active index stays correct even when some tabs are not restorable');

  console.log(`\n${checks} checks passed`);
  process.exit(0);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });

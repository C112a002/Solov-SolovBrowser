'use strict';

/**
 * 套用在「每一個網頁分頁」的 preload。
 * 對一般網頁不公開任何 API,只在使用者按下滑鼠 / 觸控時通知主程序:
 * 「我是被點到的那個分頁」,讓主程序把它設為使用中的分頁(網址列會跟著切換)。
 * 唯一的例外是內建的「新分頁」頁面(renderer/newtab.html):只有它會拿到 solovNewtab,
 * 用來選擇 / 清理自訂背景;主程序那邊也會再檢查一次發送者。
 */
const { contextBridge, ipcRenderer } = require('electron');

function poke(event) {
  if (event && event.isTrusted === false) return; // 忽略網頁腳本偽造的事件
  ipcRenderer.send('tab:interact');
}

window.addEventListener('mousedown', poke, true);
window.addEventListener('touchstart', poke, { capture: true, passive: true });

// 只有內建起始頁才公開背景設定用的 API(網頁拿不到)
if (window.top === window && location.protocol === 'file:' && /\/renderer\/newtab\.html$/i.test(location.pathname)) {
  contextBridge.exposeInMainWorld('solovNewtab', {
    pickBackground: () => ipcRenderer.invoke('newtab:bg-pick'),
    pruneBackgrounds: (keepUrl) => ipcRenderer.invoke('newtab:bg-prune', typeof keepUrl === 'string' ? keepUrl : ''),
  });
}

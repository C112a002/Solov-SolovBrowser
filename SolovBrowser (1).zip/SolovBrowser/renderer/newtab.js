'use strict';

// 新分頁頁面:時鐘、搜尋(支援 @g 之類的搜尋捷徑)、常用網站、自訂面板。
// 預設搜尋引擎若要更換,請與 main.js 的 SEARCH_URL 一起修改。
(function () {
  const ENGINES = {
    g:  { name: 'Google',      url: 'https://www.google.com/search?q=' },
    b:  { name: 'Bing',        url: 'https://www.bing.com/search?q=' },
    d:  { name: 'DuckDuckGo',  url: 'https://duckduckgo.com/?q=' },
    y:  { name: 'Yahoo!奇摩',   url: 'https://tw.search.yahoo.com/search?p=' },
    bd: { name: '百度',         url: 'https://www.baidu.com/s?wd=' },
    yt: { name: 'YouTube',     url: 'https://www.youtube.com/results?search_query=' },
    w:  { name: '維基百科',     url: 'https://zh.wikipedia.org/w/index.php?search=' },
    gh: { name: 'GitHub',      url: 'https://github.com/search?q=' },
  };
  const DEFAULT_ENGINE = 'g';

  const DEFAULTS = {
    name: 'Solov',
    sub: '我的起始頁',
    theme: 'aurora',
    tips: true,
    bg: null, // { kind: 'image' | 'video', url: 'file:///…', name, dim: 0–80, blur: 0–20 }
    links: [
      { name: 'Google',   url: 'https://www.google.com/' },
      { name: 'YouTube',  url: 'https://www.youtube.com/' },
      { name: '維基百科',  url: 'https://zh.wikipedia.org/' },
      { name: 'GitHub',   url: 'https://github.com/' },
      { name: 'Reddit',   url: 'https://www.reddit.com/' },
      { name: 'Bing',     url: 'https://www.bing.com/' },
    ],
  };
  const THEMES = ['aurora', 'ocean', 'forest', 'rose', 'night'];
  const KEY = 'solov.newtab.v1';

  const $ = (id) => document.getElementById(id);
  const clone = (o) => JSON.parse(JSON.stringify(o));

  // ---------- 設定 ----------
  const clampInt = (v, lo, hi, dflt) => {
    const n = Math.round(Number(v));
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
  };
  function cleanBg(b) {
    if (!b || typeof b !== 'object') return null;
    if ((b.kind !== 'image' && b.kind !== 'video') || typeof b.url !== 'string' || !/^file:\/\//i.test(b.url)) return null;
    return {
      kind: b.kind,
      url: b.url,
      name: typeof b.name === 'string' ? b.name.slice(0, 120) : '',
      dim: clampInt(b.dim, 0, 80, 30),
      blur: clampInt(b.blur, 0, 20, 0),
    };
  }
  function load() {
    const cfg = clone(DEFAULTS);
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (raw && typeof raw === 'object') {
        if (typeof raw.name === 'string') cfg.name = raw.name;
        if (typeof raw.sub === 'string') cfg.sub = raw.sub;
        if (THEMES.includes(raw.theme)) cfg.theme = raw.theme;
        if (typeof raw.tips === 'boolean') cfg.tips = raw.tips;
        cfg.bg = cleanBg(raw.bg);
        if (Array.isArray(raw.links)) {
          cfg.links = raw.links
            .filter((l) => l && typeof l.name === 'string' && typeof l.url === 'string' && /^https?:\/\//i.test(l.url))
            .slice(0, 12)
            .map((l) => ({ name: l.name, url: l.url }));
        }
      }
    } catch (_) { /* 沒有儲存空間時用預設值 */ }
    return cfg;
  }
  function save(cfg) {
    try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (_) { /* 忽略 */ }
  }
  let cfg = load();

  // ---------- 時鐘 ----------
  let lastMinute = '';
  function tick() {
    const d = new Date();
    const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    if (hm === lastMinute) return;
    lastMinute = hm;
    $('clock').textContent = hm;
    $('date').textContent = (d.getMonth() + 1) + '月' + d.getDate() + '日 星期' + '日一二三四五六'[d.getDay()];
  }
  tick();
  setInterval(tick, 1000);

  // ---------- 自訂背景(圖片 / 影片) ----------
  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  let shownKey = '';   // 目前畫面上的背景(種類 + 網址),相同時只更新暗化 / 模糊,不重新載入
  let brokenUrl = '';  // 載入失敗的背景網址(檔案不見或影片編碼不支援)

  function bgVideo() { return $('bg').querySelector('video'); }
  function clearBgMedia() { $('bg').textContent = ''; shownKey = ''; }

  function showBgError(msg) { $('c-bg-err').textContent = msg || ''; }

  function applyBg(bg) {
    const root = $('bg');
    if (!bg || bg.url === brokenUrl) {
      document.body.classList.remove('has-bg');
      clearBgMedia();
      return;
    }
    document.body.classList.add('has-bg');
    root.style.setProperty('--bg-dim', String(bg.dim / 100));
    root.style.setProperty('--bg-blur', bg.blur + 'px');
    root.style.setProperty('--bg-scale', bg.blur > 0 ? '1.06' : '1'); // 模糊時稍微放大,避免邊緣露出
    const key = bg.kind + '|' + bg.url;
    if (key === shownKey) return;
    clearBgMedia();
    shownKey = key;

    const el = document.createElement(bg.kind === 'video' ? 'video' : 'img');
    el.addEventListener('error', () => {
      if (!el.isConnected) return;
      brokenUrl = bg.url;
      document.body.classList.remove('has-bg');
      clearBgMedia();
      showBgError('無法載入這個背景(檔案不見了,或影片的編碼不支援)。');
    });
    if (bg.kind === 'video') {
      el.muted = true;
      el.loop = true;
      el.playsInline = true;
      el.autoplay = !reduceMotion;
      el.preload = 'auto';
      el.disablePictureInPicture = true;
      el.src = bg.url;
      if (!reduceMotion) el.play().catch(() => {});
    } else {
      el.alt = '';
      el.draggable = false;
      el.src = bg.url;
    }
    root.append(el);
  }

  // 看不到這個頁面時暫停影片(省電、省 CPU)
  document.addEventListener('visibilitychange', () => {
    const v = bgVideo();
    if (!v) return;
    if (document.hidden) v.pause();
    else if (!reduceMotion) v.play().catch(() => {});
  });

  // ---------- 畫面 ----------
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch (_) { return url; }
  }
  function render() {
    document.body.dataset.theme = cfg.theme;
    applyBg(cfg.bg);
    $('greet').textContent = cfg.name.trim() ? 'Hi ' + cfg.name.trim() : 'Hi';
    $('sub').textContent = cfg.sub;
    $('sub').style.display = cfg.sub.trim() ? '' : 'none';
    $('tips').style.display = cfg.tips ? '' : 'none';

    const ul = $('links');
    ul.textContent = '';
    for (const l of cfg.links) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.className = 'glass';
      a.href = l.url;
      const ico = document.createElement('span');
      ico.className = 'ico';
      ico.textContent = (Array.from(l.name.trim())[0] || '?').toUpperCase();
      const txt = document.createElement('span');
      txt.className = 'txt';
      const b = document.createElement('b');
      b.textContent = l.name;
      const s = document.createElement('small');
      s.textContent = hostOf(l.url);
      txt.append(b, s);
      a.append(ico, txt);
      li.append(a);
      ul.append(li);
    }
  }

  // 搜尋捷徑提示
  function buildChips() {
    const ul = $('chips');
    for (const key of Object.keys(ENGINES)) {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'glass';
      btn.textContent = '@' + key + ' ' + ENGINES[key].name;
      btn.addEventListener('click', () => {
        const q = $('q');
        q.value = '@' + key + ' ';
        q.focus();
        updatePlaceholder();
      });
      li.append(btn);
      ul.append(li);
    }
  }
  buildChips();

  // ---------- 搜尋 ----------
  function parseShortcut(s) {
    const m = /^@([a-z]+)(?:\s+(.*))?$/i.exec(s.trim());
    if (!m) return null;
    const key = m[1].toLowerCase();
    return ENGINES[key] ? { key, engine: ENGINES[key], text: (m[2] || '').trim() } : null;
  }

  function updatePlaceholder() {
    const sc = parseShortcut($('q').value);
    $('q').placeholder = sc && $('q').value.trim() ? '用 ' + sc.engine.name + ' 搜尋' : '用 Google 搜尋,或輸入網址';
  }

  function toUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return null;
    const sc = parseShortcut(s);
    if (sc) {
      if (sc.text) return sc.engine.url + encodeURIComponent(sc.text);
      return new URL(sc.engine.url).origin + '/';
    }
    if (/^(https?|file|about|data|view-source):/i.test(s)) return s;
    if (!/\s/.test(s)) {
      if (/^localhost(:\d{1,5})?([/?#].*)?$/i.test(s)) return 'http://' + s;
      if (/^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?([/?#].*)?$/.test(s)) return 'http://' + s;
      if (/^([a-z0-9¡-￿-]+\.)+[a-z¡-￿]{2,}(:\d{1,5})?([/?#].*)?$/i.test(s)) {
        return 'https://' + s;
      }
    }
    return ENGINES[DEFAULT_ENGINE].url + encodeURIComponent(s);
  }

  $('q').addEventListener('input', updatePlaceholder);
  $('search').addEventListener('submit', (e) => {
    e.preventDefault();
    const url = toUrl($('q').value);
    if (url) location.href = url;
  });

  // ---------- 自訂面板 ----------
  function addRow(l) {
    const row = document.createElement('div');
    row.className = 'row';
    const n = document.createElement('input');
    n.type = 'text'; n.placeholder = '名稱'; n.maxLength = 20; n.value = l.name;
    const u = document.createElement('input');
    u.type = 'text'; u.placeholder = 'https://example.com'; u.value = l.url;
    const del = document.createElement('button');
    del.type = 'button'; del.className = 'btn small'; del.textContent = '刪除';
    del.addEventListener('click', () => row.remove());
    row.append(n, u, del);
    $('c-links').append(row);
  }
  let draftBg = null; // 面板裡編輯中的背景(儲存前先即時預覽在頁面上)

  function syncBgPanel() {
    const has = !!draftBg;
    $('c-bg-name').textContent = has
      ? (draftBg.kind === 'video' ? '影片:' : '圖片:') + (draftBg.name || '(未命名)')
      : '未選擇(使用上面的背景色調)';
    $('c-bg-clear').disabled = !has;
    $('c-bg-opts').style.display = has ? '' : 'none';
    if (has) {
      $('c-dim').value = draftBg.dim;
      $('c-blur').value = draftBg.blur;
      $('c-dim-v').textContent = draftBg.dim + '%';
      $('c-blur-v').textContent = draftBg.blur + ' px';
    }
    applyBg(draftBg);
  }

  function fillPanel(c) {
    draftBg = c.bg ? Object.assign({}, c.bg) : null;
    showBgError(draftBg && draftBg.url === brokenUrl ? '目前的背景檔案無法載入,請重新選擇。' : '');
    syncBgPanel();
    $('c-name').value = c.name;
    $('c-sub').value = c.sub;
    $('c-theme').value = c.theme;
    $('c-tips').checked = c.tips;
    $('c-links').textContent = '';
    c.links.forEach(addRow);
  }
  function openPanel() {
    cfg = load(); // 別的新分頁可能已經改過設定
    fillPanel(cfg);
    $('overlay').classList.add('open');
    $('c-name').focus();
  }
  function closePanel() {
    if (!$('overlay').classList.contains('open')) return;
    $('overlay').classList.remove('open');
    draftBg = null;
    applyBg(cfg.bg); // 取消時還原成已儲存的背景
    // 刪掉選過但沒有儲存的檔案;以儲存空間裡最新的設定為準,避免誤刪別的分頁剛存的背景
    const keep = load().bg;
    if (window.solovNewtab) window.solovNewtab.pruneBackgrounds(keep ? keep.url : '').catch(() => {});
  }

  function normalizeUrl(s) {
    s = s.trim();
    if (!s) return null;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'https://' + s;
    try {
      const u = new URL(s);
      return /^https?:$/.test(u.protocol) ? u.href : null;
    } catch (_) { return null; }
  }

  $('customize').addEventListener('click', openPanel);
  $('c-cancel').addEventListener('click', closePanel);
  $('overlay').addEventListener('mousedown', (e) => { if (e.target === $('overlay')) closePanel(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });
  $('c-add').addEventListener('click', () => {
    if ($('c-links').children.length >= 12) return;
    addRow({ name: '', url: '' });
    $('c-links').lastChild.firstChild.focus();
  });
  $('c-reset').addEventListener('click', () => fillPanel(DEFAULTS));

  $('c-bg-pick').addEventListener('click', async () => {
    const api = window.solovNewtab;
    if (!api) { showBgError('這個環境無法選擇檔案。'); return; }
    const btn = $('c-bg-pick');
    btn.disabled = true;
    showBgError('');
    try {
      const r = await api.pickBackground();
      if (!r || !r.ok) {
        if (r && r.error) showBgError(r.error);
        return;
      }
      const picked = cleanBg({ kind: r.kind, url: r.url, name: r.name, dim: draftBg ? draftBg.dim : 30, blur: draftBg ? draftBg.blur : 0 });
      if (!picked) { showBgError('無法使用這個檔案。'); return; }
      if (brokenUrl === picked.url) brokenUrl = '';
      draftBg = picked;
      syncBgPanel();
    } catch (_) {
      showBgError('無法選擇檔案。');
    } finally {
      btn.disabled = false;
    }
  });
  $('c-bg-clear').addEventListener('click', () => { draftBg = null; showBgError(''); syncBgPanel(); });
  $('c-dim').addEventListener('input', () => {
    if (!draftBg) return;
    draftBg.dim = clampInt($('c-dim').value, 0, 80, 30);
    $('c-dim-v').textContent = draftBg.dim + '%';
    applyBg(draftBg);
  });
  $('c-blur').addEventListener('input', () => {
    if (!draftBg) return;
    draftBg.blur = clampInt($('c-blur').value, 0, 20, 0);
    $('c-blur-v').textContent = draftBg.blur + ' px';
    applyBg(draftBg);
  });

  // 其他新分頁改了設定時,這一頁也跟著更新(面板開著時不打斷編輯)
  window.addEventListener('storage', (e) => {
    if (e.key !== KEY || $('overlay').classList.contains('open')) return;
    cfg = load();
    render();
  });
  $('c-save').addEventListener('click', () => {
    const links = [];
    for (const row of $('c-links').children) {
      const [n, u] = row.querySelectorAll('input');
      const url = normalizeUrl(u.value);
      if (!url) continue;
      links.push({ name: n.value.trim() || hostOf(url), url });
    }
    cfg = {
      name: $('c-name').value,
      sub: $('c-sub').value,
      theme: $('c-theme').value,
      tips: $('c-tips').checked,
      bg: draftBg ? cleanBg(draftBg) : null,
      links,
    };
    save(cfg);
    render();
    closePanel();
  });

  render();
  $('q').focus();
})();

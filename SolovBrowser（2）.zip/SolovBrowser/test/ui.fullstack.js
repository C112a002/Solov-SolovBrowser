'use strict';
/* 整合測試:真正的 main.js(假 electron)+ 真正的 preload-ui.js / preload-tab.js + 真正的 renderer,
 * 在無頭 Chromium 裡實際操作設定面板,檢查 IPC、主題、版面、快速鍵、新分頁頁面是不是真的接起來。
 * 頁面裡的 require('electron') 是一個小小的橋:ipcRenderer 的呼叫會轉給 Node 端的 main.js,
 * main.js 對視窗的推送(webContents.send)也會轉進頁面。
 * 用法:node test/ui.fullstack.js [截圖輸出資料夾] */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');
const { startApp, ROOT } = require('./helpers/fakeapp');
const { computeLayout } = require('../lib/layout');
const { ACTIONS } = require('../lib/keys');

const OUT = process.argv[2] || '/home/claude/shots';
fs.mkdirSync(OUT, { recursive: true });
const INDEX = pathToFileURL(path.join(ROOT, 'renderer', 'index.html')).href;
const NEWTAB = pathToFileURL(path.join(ROOT, 'renderer', 'newtab.html')).href;
const PRELOAD_UI = fs.readFileSync(path.join(ROOT, 'preload-ui.js'), 'utf8');
const PRELOAD_TAB = fs.readFileSync(path.join(ROOT, 'preload-tab.js'), 'utf8');

/** 讓頁面裡的 preload 以為自己在 Electron 裡:ipcRenderer ↔ Node 端的 main.js */
async function bridge(page, app, wc, preloadSrc, syncChannel) {
  let chain = Promise.resolve();
  const sync = {};
  if (syncChannel) sync[syncChannel] = app.sendFrom(wc, syncChannel); // 頁面一載入就要答案,所以先算好
  await page.exposeFunction('__ipcSend', (channel, args) => {
    try {
      app.sendFrom(wc, channel, ...args);
    } catch (err) {
      console.error('[bridge send]', channel, err.message);
    }
  });
  await page.exposeFunction('__ipcInvoke', async (channel, args) => app.invokeFrom(wc, channel, ...args));
  wc.onSend = (channel, payload) => {
    const data = JSON.parse(JSON.stringify(payload === undefined ? null : payload));
    chain = chain.then(() => page.evaluate(([c, p]) => window.__ipcEmit && window.__ipcEmit(c, p), [channel, data])).catch(() => {});
  };
  const content = `(() => {
    window.__sync = ${JSON.stringify(sync)};
    window.__listeners = {};
    window.__ipcEmit = (ch, payload) => { for (const cb of (window.__listeners[ch] || [])) cb({}, payload); };
    const electron = {
      contextBridge: { exposeInMainWorld: (k, api) => { window[k] = api; } },
      ipcRenderer: {
        send: (ch, ...args) => { window.__ipcSend(ch, args); },
        invoke: (ch, ...args) => window.__ipcInvoke(ch, args),
        sendSync: (ch) => (ch in window.__sync ? window.__sync[ch] : null),
        on: (ch, cb) => { (window.__listeners[ch] = window.__listeners[ch] || []).push(cb); },
      },
    };
    (function (require) {\n${preloadSrc}\n})((name) => { if (name === 'electron') return electron; throw new Error('require(' + name + ')'); });
  })();`;
  await page.addInitScript({ content });
  return { settle: () => chain, wc };
}

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  let checks = 0;
  const ok = (m) => { checks++; console.log('  ok  ' + m); };
  let expectMissingFile = false;
  const watch = (page, name) => {
    page.on('pageerror', (e) => problems.push(`[${name}] pageerror: ${e.message}`));
    page.on('console', (m) => {
      if (!['error', 'warning'].includes(m.type())) return;
      if (expectMissingFile && /ERR_FILE_NOT_FOUND/.test(m.text())) return;
      problems.push(`[${name}] console.${m.type()}: ${m.text()}`);
    });
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /** 頁面根元素上某個 CSS 變數目前的值 */
  const cssVar = (page, name) => page.evaluate((n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim(), name);
  const until = (page, fn, arg, ms = 4000) => page.waitForFunction(fn, arg, { timeout: ms });

  /* ──────────────── 1. 開機、提示、開啟設定面板 ──────────────── */
  const app = await startApp();
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 860 }, colorScheme: 'light' });
  const page = await ctx.newPage();
  watch(page, 'ui');
  const br = await bridge(page, app, app.win.webContents, PRELOAD_UI, 'ui:boot');
  await page.goto(INDEX);
  await page.waitForSelector('.tab');
  const shot = (name) => page.screenshot({ path: path.join(OUT, `fs-${name}.png`) });

  app.finishLoad(app.activeWC());
  await until(page, () => document.getElementById('btn-reload').dataset.mode === 'reload');
  assert.strictEqual(await page.locator('#solov-theme').textContent(), '', 'default settings → no theme override');
  assert.strictEqual(await cssVar(page, '--tab-h'), '38px');
  assert.strictEqual(await cssVar(page, '--panel-w'), '420px');
  assert.strictEqual(await page.locator('#btn-home').isHidden(), true, 'home button is off by default');
  assert.strictEqual(await page.locator('#btn-settings').isVisible(), true);
  assert.strictEqual(await page.locator('#btn-newtab').getAttribute('title'), '新增分頁 (Ctrl+T)');
  assert.strictEqual(await page.locator('#btn-settings').getAttribute('title'), '設定 (Ctrl+,)');
  assert.strictEqual(await page.locator('#btn-ext').getAttribute('title'), '擴充功能與使用者腳本 (Ctrl+Shift+X)');
  assert.strictEqual(await page.locator('#btn-reload').getAttribute('title'), '重新整理 (F5)');
  ok('boots through the real preload: default look, buttons carry their current shortcuts in tooltips');

  await page.locator('#btn-settings').click();
  await until(page, () => !document.getElementById('panel').hidden);
  assert.strictEqual(app.state().panelOpen, true);
  assert.strictEqual(app.state().panelMode, 'settings');
  assert.strictEqual(await page.locator('#view-settings').isVisible(), true);
  assert.strictEqual(await page.locator('#view-list').isVisible(), false);
  assert.strictEqual(await page.locator('#panel-title').textContent(), '設定');
  assert.strictEqual(await page.locator('#settings-tabs .stab').count(), 6);
  assert.strictEqual(await page.locator('#btn-settings.on').count(), 1);
  assert.strictEqual(await page.locator('#btn-ext.on').count(), 0);
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--panel-w').trim() === '480px');
  assert.strictEqual(app.win.children[0].bounds.width, 1400 - 480, 'native page view shrinks to make room for the 480px settings panel');
  ok('settings button opens the settings panel (480px minimum), page view makes room, 6 sections');

  // 開著設定面板時再按一次 = 關閉;切到擴充功能 = 換內容不關面板
  await page.locator('#btn-ext').click();
  await until(page, () => document.getElementById('view-settings').hidden);
  assert.strictEqual(app.state().panelMode, 'scripts');
  assert.strictEqual(await page.locator('#view-list').isVisible(), true);
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--panel-w').trim() === '420px');
  await page.locator('#btn-settings').click();
  await until(page, () => !document.getElementById('view-settings').hidden);
  await page.locator('#btn-settings').click();
  await until(page, () => document.getElementById('panel').hidden);
  assert.strictEqual(app.state().panelOpen, false);
  await page.locator('#btn-settings').click();
  await until(page, () => !document.getElementById('panel').hidden);
  ok('the two toolbar buttons switch the panel between scripts and settings; pressing the active one closes it');

  /* ──────────────── 2. 外觀 ──────────────── */
  const openSection = async (id) => {
    await page.locator(`#settings-tabs .stab[data-section="${id}"]`).click();
    await until(page, (sid) => !document.querySelector(`.spanel[data-section="${sid}"]`).hidden, id);
  };
  const panelOf = (id) => page.locator(`.spanel[data-section="${id}"]`);
  const savedSettings = async () => { await sleep(420); return app.settingsOnDisk(); };

  await openSection('appearance');
  // 配色
  await page.locator('.pal[data-palette="ocean"]').click();
  await until(page, () => document.getElementById('solov-theme').textContent.includes('#2f6fed'));
  assert.strictEqual(await page.locator('.pal[data-palette="ocean"]').getAttribute('aria-pressed'), 'true');
  assert.strictEqual(await cssVar(page, '--bar'), '#f5f8fc');
  await page.emulateMedia({ colorScheme: 'dark' });
  assert.strictEqual(await cssVar(page, '--bar'), '#1a2331', 'the dark half of the ocean palette applies in dark mode');
  await page.emulateMedia({ colorScheme: 'light' });
  assert.strictEqual((await savedSettings()).appearance.palette, 'ocean');
  ok('palette: click applies live (light + dark variants) and is written to settings.json');

  // 色彩模式 → 主程序切換 nativeTheme(連網頁一起切換)
  await page.locator('#settings-body .seg[aria-label="色彩模式"] button[data-value="dark"]').click();
  await app.waitFor(() => app.electron.nativeTheme.themeSource === 'dark', 'nativeTheme dark');
  assert(app.win.log.bg.length > 0 && app.win.bg === '#0e131b', 'window background follows the palette: ' + app.win.bg);
  await page.locator('#settings-body .seg[aria-label="色彩模式"] button[data-value="system"]').click();
  await app.waitFor(() => app.electron.nativeTheme.themeSource === 'system', 'nativeTheme system');
  ok('color mode drives nativeTheme.themeSource and the window background colour');

  // 滑桿:字級
  const fsInput = page.locator('input[type=range][aria-label="介面字級"]');
  await fsInput.fill('16');
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--fs').trim() === '16px');
  const fsReset = page.locator('.slider:has(input[aria-label="介面字級"]) .reset');
  assert.strictEqual(await fsReset.isVisible(), true, 'a changed value shows its reset button');
  assert.strictEqual(await page.locator('.slider:has(input[aria-label="介面字級"]) .val').textContent(), '16 px');
  await fsReset.click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--fs').trim() === '13px');
  assert.strictEqual(await fsInput.inputValue(), '13');
  assert.strictEqual(await fsReset.evaluate((el) => getComputedStyle(el).visibility), 'hidden');
  ok('slider: drag applies immediately, shows its value, ↺ resets to the default');

  // 介面密度 → 版面也要重算(原生檢視往下移)
  await page.locator('.seg[aria-label="介面密度"] button[data-value="comfortable"]').click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--tab-h').trim() === '44px');
  assert.strictEqual(await cssVar(page, '--bar-h'), '52px');
  assert.strictEqual(await cssVar(page, '--chrome-h'), '96px');
  assert.strictEqual(await cssVar(page, '--ctl'), '34px');
  await app.waitFor(() => app.win.children[0].bounds.y === 96, 'native view moved to y=96');
  await page.locator('.seg[aria-label="介面密度"] button[data-value="compact"]').click();
  await app.waitFor(() => app.win.children[0].bounds.y === 70, 'compact → y=70');
  await page.locator('.seg[aria-label="介面密度"] button[data-value="normal"]').click();
  await app.waitFor(() => app.win.children[0].bounds.y === 82);
  ok('density changes the toolbar heights and the main process re-tiles the native page views');

  // 圓角、強調色、分頁寬度
  await page.locator('.seg[aria-label="圓角"] button[data-value="sharp"]').click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--round').trim() === '0');
  await page.locator('.seg[aria-label="圓角"] button[data-value="normal"]').click();
  await until(page, () => !document.getElementById('solov-theme').textContent.includes('--round'));
  await page.locator('.dot[data-accent="#dc2626"]').click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() === '#dc2626');
  assert.strictEqual(await page.locator('.dot[data-accent="#dc2626"]').getAttribute('aria-pressed'), 'true');
  await page.locator('input[type=range][aria-label="分頁寬度"]').fill('280');
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--tab-w').trim() === '280px');
  ok('radius, accent colour and tab width apply live');

  // 逐項自訂顏色(淺色模式的背景)
  await page.locator('details.more > summary').click();
  const stageInput = page.locator('input[type=color][aria-label="淺色模式的背景"]');
  await stageInput.fill('#ffeecc');
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--stage').trim() === '#ffeecc');
  assert.strictEqual(await page.locator('.colorctl:has(input[aria-label="淺色模式的背景"]) .reset').isVisible(), true);
  await page.locator('.colorctl:has(input[aria-label="淺色模式的背景"]) .reset').click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--stage').trim() === '#e5ebf4');
  ok('per-colour override applies live and resets back to the palette colour');

  // 字型:預設選單、自訂、不合法
  const uiFont = page.locator('.fontctl:has(select[aria-label="介面字型"])');
  await uiFont.locator('select').selectOption({ label: '微軟正黑體' });
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--sans').includes('Microsoft JhengHei UI'));
  await uiFont.locator('select').selectOption('__custom');
  await uiFont.locator('input[type=text]').fill('"LXGW WenKai", serif');
  await uiFont.locator('input[type=text]').press('Enter');
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--sans').startsWith('"LXGW WenKai"'));
  await uiFont.locator('input[type=text]').fill('Arial; } body { display:none');
  await uiFont.locator('input[type=text]').press('Enter');
  await until(page, () => /字型名稱/.test(document.getElementById('panel-note').textContent));
  assert(!(await cssVar(page, '--sans')).includes('display'), 'unsafe font names never reach the stylesheet');
  assert.strictEqual(await page.locator('body').evaluate((b) => getComputedStyle(b).display), 'block');
  ok('fonts: preset, custom name, and a CSS-injection attempt is rejected with a note');

  await shot('settings-appearance-light');
  await page.emulateMedia({ colorScheme: 'dark' });
  await shot('settings-appearance-dark');
  await page.emulateMedia({ colorScheme: 'light' });

  // 還原這一頁
  const resetBtn = panelOf('appearance').locator('.sreset .btn');
  await resetBtn.click();
  assert.strictEqual((await resetBtn.textContent()).trim(), '再按一次確定');
  assert.strictEqual(await page.locator('#solov-theme').textContent() !== '', true, 'first click only arms the button');
  await resetBtn.click();
  await until(page, () => document.getElementById('solov-theme').textContent === '');
  assert.strictEqual(await cssVar(page, '--sans') !== '', true);
  assert.strictEqual((await savedSettings()).appearance.palette, 'default');
  assert.strictEqual(app.electron.nativeTheme.themeSource, 'system');
  ok('"restore this page" needs two clicks and puts every appearance setting back to the default');

  /* ──────────────── 3. 版面 ──────────────── */
  await openSection('layout');
  await page.locator('#btn-newtab').click();
  await until(page, () => document.querySelectorAll('.tile').length === 2);
  app.finishLoad(app.tabWC(1));

  /** 原生檢視的位置是不是和「用這些設定算出來的版面」一模一樣 */
  const L = { gap: 6, pad: 6, headH: 30, frame: 2, cols: 0, panelW: 480, chromeH: 82, minW: 300, minH: 190, layout: 'grid' };
  const viewsMatch = (o = {}) => {
    const m = { ...L, ...o };
    const n = app.win.children.filter((v) => v.visible).length;
    const lay = computeLayout({
      width: 1400, height: 860, chromeH: m.chromeH, panelW: m.panelW, count: n, layout: m.layout, gridColumns: m.cols,
      metrics: { PAD: m.pad, GAP: m.gap, HEAD_H: m.headH, FRAME: m.frame, MIN_TILE_W: m.minW, MIN_TILE_H: m.minH },
    });
    return app.win.children.filter((v) => v.visible).every((v, i) => {
      const r = lay.tiles[i].view;
      return v.bounds && v.bounds.x === r.x && v.bounds.y === r.y && v.bounds.width === r.w && v.bounds.height === r.h;
    });
  };
  const box = (label) => page.locator(`input[type=checkbox][aria-label="${label}"]`);
  const range = (label) => page.locator(`input[type=range][aria-label="${label}"]`);
  assert(viewsMatch(), 'two tabs tile the area next to the 480px panel');
  ok('layout: starting point — two native views tiled exactly as computeLayout says (with the settings panel open)');

  await range('方塊間距').fill('20');
  await app.waitFor(() => viewsMatch({ gap: 20 }), 'gap 20');
  await range('外側留白').fill('0');
  await app.waitFor(() => viewsMatch({ gap: 20, pad: 0 }), 'pad 0');
  await range('邊框粗細').fill('4');
  await app.waitFor(() => viewsMatch({ gap: 20, pad: 0, frame: 4 }), 'frame 4');
  await until(page, () => getComputedStyle(document.querySelector('.tile')).borderTopWidth === '4px');
  await range('方塊間距').evaluate((el) => { el.focus(); });
  await page.locator('.slider:has(input[aria-label="方塊間距"]) .reset').click();
  await page.locator('.slider:has(input[aria-label="外側留白"]) .reset').click();
  await page.locator('.slider:has(input[aria-label="邊框粗細"]) .reset').click();
  await app.waitFor(() => viewsMatch(), 'back to defaults');
  ok('gap / padding / frame sliders re-tile the native views live, ↺ puts them back');

  await box('顯示方塊標題列').uncheck();
  await until(page, () => document.documentElement.classList.contains('no-head'));
  assert.strictEqual(await page.locator('.tile .head').first().isHidden(), true);
  assert.strictEqual(await cssVar(page, '--head-h'), '0px');
  await app.waitFor(() => viewsMatch({ headH: 0 }), 'no header');
  await box('顯示方塊標題列').check();
  await until(page, () => !document.documentElement.classList.contains('no-head'));
  await range('標題列高度').fill('40');
  await app.waitFor(() => viewsMatch({ headH: 40 }), 'headH 40');
  await until(page, () => getComputedStyle(document.querySelector('.tile .head')).height === '38px');
  await range('標題列高度').evaluate((el) => el.blur());
  await page.locator('.slider:has(input[aria-label="標題列高度"]) .reset').click();
  await app.waitFor(() => viewsMatch(), 'headH back');
  ok('tile header can be hidden or resized; the page views move with it');

  await range('自動網格的欄數').fill('2');
  await app.waitFor(() => viewsMatch({ cols: 2 }), 'cols 2');
  assert.strictEqual(await page.locator('.slider:has(input[aria-label="自動網格的欄數"]) .val').textContent(), '2 欄');
  await page.locator('.slider:has(input[aria-label="自動網格的欄數"]) .reset').click();
  await until(page, () => document.querySelector('.slider:has(input[aria-label="自動網格的欄數"]) .val').textContent === '自動');
  ok('auto-grid column count');

  // 工具列按鈕
  await box('工具列:首頁按鈕').check();
  await until(page, () => document.documentElement.classList.contains('show-home'));
  await page.locator('#btn-home').click();
  await app.waitFor(() => /newtab\.html$/.test(app.activeWC().loaded[app.activeWC().loaded.length - 1]), 'home → new-tab page');
  await box('工具列:上一頁 / 下一頁 / 重新整理').uncheck();
  await until(page, () => document.documentElement.classList.contains('hide-nav'));
  assert.strictEqual(await page.locator('#btn-back').isHidden(), true);
  assert.strictEqual(await page.locator('#btn-reload').isHidden(), true);
  await box('工具列:畫面配置按鈕').uncheck();
  assert.strictEqual(await page.locator('.layouts').isHidden(), true);
  await box('工具列:擴充功能按鈕').uncheck();
  assert.strictEqual(await page.locator('#btn-ext').isHidden(), true);
  assert.strictEqual(await page.locator('#btn-settings').isVisible(), true, 'the settings button can never be hidden');
  assert.strictEqual(await page.locator('#addr').isVisible(), true);
  for (const label of ['工具列:上一頁 / 下一頁 / 重新整理', '工具列:畫面配置按鈕', '工具列:擴充功能按鈕']) await box(label).check();
  await box('工具列:首頁按鈕').uncheck();
  await until(page, () => !document.documentElement.classList.contains('hide-nav') && !document.documentElement.classList.contains('show-home'));
  assert.strictEqual(await page.locator('.layouts').isVisible(), true);
  ok('toolbar buttons can be hidden individually (settings and the address bar stay); the home button works');

  // 分頁列
  await box('顯示分頁列').uncheck();
  await until(page, () => document.documentElement.classList.contains('no-strip'));
  assert.strictEqual(await page.locator('#tabstrip').isHidden(), true);
  assert.strictEqual(await cssVar(page, '--chrome-h'), '44px');
  await app.waitFor(() => viewsMatch({ chromeH: 44 }), 'chrome 44');
  assert.strictEqual(await page.locator('#toolbar').evaluate((el) => el.getBoundingClientRect().top), 0, 'toolbar moves up to the top edge');
  await box('顯示分頁列').check();
  await app.waitFor(() => viewsMatch(), 'strip back');
  ok('the tab strip can be hidden; toolbar and page views move up');

  // 側邊面板寬度
  await range('側邊面板寬度').fill('620');
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--panel-w').trim() === '620px');
  await app.waitFor(() => viewsMatch({ panelW: 620 }), 'panel 620');
  await page.locator('.slider:has(input[aria-label="側邊面板寬度"]) .reset').click();
  await until(page, () => getComputedStyle(document.documentElement).getPropertyValue('--panel-w').trim() === '480px');
  ok('side panel width follows its slider (never below 480px in settings mode)');

  // 視窗
  await box('視窗永遠在最上層').check();
  await app.waitFor(() => app.win.onTop === true, 'always on top');
  await range('視窗不透明度').fill('60');
  await app.waitFor(() => app.win.opacity === 0.6, 'opacity 0.6');
  await box('視窗永遠在最上層').uncheck();
  await app.waitFor(() => app.win.onTop === false);
  ok('window: always-on-top and opacity reach the BrowserWindow');

  await page.locator('select[aria-label="啟動時的配置"]').selectOption('cols');
  assert.strictEqual((await savedSettings()).layout.startLayout, 'cols');
  await page.locator('select[aria-label="啟動時的配置"]').selectOption('last');

  await shot('settings-layout-light');
  const layoutReset = panelOf('layout').locator('.sreset .btn');
  await range('視窗不透明度').evaluate((el) => el.blur());
  await layoutReset.click();
  await layoutReset.click();
  await app.waitFor(() => app.win.opacity === 1, 'window defaults restored');
  assert.strictEqual(await range('視窗不透明度').inputValue(), '100');
  ok('"restore this page" for layout + window puts every value back');

  /* ──────────────── 4. 瀏覽 ──────────────── */
  await openSection('browsing');
  const lastLoaded = () => { const l = app.activeWC().loaded; return l[l.length - 1]; };
  const goAddr = async (text) => {
    await page.locator('#addr').click();
    await page.locator('#addr').fill(text);
    await page.locator('#addr').press('Enter');
  };

  // 搜尋引擎:新增、關鍵字、設為預設、刪除
  assert.strictEqual(await page.locator('.engine').count(), 8);
  await page.getByRole('button', { name: '新增搜尋引擎' }).click();
  await until(page, () => document.querySelectorAll('.engine').length === 9);
  const eng = page.locator('.engine').last();
  assert.strictEqual(await eng.locator('.e-name').evaluate((el) => document.activeElement === el), true, 'the new row takes the cursor');
  await eng.locator('.e-name').fill('MyEng'); await eng.locator('.e-name').press('Enter');
  await eng.locator('.e-kw').fill('@me'); await eng.locator('.e-kw').press('Enter');
  await eng.locator('.e-url').fill('https://my.example/?q=%s'); await eng.locator('.e-url').press('Enter');
  await sleep(450);
  const mine = app.settingsOnDisk().browsing.engines.find((e) => e.name === 'MyEng');
  assert(mine && mine.keyword === '@me' && mine.url === 'https://my.example/?q=%s', JSON.stringify(mine));
  await goAddr('@me hello world');
  await app.waitFor(() => lastLoaded() === 'https://my.example/?q=hello%20world', 'keyword search');
  await goAddr('@yt 貓咪');
  await app.waitFor(() => lastLoaded() === 'https://www.youtube.com/results?search_query=' + encodeURIComponent('貓咪'), 'built-in keyword');
  ok('search engines: add one, give it a @keyword, and the address bar uses it (built-in @yt too)');

  await page.locator('.engine').last().locator('.defpick input').check();
  await sleep(450);
  assert.strictEqual(app.settingsOnDisk().browsing.defaultEngine, mine.id);
  await goAddr('hello world');
  await app.waitFor(() => lastLoaded() === 'https://my.example/?q=hello%20world', 'default engine');
  await page.locator('.engine').last().locator('.e-url').fill('not a url');
  await page.locator('.engine').last().locator('.e-url').press('Enter');
  await until(page, () => /搜尋網址要以 http/.test(document.getElementById('panel-note').textContent));
  assert.strictEqual(await page.locator('.engine').last().locator('.e-url').getAttribute('aria-invalid'), 'true');
  await sleep(450);
  assert.strictEqual(app.settingsOnDisk().browsing.engines.find((e) => e.id === mine.id).url, 'https://my.example/?q=%s', 'invalid URL is never saved');
  await page.locator('.engine').last().locator('.mini').click();
  await until(page, () => document.querySelectorAll('.engine').length === 8);
  await sleep(450);
  assert.strictEqual(app.settingsOnDisk().browsing.defaultEngine, 'google', 'deleting the default engine falls back to the first one');
  await goAddr('hello world');
  await app.waitFor(() => lastLoaded().startsWith('https://www.google.com/search?q=hello'), 'google again');
  ok('default engine switch, invalid URL refused with a note, delete falls back to the first engine');

  // 預設縮放
  const zoomLevel = (pct) => Math.log(pct / 100) / Math.log(1.2);
  await goAddr('https://zoom.example/page');
  app.finishLoad(app.activeWC());
  await range('預設縮放').fill('150');
  await app.waitFor(() => Math.abs(app.activeWC().zoom - zoomLevel(150)) < 0.01, 'zoom 150%');
  await range('預設縮放').evaluate((el) => el.blur());
  await page.locator('.slider:has(input[aria-label="預設縮放"]) .reset').click();
  await app.waitFor(() => Math.abs(app.activeWC().zoom) < 0.01, 'zoom back to 100%');
  ok('default zoom applies to a page that has no zoom of its own, and releases it when reset');

  // 首頁、新分頁、啟動方式
  await page.locator('select[aria-label="啟動時"]').selectOption('home');
  const home = page.locator('input[aria-label="首頁網址"]');
  await home.fill('example.com'); await home.press('Enter');
  await until(page, () => /首頁網址要以/.test(document.getElementById('panel-note').textContent));
  assert.strictEqual(await home.inputValue(), '', 'a homepage without a scheme is refused and the field goes back');
  await home.fill('https://home.example/'); await home.press('Enter');
  await sleep(450);
  assert.strictEqual(app.settingsOnDisk().browsing.homepage, 'https://home.example/');
  assert.strictEqual(app.settingsOnDisk().browsing.startup, 'home');
  await page.locator('select[aria-label="新分頁開啟"]').selectOption('home');
  const before = app.win.children.length;
  await page.locator('#btn-newtab').click();
  await app.waitFor(() => app.win.children.length === before + 1, 'new tab');
  assert.strictEqual(app.win.children[before].webContents.loaded.pop(), 'https://home.example/');
  await page.locator('select[aria-label="新分頁開啟"]').selectOption('blank');
  await page.locator('#btn-newtab').click();
  await app.waitFor(() => app.win.children.length === before + 2, 'new blank tab');
  assert.strictEqual(app.win.children[before + 1].webContents.loaded.pop(), 'about:blank');
  await page.locator('select[aria-label="新分頁開啟"]').selectOption('builtin');
  await page.locator('#btn-newtab').click();
  await app.waitFor(() => app.win.children.length === before + 3, 'new built-in tab');
  assert(/newtab\.html$/.test(app.win.children[before + 2].webContents.loaded.pop()));
  // 收掉多開的分頁
  for (let i = 0; i < 3; i++) await page.locator('.tab').last().locator('.close').click({ force: true });
  await app.waitFor(() => app.win.children.length === before, 'extra tabs closed');
  ok('startup mode, homepage validation, and what a new tab opens (home / blank / built-in page)');

  // 自動重新整理的選項 → 右鍵選單
  const refresh = page.locator('input[aria-label="自動重新整理可選的間隔(秒)"]');
  await refresh.fill('abc'); await refresh.press('Enter');
  await until(page, () => /5 到 86400/.test(document.getElementById('panel-note').textContent));
  assert.strictEqual(await refresh.inputValue(), '10, 30, 60, 300, 900');
  await refresh.fill('15, 45, 90'); await refresh.press('Enter');
  await until(page, () => document.querySelector('input[aria-label="自動重新整理可選的間隔(秒)"]').value === '15, 45, 90');
  app.calls.menus.length = 0;
  app.send(app.win, 'tab:menu', app.state().activeId);
  const menu = app.calls.menus[app.calls.menus.length - 1];
  const sub = menu.find((m) => m.label === '自動重新整理').submenu.map((m) => m.label);
  assert.deepStrictEqual(sub, ['關閉', '每 15 秒', '每 45 秒', '每 1.5 分鐘']);
  await page.locator('.slider:has(input[aria-label="預設縮放"])').scrollIntoViewIfNeeded();
  ok('refresh intervals: bad input refused, good input shows up in the tab right-click menu');

  // 網站權限
  const askBefore = app.boxes.length;
  const askPerm = (perm) => new Promise((res) => app.permHandler()(app.activeWC(), perm, res, { requestingUrl: 'https://cam.example/' }));
  assert.strictEqual(await askPerm('media'), true, 'default = ask → our fake dialog answers allow');
  assert.strictEqual(app.boxes.length, askBefore + 1);
  await page.locator('select[aria-label="攝影機與麥克風"]').selectOption('block');
  await sleep(100);
  assert.strictEqual(await askPerm('media'), false);
  assert.strictEqual(app.boxes.length, askBefore + 1, 'blocked without asking');
  await page.locator('select[aria-label="攝影機與麥克風"]').selectOption('allow');
  await sleep(100);
  assert.strictEqual(await askPerm('media'), true);
  assert.strictEqual(app.boxes.length, askBefore + 1, 'allowed without asking');
  assert.strictEqual(app.permCheck()(app.activeWC(), 'media', 'https://cam.example/'), true);
  assert.strictEqual(await askPerm('openExternal'), false, 'unknown permissions stay denied');
  ok('site permission policy: ask / block / allow reaches the session handlers');

  // User-Agent 與語言
  const ua = page.locator('select[aria-label="User-Agent"]');
  await ua.selectOption({ label: 'Firefox · Windows' });
  await app.waitFor(() => /Firefox\/140/.test(app.ses.ua), 'firefox UA');
  await ua.selectOption('__custom');
  const uaText = page.locator('input[aria-label="User-Agent(自訂)"]');
  await uaText.fill('MyBot/1.0'); await uaText.press('Enter');
  await app.waitFor(() => app.ses.ua === 'MyBot/1.0', 'custom UA');
  await ua.selectOption({ index: 0 });
  await app.waitFor(() => /Chrome\/\d+/.test(app.ses.ua) && !/Firefox|MyBot/.test(app.ses.ua), 'default UA back');
  const lang = page.locator('input[aria-label="Accept-Language"]');
  await lang.fill('zh-TW,zh;q=0.9,en;q=0.8'); await lang.press('Enter');
  await app.waitFor(() => app.ses.langs === 'zh-TW,zh;q=0.9,en;q=0.8', 'language');
  await lang.fill('zh-TW<script>'); await lang.press('Enter');
  await until(page, () => /語言格式不正確/.test(document.getElementById('panel-note').textContent));
  ok('User-Agent presets / custom value and Accept-Language reach the session; a malformed language is refused');

  await shot('settings-browsing-light');
  const browsingReset = panelOf('browsing').locator('.sreset .btn');
  await browsingReset.click(); await browsingReset.click();
  await until(page, () => document.querySelector('select[aria-label="啟動時"]').value === 'restore');
  assert.strictEqual(await home.inputValue(), '');
  await app.waitFor(() => app.ses.langs === '', 'language cleared');
  ok('"restore this page" for browsing clears homepage, language, UA and the rest');

  /* ──────────────── 5. 新分頁(設定 + 內建頁面本身) ──────────────── */
  // 一張漸層圖,等一下當背景用(用瀏覽器畫出來,不用另外裝圖片工具)
  const bgPng = path.join(app.tmp, 'bg.png');
  {
    const p3 = await ctx.newPage();
    await p3.setViewportSize({ width: 1280, height: 720 });
    await p3.setContent('<body style="margin:0;height:720px;background:radial-gradient(circle at 25% 30%,#ffd29a,transparent 45%),radial-gradient(circle at 80% 70%,#7aa7ff,transparent 50%),linear-gradient(135deg,#3b2a6b,#d1527a)"></body>');
    await p3.screenshot({ path: bgPng });
    await p3.close();
  }

  const newTabWCs = () => app.win.children.map((v) => v.webContents).filter((wc) => /newtab\.html$/i.test(wc.getURL()));
  let ntWC = newTabWCs()[0];
  if (!ntWC) { app.send(app.win, 'tab:new'); await app.flush(80); ntWC = newTabWCs()[0]; }
  assert(ntWC, 'there is a built-in new-tab tab to attach to');

  const nt = await ctx.newPage();
  await nt.setViewportSize({ width: 1000, height: 700 });
  watch(nt, 'newtab');
  await bridge(nt, app, ntWC, PRELOAD_TAB, 'newtab:boot');
  await nt.route(/^https?:/, (route) => route.fulfill({ status: 200, contentType: 'text/html', body: '<title>stub</title>stub page' }));
  await nt.goto(NEWTAB);
  await nt.waitForSelector('#title:not([hidden])');

  assert.strictEqual(await nt.locator('#title').textContent(), '索洛夫瀏覽器');
  assert.strictEqual(await nt.locator('#subtitle').textContent(), '同一個畫面,同時看很多個分頁。');
  assert.strictEqual(await nt.locator('#links li').count(), 6);
  assert.strictEqual(await nt.locator('#tip-list li').count(), 5);
  assert.deepStrictEqual(await nt.locator('#tip-list li').first().locator('kbd').allTextContents(), ['Ctrl', 'T']);
  assert.strictEqual(await nt.locator('#kw button').count(), 8, 'one chip per search keyword');
  assert.strictEqual(await nt.locator('#customize').isVisible(), true);
  assert.strictEqual(await nt.locator('#clock').isHidden(), true);
  assert.match(await nt.locator('#q').getAttribute('placeholder'), /Google/);
  assert.strictEqual(await nt.evaluate(() => typeof window.solovNewTab.boot), 'object');
  ok('new-tab page: real preload hands it the user\'s settings (title, links, tips with the current shortcut, keyword chips)');

  await openSection('newtab');
  const title = page.locator('input[aria-label="新分頁標題"]');
  await title.fill('Hi Solov');
  await nt.waitForFunction(() => document.getElementById('title').textContent === 'Hi Solov');
  await page.locator('input[aria-label="新分頁副標題"]').fill('');
  await nt.waitForFunction(() => document.getElementById('subtitle').hidden);
  await page.locator('input[aria-label="新分頁副標題"]').fill('我的起始頁');
  await nt.waitForFunction(() => document.getElementById('subtitle').textContent === '我的起始頁');
  ok('title and subtitle edits show up on the open new-tab page without reloading it');

  await box('搜尋框').uncheck();
  await nt.waitForFunction(() => document.getElementById('search').hidden);
  await box('搜尋框').check();
  await box('快速連結').uncheck();
  await nt.waitForFunction(() => document.getElementById('links').hidden);
  await box('快速連結').check();
  await box('使用提示').uncheck();
  await nt.waitForFunction(() => document.getElementById('tips').hidden);
  await box('使用提示').check();
  await box('時鐘').check();
  await nt.waitForFunction(() => !document.getElementById('clock').hidden && /^\d\d:\d\d$/.test(document.getElementById('time').textContent));
  assert.match(await nt.locator('#date').textContent(), /月.*日/);
  ok('show / hide the search box, quick links, tips and the clock');

  // 背景:純色(淺字 / 深字依底色決定)
  await page.locator('.seg[aria-label="背景"] button[data-value="color"]').click();
  await nt.waitForFunction(() => document.body.classList.contains('bg-color'));
  const bgColor = page.locator('input[type=color][aria-label="背景顏色"]');
  await bgColor.fill('#102030');
  await nt.waitForFunction(() => getComputedStyle(document.body).getPropertyValue('--nt-bg').trim() === '#102030' && document.body.classList.contains('tone-dark'));
  assert.strictEqual(await nt.evaluate(() => getComputedStyle(document.querySelector('h1')).color), 'rgb(241, 244, 246)', 'light text on a dark colour');
  await bgColor.fill('#f3ead8');
  await nt.waitForFunction(() => document.body.classList.contains('tone-light'));
  assert.strictEqual(await nt.evaluate(() => getComputedStyle(document.querySelector('h1')).color), 'rgb(28, 35, 41)', 'dark text on a light colour');
  await nt.screenshot({ path: path.join(OUT, 'fs-newtab-color-light.png') });
  await bgColor.fill('#1c2a33');
  await nt.waitForFunction(() => document.body.classList.contains('tone-dark'));
  await nt.screenshot({ path: path.join(OUT, 'fs-newtab-color-dark.png') });
  ok('background colour: text colour flips automatically between light and dark backgrounds');

  // 背景:圖片(選檔 → 複製進資料夾 → 套用)
  app.dialogs.open = { canceled: false, filePaths: [bgPng] };
  await page.locator('.seg[aria-label="背景"] button[data-value="image"]').click();
  await page.getByRole('button', { name: '選擇圖片…' }).click();
  await nt.waitForFunction(() => document.body.classList.contains('bg-image'));
  const imgUrl = app.settingsOnDisk && (await (async () => { await sleep(450); return app.settingsOnDisk().newtab.bg.image; })());
  assert(/^file:\/\/.*\/backgrounds\/newtab-bg-\d+\.png$/.test(imgUrl), imgUrl);
  assert(fs.existsSync(path.join(app.userData, 'backgrounds', path.basename(imgUrl))), 'the image was copied into the data folder');
  assert.strictEqual(await nt.evaluate(() => new Promise((res) => {
    const i = new Image(); i.onload = () => res([i.naturalWidth, i.naturalHeight]); i.onerror = () => res('error');
    i.src = document.getElementById('bg').style.backgroundImage.slice(5, -2);
  })).then((r) => r.join('x')), '1280x720', 'the stored background image really loads from the new-tab page');
  await range('圖片暗化').fill('55');
  await nt.waitForFunction(() => getComputedStyle(document.body).getPropertyValue('--nt-dim').trim() === '0.55');
  await nt.screenshot({ path: path.join(OUT, 'fs-newtab-image.png') });
  await page.getByRole('button', { name: '移除圖片' }).click();
  await nt.waitForFunction(() => !document.body.classList.contains('bg-image') && !document.body.classList.contains('bg-color'));
  ok('background image: picked file is copied next to the settings, shown with dimming, and removable');

  // 圖片檔不見了 → 退回預設外觀,頁面不會壞掉
  expectMissingFile = true; // 瀏覽器會在主控台記「圖片載入失敗」,這裡本來就是要測這件事,不算問題
  app.invoke(app.win, 'settings:update', { newtab: { bg: { mode: 'image', image: 'file:///nonexistent/missing.png' } } });
  await nt.waitForFunction(() => document.body.classList.contains('bg-image') === false && document.getElementById('title').textContent === 'Hi Solov');
  app.invoke(app.win, 'settings:update', { newtab: { bg: { mode: null, image: null, dim: null } } });
  await sleep(500);
  expectMissingFile = false;
  ok('a missing background image falls back to the default look');

  // 快速連結編輯器
  assert.strictEqual(await page.locator('.llist .link').count(), 6);
  await page.getByRole('button', { name: '新增連結' }).click();
  await until(page, () => document.querySelectorAll('.llist .link').length === 7);
  const lastLink = page.locator('.llist .link').last();
  assert.strictEqual(await lastLink.locator('input').first().evaluate((el) => document.activeElement === el), true);
  await lastLink.locator('input').nth(0).fill('Solov'); await lastLink.locator('input').nth(0).press('Enter');
  await lastLink.locator('input').nth(1).fill('https://solov.example/'); await lastLink.locator('input').nth(1).press('Enter');
  await nt.waitForFunction(() => Array.from(document.querySelectorAll('#links b')).some((b) => b.textContent === 'Solov'));
  assert.strictEqual(await nt.locator('#links a').last().getAttribute('href'), 'https://solov.example/');
  assert.strictEqual(await nt.locator('#links small').last().textContent(), 'solov.example');
  await page.locator('.llist .link').last().locator('.mini[title="往上移"]').click();
  await nt.waitForFunction(() => document.querySelectorAll('#links b')[5].textContent === 'Solov');
  await page.locator('.llist .link').nth(5).locator('.mini[title="往下移"]').click();
  await nt.waitForFunction(() => document.querySelectorAll('#links b')[6].textContent === 'Solov');
  await page.locator('.llist .link').last().locator('input').nth(1).fill('ftp://nope.example/');
  await page.locator('.llist .link').last().locator('input').nth(1).press('Enter');
  await until(page, () => /連結網址要以 http/.test(document.getElementById('panel-note').textContent));
  await page.locator('.llist .link').last().locator('.mini[title="刪除"]').click();
  await nt.waitForFunction(() => document.querySelectorAll('#links li').length === 6);
  ok('quick links: add, edit, reorder, delete — the open page follows; non-web URLs are refused');

  // 搜尋框:關鍵字與預設引擎
  await nt.locator('#kw button', { hasText: '@yt' }).click();
  assert.strictEqual(await nt.locator('#q').inputValue(), '@yt ');
  await nt.keyboard.type('貓咪');
  await nt.keyboard.press('Enter');
  await nt.waitForURL(/youtube\.com\/results\?search_query=/);
  assert(decodeURIComponent(nt.url()).endsWith('search_query=貓咪'), nt.url());
  await nt.goto(NEWTAB);
  await nt.locator('#q').fill('example.com'); await nt.locator('#q').press('Enter');
  await nt.waitForURL('https://example.com/');
  await nt.goto(NEWTAB);
  await nt.locator('#q').fill('一般 搜尋'); await nt.locator('#q').press('Enter');
  await nt.waitForURL(/google\.com\/search\?q=/);
  await nt.goto(NEWTAB);
  ok('new-tab search box: keyword chips, plain URLs and ordinary searches');

  // 點到頁面 → 該分頁成為使用中;「自訂這個頁面」→ 打開設定
  const ntIndex = app.win.children.findIndex((v) => v.webContents === ntWC);
  const other = app.state().tabs.find((t, i) => i !== ntIndex);
  app.send(app.win, 'tab:activate', other.id, false);
  await app.waitFor(() => app.state().activeId === other.id, 'other tab active');
  await nt.mouse.click(8, 8); // 頁面左上角的空白處(不要點到連結)
  await app.waitFor(() => app.state().activeId === app.state().tabs[ntIndex].id, 'click on the page activates its tab');
  await page.locator('#btn-settings').click();
  await until(page, () => document.getElementById('panel').hidden);
  await nt.locator('#customize').click();
  await app.waitFor(() => app.state().panelOpen && app.state().panelMode === 'settings', 'customize opens settings');
  await until(page, () => !document.getElementById('view-settings').hidden);
  ok('clicking the page activates its tab; “customize this page” opens the settings panel');

  // 安全:其他網頁分頁不能拿設定、不能叫主程序做事
  const webWC = app.win.children.map((v) => v.webContents).find((wc) => !/newtab\.html$/i.test(wc.getURL()));
  assert(webWC, 'a normal web tab exists');
  assert.strictEqual(app.sendFrom(webWC, 'newtab:boot'), null, 'a normal page gets nothing from newtab:boot');
  const tabsBefore = app.win.children.length;
  app.sendFrom(webWC, 'action:run', 'tab.new');
  app.sendFrom(webWC, 'tab:new');
  app.sendFrom(webWC, 'newtab:open-settings');
  await assert.rejects(Promise.resolve().then(() => app.invokeFrom(webWC, 'settings:update', { customCss: 'body{display:none}' })), /forbidden/);
  await assert.rejects(Promise.resolve().then(() => app.invokeFrom(webWC, 'settings:export', false)), /forbidden/);
  await app.flush(100);
  assert.strictEqual(app.win.children.length, tabsBefore, 'web pages cannot drive the browser UI');
  assert.strictEqual(app.settingsOnDisk().customCss, '');
  ok('security: ordinary web tabs cannot read the new-tab data or call any UI/settings channel');

  /* ──────────────── 6. 快速鍵 ──────────────── */
  await openSection('shortcuts');
  const krow = (id) => page.locator(`.krow[data-action="${id}"]`);
  const addBtn = (id) => krow(id).locator('.btn.small').first();
  const chipsOf = async (id) => (await krow(id).locator('kbd.chip').allTextContents()).map((t) => t.replace(/×$/, '').trim());
  const kmsg = (id) => krow(id).locator('.kmsg');
  const wcA = () => app.activeWC();
  const probe = () => { const wc = wcA(); const n = wc.reloads; const prevented = app.press(wc, { key: 'F5' }); return prevented && wc.reloads === n + 1; };

  // 搜尋篩選
  assert.strictEqual(await page.locator('.krow').count(), ACTIONS.length);
  await page.locator('input[aria-label="搜尋動作或快速鍵"]').fill('新增分頁');
  await until(page, () => document.querySelectorAll('.krow:not([hidden])').length === 1);
  assert.strictEqual(await page.locator('.kgroup:not([hidden])').count(), 1, 'groups with no match disappear');
  await page.locator('input[aria-label="搜尋動作或快速鍵"]').fill('ctrl+shift+g');
  await until(page, () => document.querySelectorAll('.krow:not([hidden])').length === 1 && document.querySelector('.krow:not([hidden])').dataset.action === 'layout.cycle');
  await page.locator('input[aria-label="搜尋動作或快速鍵"]').fill('zzzzz');
  await until(page, () => document.querySelectorAll('.krow:not([hidden])').length === 0);
  assert.strictEqual(await page.getByText('沒有符合的動作。').isVisible(), true);
  await page.locator('input[aria-label="搜尋動作或快速鍵"]').fill('');
  await until(page, (n) => document.querySelectorAll('.krow:not([hidden])').length === n, ACTIONS.length);
  ok(`shortcut list: all ${ACTIONS.length} actions, filter by name or by key combination`);

  // 錄製新的快速鍵:錄製中主程序不攔截任何按鍵
  assert.strictEqual(probe(), true, 'F5 reloads before recording');
  await addBtn('tab.new').click();
  await until(page, () => !!document.querySelector('.krow[data-action="tab.new"] .kmsg.rec'));
  assert.strictEqual(app.press(wcA(), { key: 'F5' }), false, 'while recording the main process lets every key through');
  await page.keyboard.press('Control');                        // 只按修飾鍵:繼續等
  assert.strictEqual(await kmsg('tab.new').getAttribute('class'), 'kmsg rec');
  await page.keyboard.press('Control+Shift+Y');
  await until(page, () => document.querySelectorAll('.krow[data-action="tab.new"] kbd.chip').length === 2);
  assert.deepStrictEqual(await chipsOf('tab.new'), ['Ctrl+T', 'Ctrl+Shift+Y']);
  assert.strictEqual(probe(), true, 'recording is over → shortcuts work again');
  const n0 = app.win.children.length;
  assert.strictEqual(app.press(wcA(), { key: 'y', control: true, shift: true }), true);
  await app.waitFor(() => app.win.children.length === n0 + 1, 'Ctrl+Shift+Y opens a tab');
  assert.strictEqual(app.settingsOnDisk && (await (async () => { await sleep(450); return JSON.stringify(app.settingsOnDisk().shortcuts); })()), JSON.stringify({ 'tab.new': ['Ctrl+T', 'Ctrl+Shift+Y'] }));
  app.send(app.win, 'tab:close', app.state().activeId);
  await app.waitFor(() => app.win.children.length === n0, 'extra tab closed');
  ok('recording: main stops intercepting keys, the new combo is saved, listed and works immediately');

  // 衝突:改用在這裡
  await addBtn('nav.reload').click();
  await page.keyboard.press('Control+W');
  await until(page, () => /「關閉目前分頁」已經在用 Ctrl\+W/.test(document.querySelector('.krow[data-action="nav.reload"] .kmsg').textContent));
  await kmsg('nav.reload').getByRole('button', { name: '改用在這裡' }).click();
  await until(page, () => document.querySelectorAll('.krow[data-action="nav.reload"] kbd.chip').length === 3);
  assert.deepStrictEqual(await chipsOf('nav.reload'), ['F5', 'Ctrl+R', 'Ctrl+W']);
  assert.deepStrictEqual(await chipsOf('tab.close'), ['Ctrl+F4']);
  const w0 = wcA().reloads; const c0 = app.win.children.length;
  assert.strictEqual(app.press(wcA(), { key: 'w', control: true }), true);
  assert.strictEqual(wcA().reloads, w0 + 1, 'Ctrl+W now reloads');
  assert.strictEqual(app.win.children.length, c0, 'and no longer closes the tab');
  // 衝突:取消
  await addBtn('nav.reload').click();
  await page.keyboard.press('Control+F4');
  await until(page, () => /已經在用 Ctrl\+F4/.test(document.querySelector('.krow[data-action="nav.reload"] .kmsg').textContent));
  await kmsg('nav.reload').getByRole('button', { name: '取消' }).click();
  assert.deepStrictEqual(await chipsOf('tab.close'), ['Ctrl+F4']);
  assert.deepStrictEqual(await chipsOf('nav.reload'), ['F5', 'Ctrl+R', 'Ctrl+W']);
  ok('conflicts: the owner is named, “use it here” takes the key over, “cancel” changes nothing');

  // 不能用的組合、重複、Esc 取消
  await addBtn('zoom.in').click();
  await page.keyboard.press('a');
  await until(page, () => /不能用/.test(document.querySelector('.krow[data-action="zoom.in"] .kmsg').textContent));
  await page.keyboard.press('Control+C');
  await until(page, () => /Ctrl\+C 不能用/.test(document.querySelector('.krow[data-action="zoom.in"] .kmsg').textContent));
  assert.strictEqual(app.press(wcA(), { key: 'F5' }), false, 'still recording after a rejected combo');
  await page.keyboard.press('Escape');
  await until(page, () => document.querySelector('.krow[data-action="zoom.in"] .kmsg').textContent === '');
  assert.strictEqual(probe(), true, 'Esc ends the recording');
  await addBtn('tab.new').click();
  await page.keyboard.press('Control+T');
  await until(page, () => /已經有這個快速鍵了/.test(document.querySelector('.krow[data-action="tab.new"] .kmsg').textContent));
  await addBtn('zoom.out').click();                       // 開始錄另一個 → 前一個自動結束
  await until(page, () => !!document.querySelector('.krow[data-action="zoom.out"] .kmsg.rec'));
  assert.strictEqual(await kmsg('tab.new').textContent(), '');
  await page.keyboard.press('Escape');
  ok('rejected combos (no modifier, Ctrl+C) and duplicates explain themselves; Esc ends the recording');

  // 移除、還原、取消綁定;按鈕提示與新分頁頁面的提示跟著變
  await krow('tab.new').locator('kbd.chip', { hasText: 'Ctrl+T' }).locator('.x').click();
  await until(page, () => document.querySelectorAll('.krow[data-action="tab.new"] kbd.chip').length === 1);
  await until(page, () => document.getElementById('btn-newtab').title === '新增分頁 (Ctrl+Shift+Y)');
  await nt.waitForFunction(() => document.querySelector('#tip-list li').querySelectorAll('kbd').length === 3);
  assert.deepStrictEqual(await nt.locator('#tip-list li').first().locator('kbd').allTextContents(), ['Ctrl', 'Shift', 'Y']);
  assert.strictEqual(await krow('tab.new').locator('.reset').evaluate((el) => getComputedStyle(el).visibility), 'visible');
  await krow('tab.new').locator('.reset').click();
  await until(page, () => document.getElementById('btn-newtab').title === '新增分頁 (Ctrl+T)');
  assert.deepStrictEqual(await chipsOf('tab.new'), ['Ctrl+T']);
  await krow('zoom.reset').locator('.x').click();
  await until(page, () => document.querySelector('.krow[data-action="zoom.reset"] .none'));
  const z0 = wcA().zoom;
  assert.strictEqual(app.press(wcA(), { key: '0', control: true }), false, 'an unbound action no longer has a shortcut');
  assert.strictEqual(wcA().zoom, z0);
  await krow('zoom.reset').locator('.reset').click();
  await until(page, () => document.querySelectorAll('.krow[data-action="zoom.reset"] kbd.chip').length === 1);
  assert.strictEqual(app.press(wcA(), { key: '0', control: true }), true);
  ok('removing / unbinding / restoring a shortcut updates the keymap, button tooltips and the new-tab page tips');

  // 重複使用的快速鍵 → 警告列 + 紅色標示
  await app.invoke(app.win, 'settings:update', { shortcuts: { 'tab.close': ['Ctrl+R'] } });
  await until(page, () => !document.querySelector('.kwarn[role=status]:not([hidden])') === false);
  assert.match(await page.locator('#settings-body .kwarn').first().textContent(), /有 1 組快速鍵重複使用/);
  assert.strictEqual(await page.locator('kbd.chip.clash').count(), 1);
  assert.strictEqual(await krow('nav.reload').locator('kbd.chip.clash').count(), 1, 'the later action is the one that loses');
  await shot('settings-shortcuts-light');
  const kReset = panelOf('shortcuts').locator('.sreset .btn');
  await kReset.click(); await kReset.click();
  await until(page, () => document.querySelectorAll('kbd.chip.clash').length === 0);
  assert.deepStrictEqual(await chipsOf('tab.close'), ['Ctrl+W', 'Ctrl+F4']);
  assert.deepStrictEqual(app.settingsOnDisk && (await (async () => { await sleep(450); return app.settingsOnDisk().shortcuts; })()), {});
  ok('duplicate bindings are flagged (the later action is marked as not working); “restore all” clears every override');

  /* ──────────────── 7. 進階:自訂 CSS、匯出 / 匯入、清除資料、全部重設 ──────────────── */
  await openSection('advanced');
  const css = page.locator('textarea[aria-label="自訂 CSS"]');
  await css.fill('#btn-newtab { outline: 3px solid rgb(255, 0, 0); outline-offset: -3px }\nbody.__x { }');
  await until(page, () => document.getElementById('solov-user-css').textContent.includes('rgb(255, 0, 0)'));
  assert.strictEqual(await page.locator('#btn-newtab').evaluate((el) => getComputedStyle(el).outlineStyle), 'solid');
  await nt.waitForFunction(() => document.getElementById('solov-user-css').textContent.includes('rgb(255, 0, 0)'));
  await css.focus();
  await page.keyboard.press('Control+End');
  await page.keyboard.press('Tab');
  assert((await css.inputValue()).endsWith('  '), 'Tab inserts two spaces in the CSS box');
  await css.fill('this is { not valid css ::: }');
  await until(page, () => document.getElementById('solov-user-css').textContent.startsWith('this is'));
  assert.strictEqual(await page.locator('#tabstrip').isVisible(), true, 'broken CSS does not break the UI');
  await css.fill('#btn-newtab { outline: 3px solid rgb(255, 0, 0); outline-offset: -3px }');
  await until(page, () => document.getElementById('solov-user-css').textContent.includes('rgb(255, 0, 0)'));
  assert.strictEqual((await (async () => { await sleep(450); return app.settingsOnDisk().customCss; })()).includes('rgb(255, 0, 0)'), true);
  ok('custom CSS: live in the browser UI and on the new-tab page, Tab key indents, broken CSS is harmless');

  // 匯出(含腳本)
  const outFile = path.join(app.tmp, 'out', 'solov-settings.json');
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  app.dialogs.save = { canceled: false, filePath: outFile };
  await page.locator('.check:has(input[aria-label="匯出時一併包含腳本"]) input').check();
  await page.getByRole('button', { name: '匯出設定…' }).click();
  await until(page, () => /已匯出到/.test(document.getElementById('panel-note').textContent));
  const exported = JSON.parse(fs.readFileSync(outFile, 'utf8'));
  assert.strictEqual(exported.app, 'solov-browser');
  assert.strictEqual(exported.settings.customCss.includes('rgb(255, 0, 0)'), true);
  assert.strictEqual(exported.settings.newtab.title, 'Hi Solov');
  assert(Array.isArray(exported.scripts) && exported.scripts.length >= 1 && exported.scripts[0].code, 'scripts are included on request');
  assert.strictEqual(exported.settings.browsing.engines.length, 8);
  ok('export writes a plain JSON file (settings, and scripts when asked)');

  // 全部還原
  const resetAll = page.getByRole('button', { name: '全部還原成預設值' });
  await resetAll.click();
  assert.match(await page.getByRole('button', { name: '再按一次,真的要還原' }).textContent(), /真的要還原/);
  await page.getByRole('button', { name: '再按一次,真的要還原' }).click();
  await until(page, () => document.getElementById('solov-user-css').textContent === '' && document.getElementById('solov-theme').textContent === '');
  assert.strictEqual(await css.inputValue(), '');
  assert.strictEqual(await nt.locator('#title').textContent(), '索洛夫瀏覽器');
  assert.strictEqual(await page.evaluate(() => document.documentElement.className.includes('no-')), false);
  assert.deepStrictEqual(app.settingsOnDisk && (await (async () => { await sleep(450); return app.settingsOnDisk(); })()), (await app.invoke(app.win, 'settings:get')).defaults);
  ok('“restore everything” needs two clicks and writes the factory defaults to settings.json');

  // 匯入:含自訂 CSS 要確認
  const scriptList = async () => (await app.invoke(app.win, 'ui:ready')).scripts;
  const scriptsBefore = (await scriptList()).length;
  app.dialogs.open = { canceled: false, filePaths: [outFile] };
  app.dialogs.box = { response: 2 };                      // 取消
  await page.getByRole('button', { name: '匯入設定…' }).click();
  await app.waitFor(() => app.boxes.some((b) => b.message === '這個檔案含有自訂 CSS'), 'confirmation asked');
  await sleep(150);
  assert.strictEqual(await css.inputValue(), '', 'cancel imports nothing');
  assert.strictEqual((await scriptList()).length, scriptsBefore);
  app.dialogs.box = { response: 1 };                      // 匯入,但不要自訂 CSS
  await page.getByRole('button', { name: '匯入設定…' }).click();
  await until(page, () => /已匯入設定/.test(document.getElementById('panel-note').textContent));
  assert.strictEqual(await css.inputValue(), '', 'CSS left out on request');
  assert.strictEqual((await app.invoke(app.win, 'settings:get')).settings.newtab.title, 'Hi Solov', 'the rest of the settings came in');
  await app.waitFor(async () => (await scriptList()).length === scriptsBefore + 1, 'imported script listed');
  assert.strictEqual((await scriptList()).slice(-1)[0].enabled, false, 'imported scripts always start disabled');
  app.dialogs.box = { response: 0 };                      // 匯入(含 CSS)
  await page.getByRole('button', { name: '匯入設定…' }).click();
  await until(page, () => document.getElementById('solov-user-css').textContent.includes('rgb(255, 0, 0)'));
  assert.strictEqual(await css.inputValue(), '#btn-newtab { outline: 3px solid rgb(255, 0, 0); outline-offset: -3px }');
  ok('import: custom CSS needs confirmation (cancel / without CSS / with CSS), scripts arrive disabled');

  // 壞檔案
  const badFile = path.join(app.tmp, 'out', 'bad.json');
  fs.writeFileSync(badFile, '{ not json');
  app.dialogs.open = { canceled: false, filePaths: [badFile] };
  await page.getByRole('button', { name: '匯入設定…' }).click();
  await until(page, () => /匯入失敗.*不是有效的 JSON/.test(document.getElementById('panel-note').textContent));
  fs.writeFileSync(badFile, JSON.stringify({ hello: 'world' }));
  await page.getByRole('button', { name: '匯入設定…' }).click();
  await until(page, () => /找不到任何可以匯入的設定/.test(document.getElementById('panel-note').textContent));
  ok('import: broken / unrelated files are rejected with a clear message');

  // 清除瀏覽資料
  await page.locator('.check input[data-kind="cache"]').check();
  await page.locator('.check input[data-kind="cookies"]').check();
  app.dialogs.box = { response: 1 };                      // 取消
  await page.getByRole('button', { name: '清除選取的資料…' }).click();
  await app.waitFor(() => app.boxes.some((b) => /要清除:快取、Cookie/.test(b.message)), 'asked before clearing');
  assert.strictEqual(app.calls.clearCache, 0, 'cancel clears nothing');
  app.dialogs.box = { response: 0 };
  await page.getByRole('button', { name: '清除選取的資料…' }).click();
  await until(page, () => /已清除:快取、Cookie/.test(document.getElementById('panel-note').textContent));
  assert.strictEqual(app.calls.clearCache, 1);
  assert.deepStrictEqual(app.calls.clearStorage.map((c) => c.storages), [['cookies']]);
  await page.locator('.check input[data-kind="cache"]').uncheck();
  await page.locator('.check input[data-kind="cookies"]').uncheck();
  await page.getByRole('button', { name: '清除選取的資料…' }).click();
  await until(page, () => /先勾選要清除的項目/.test(document.getElementById('panel-note').textContent));
  ok('clear browsing data asks first, clears what was ticked, and refuses an empty selection');

  await page.getByRole('button', { name: '開啟資料夾' }).click();
  await app.waitFor(() => app.calls.openPath.includes(app.userData), 'open data folder');
  assert.match(await page.locator('#settings-body .tip').last().textContent(), /版本 9\.9\.9-test · 資料夾:.*userData/);
  assert.strictEqual(await page.locator('#settings-body .kwarn').last().isHidden(), true, 'no safe-mode banner in a normal run');
  ok('data folder button and the version / folder line');

  await shot('settings-advanced-light');
  await resetAll.click(); await page.getByRole('button', { name: '再按一次,真的要還原' }).click();
  await until(page, () => document.getElementById('solov-user-css').textContent === '');

  /* ──────────────── 8. 幾種不同的啟動情況(每一個都是全新的 main.js 實例) ──────────────── */
  const Settings = require('../lib/settings');
  const Theme = require('../lib/theme');
  const openUi = async (a, name, scheme = 'light') => {
    const c = await browser.newContext({ viewport: { width: 1400, height: 860 }, colorScheme: scheme });
    const pg = await c.newPage();
    watch(pg, name);
    await bridge(pg, a, a.win.webContents, PRELOAD_UI, 'ui:boot');
    await pg.goto(INDEX);
    await pg.waitForSelector('.tab');
    return pg;
  };
  const gotoSection = async (pg, id) => {
    if (await pg.locator('#panel').isHidden()) await pg.locator('#btn-settings').click();
    await pg.locator(`#settings-tabs .stab[data-section="${id}"]`).click();
    await pg.waitForFunction((sid) => !document.querySelector(`.spanel[data-section="${sid}"]`).hidden, id, { timeout: 4000 });
  };
  const advBanner = (pg) => pg.locator('.spanel[data-section="advanced"] .kwarn').first();
  const scriptsOf = async (a) => (await a.invoke(a.win, 'ui:ready')).scripts;

  // 8a. 手動改過的 settings.json:啟動時就要全部生效
  {
    const raw = {
      appearance: { theme: 'dark', accent: '#e11d48', density: 'compact', radius: 'round', fontSize: 15 },
      layout: { startLayout: 'cols', gap: 12, panelWidth: 520, toolbar: { home: true } },
      window: { alwaysOnTop: true, opacity: 90 },
      browsing: { startup: 'home', homepage: 'https://example.org/home', defaultZoom: 125 },
      shortcuts: { 'tab.new': ['Ctrl+Alt+N'] },
      newtab: { title: '我的首頁' },
    };
    const a = await startApp({ files: { 'userData/settings.json': raw } });
    const clean = Settings.sanitize(raw);
    assert.strictEqual(a.bootPayload().info.loadError, '');
    assert.strictEqual(a.electron.nativeTheme.themeSource, 'dark');
    assert.strictEqual(a.win.opts.backgroundColor, Theme.windowBackground(clean.appearance, true), 'window is created with the dark background (no white flash)');
    assert.strictEqual(a.win.opts.alwaysOnTop, true);
    assert.strictEqual(a.win.opacity, 0.9);
    assert.strictEqual(a.state().layout, 'cols', 'start layout');
    assert.strictEqual(a.win.children.length, 1);
    assert.deepStrictEqual(a.tabWC(0).loaded, ['https://example.org/home'], 'startup = open the home page');
    a.finishLoad(a.tabWC(0));
    assert(Math.abs(a.tabWC(0).zoom - Math.log(1.25) / Math.log(1.2)) < 0.01, 'default zoom 125% applied to the first page');
    const pg = await openUi(a, 'prefilled', 'dark');
    assert.strictEqual(await cssVar(pg, '--tab-h'), '32px', 'compact density');
    assert.strictEqual(await cssVar(pg, '--panel-w'), '520px');
    assert.strictEqual(await pg.locator('#btn-home').isVisible(), true, 'home button switched on');
    assert.strictEqual(await pg.locator('#btn-newtab').getAttribute('title'), '新增分頁 (Ctrl+Alt+N)');
    assert.notStrictEqual(await pg.locator('#solov-theme').textContent(), '', 'theme CSS is there from the first paint');
    const n0 = a.win.children.length;
    assert.strictEqual(a.press(a.activeWC(), { key: 't', control: true }), false, 'the replaced default is gone');
    assert.strictEqual(a.press(a.activeWC(), { key: 'n', control: true, alt: true }), true);
    await a.waitFor(() => a.win.children.length === n0 + 1, 'custom shortcut opens a tab');
    const nt2 = a.sendFrom(a.win.children[n0].webContents, 'newtab:boot');
    assert.strictEqual(nt2.title, '我的首頁');
    assert.strictEqual(nt2.keys.newTab, 'Ctrl+Alt+N', 'the new-tab page tips use the custom shortcut');
    await pg.screenshot({ path: path.join(OUT, 'fs-prefilled-dark.png') });
    ok('a hand-edited settings.json is honoured from the very first frame (theme, density, layout, window, startup, zoom, shortcuts)');
  }

  // 8b. 跟隨系統的深淺色:系統一切換,視窗底色也跟著換
  {
    const a = await startApp();
    const def = Settings.defaults().appearance;
    const light = Theme.windowBackground(def, false);
    const dark = Theme.windowBackground(def, true);
    assert.notStrictEqual(light, dark);
    assert.strictEqual(a.win.opts.backgroundColor, light);
    a.setSystemDark(true);
    assert.strictEqual(a.win.bg, dark, 'system → dark: window background follows');
    await a.invoke(a.win, 'settings:update', { appearance: { theme: 'light' } });
    assert.strictEqual(a.win.bg, light, 'forced light even though the system is dark');
    a.setSystemDark(false); a.setSystemDark(true);
    assert.strictEqual(a.win.bg, light, 'system changes are ignored while a fixed theme is chosen');
    await a.invoke(a.win, 'settings:update', { appearance: { theme: 'system' } });
    assert.strictEqual(a.win.bg, dark, 'back to following the system');
    ok('window background tracks the OS light / dark switch when the theme is “follow system”');
  }

  // 8c. 安全模式:自訂 CSS 不套用,但也不會被弄丟
  {
    const CSS = '#btn-newtab { display: none !important }';
    const a = await startApp({ argv: ['--safe-mode'], files: { 'userData/settings.json': { customCss: CSS, newtab: { title: 'Safe' } } } });
    const boot = a.bootPayload();
    assert.strictEqual(boot.info.safeMode, true);
    assert.strictEqual(boot.settings.customCss, '', 'safe mode: the custom CSS is not handed to the UI');
    assert.strictEqual(boot.settings.newtab.title, 'Safe', 'everything else loads normally');
    const pg = await openUi(a, 'safe mode');
    assert.strictEqual(await pg.locator('#solov-user-css').textContent(), '');
    assert.strictEqual(await pg.locator('#btn-newtab').isVisible(), true, 'the button the CSS would hide is still there');
    await gotoSection(pg, 'advanced');
    assert.match(await advBanner(pg).textContent(), /安全模式/);
    assert.strictEqual(await advBanner(pg).isVisible(), true);
    assert.strictEqual(await pg.locator('textarea[aria-label="自訂 CSS"]').inputValue(), '');
    await a.invoke(a.win, 'settings:update', { newtab: { title: 'Safe 2' } });
    await sleep(450);
    assert.strictEqual(a.settingsOnDisk().customCss, CSS, 'saving other settings keeps the withheld CSS in the file');
    assert.strictEqual(a.settingsOnDisk().newtab.title, 'Safe 2');
    const out = path.join(a.tmp, 'out', 'safe.json');
    fs.mkdirSync(path.dirname(out), { recursive: true });
    a.dialogs.save = { canceled: false, filePath: out };
    await a.invoke(a.win, 'settings:export', false);
    assert.strictEqual(JSON.parse(fs.readFileSync(out, 'utf8')).settings.customCss, CSS, 'export includes the withheld CSS');
    const again = await startApp({ files: { 'userData/settings.json': a.settingsOnDisk() } });
    assert.strictEqual(again.bootPayload().info.safeMode, false);
    assert.strictEqual(again.bootPayload().settings.customCss, CSS, 'the next normal start has the CSS back');
    await a.invoke(a.win, 'settings:update', { customCss: '/* fixed */' });
    await sleep(450);
    assert.strictEqual(a.settingsOnDisk().customCss, '/* fixed */', 'writing new CSS in safe mode replaces the withheld one');
    ok('safe mode: custom CSS is not applied (banner explains), yet it is kept in the file, exported, and back on the next normal start');
  }

  // 8d. 從舊版(MultiView)搬家
  {
    const cfg = {
      layout: 'rows', window: { width: 1200, height: 800 }, active: 2,
      tabs: [{ url: 'https://legacy.example/a', shown: true }, { url: 'https://legacy.example/b', shown: false }, { url: 'https://legacy.example/c', shown: true }],
    };
    const old = [{ id: 'old1', name: '舊腳本', code: "console.log('old')", enabled: true, match: '' }];
    for (const dir of ['MultiViewBrowser', 'multiview-browser']) {
      const a = await startApp({ files: { [`appData/${dir}/config.json`]: cfg, [`appData/${dir}/scripts.json`]: old } });
      assert.strictEqual(path.basename(a.bootPayload().info.migratedFrom), dir);
      assert.strictEqual(a.state().layout, 'rows');
      assert.deepStrictEqual(a.win.children.map((v) => v.webContents.loaded[0]), ['a', 'b', 'c'].map((x) => `https://legacy.example/${x}`));
      assert.deepStrictEqual(a.state().tabs.map((t) => t.shown), [true, false, true], 'hidden state carried over');
      assert.strictEqual(a.state().activeId, a.state().tabs[2].id, 'active tab carried over');
      const sc = await scriptsOf(a);
      assert.deepStrictEqual(sc.map((x) => [x.name, x.enabled]), [['舊腳本', true]]);
      assert(fs.existsSync(path.join(a.userData, 'config.json')) && fs.existsSync(path.join(a.userData, 'scripts.json')));
      assert(fs.existsSync(path.join(a.appData, dir, 'config.json')), 'the old folder is left untouched');
      if (dir === 'MultiViewBrowser') {
        const pg = await openUi(a, 'legacy');
        await gotoSection(pg, 'advanced');
        assert.match(await pg.locator('.spanel[data-section="advanced"] .tip').last().textContent(), /已從舊版搬入設定與腳本/);
      }
    }
    // 新資料夾裡已經有自己的設定 → 不搬
    const b = await startApp({ files: { 'userData/settings.json': {}, 'appData/MultiViewBrowser/config.json': cfg, 'appData/MultiViewBrowser/scripts.json': old } });
    assert.strictEqual(b.bootPayload().info.migratedFrom, '');
    assert.strictEqual(b.win.children.length, 1, 'fresh start: a single new-tab page');
    assert.deepStrictEqual((await scriptsOf(b)).map((x) => x.name).includes('舊腳本'), false);
    ok('first start after the rename carries over tabs, layout and scripts from either old folder name — only once, never over existing data');
  }

  // 8e. settings.json 壞掉,或有一堆不合理的值
  {
    const bad = '{ "appearance": { "theme": "dark", oops';
    const a = await startApp({ files: { 'userData/settings.json': bad } });
    const boot = a.bootPayload();
    assert.match(boot.info.loadError, /settings\.json 讀取失敗/);
    assert.strictEqual(fs.readFileSync(path.join(a.userData, 'settings.bad.json'), 'utf8'), bad, 'the broken file is kept for the user to repair');
    assert.deepStrictEqual(boot.settings, Settings.sanitize(null), 'defaults are used');
    const pg = await openUi(a, 'bad settings');
    await gotoSection(pg, 'advanced');
    assert.match(await advBanner(pg).textContent(), /settings\.json 讀取失敗/);
    await a.invoke(a.win, 'settings:update', { newtab: { title: 'ok' } });
    await sleep(450);
    assert.strictEqual(a.settingsOnDisk().newtab.title, 'ok', 'settings.json is a valid file again after the next change');
    assert.strictEqual(fs.readFileSync(path.join(a.userData, 'settings.bad.json'), 'utf8'), bad);

    const junk = {
      version: 99, extra: 1,
      appearance: { theme: 'purple', fontSize: 999, accent: 'red', colors: 'nope' },
      layout: { gap: -5, startLayout: 'weird', toolbar: 'yes' },
      shortcuts: { 'tab.new': 'Ctrl+T', 'nope.action': ['Ctrl+Q'], 'tab.close': ['x'] },
      browsing: { engines: [{ name: 'x' }], userAgent: 'x\ny' },
      newtab: { links: [{ name: 'bad', url: 'javascript:alert(1)' }] },
    };
    const c = await startApp({ files: { 'userData/settings.json': junk } });
    const jb = c.bootPayload();
    assert.strictEqual(jb.info.loadError, '');
    assert.deepStrictEqual(jb.settings, Settings.sanitize(junk));
    assert.strictEqual(jb.settings.appearance.theme, 'system');
    assert.strictEqual(jb.settings.layout.gap, 0);
    assert.deepStrictEqual(jb.settings.newtab.links, []);
    assert(!JSON.stringify(jb.settings).includes('javascript:'));
    assert.deepStrictEqual(jb.keymap.byAction['tab.close'], ['Ctrl+W', 'Ctrl+F4'], 'a shortcut list with nothing valid in it does not unbind the action');
    assert.strictEqual(c.press(c.activeWC(), { key: 'w', control: true }), true);
    const jpg = await openUi(c, 'junk settings');
    await gotoSection(jpg, 'appearance');
    ok('a broken settings.json falls back to defaults (original kept as settings.bad.json); nonsense values are corrected, not trusted');
  }

  // 8f. 介面頁面專用的通道,別的頁面叫不動
  {
    const a = await startApp();
    const web = a.win.children[0].webContents;
    assert.strictEqual(a.sendFrom(web, 'ui:boot'), null, 'a web tab gets nothing from ui:boot');
    assert.strictEqual(a.sendFrom({ id: 9999 }, 'ui:boot'), null, 'neither does an unknown sender');
    assert.notStrictEqual(a.sendFrom(a.win.webContents, 'ui:boot'), null);
    for (const ch of ['settings:get', 'settings:update', 'settings:export', 'ui:ready']) {
      await assert.rejects(() => a.invokeFrom(web, ch, {}), /forbidden/, ch);
    }
    ok('only the browser window itself can read or change settings (sync boot call included)');
  }

  console.log(`\n${checks} checks passed`);
  if (problems.length) {
    console.log('\nPAGE PROBLEMS (console errors / warnings / CSP violations):');
    for (const p of problems) console.log('  - ' + p);
  } else {
    console.log('no console errors, page errors or CSP violations');
  }
  await browser.close();
  process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });

'use strict';
/* 測試用:用「假的 electron 模組」把 main.js 實際跑起來,回傳一組可以操作與檢查的把手。
 * 每次 startApp() 都會建立全新的資料夾與全新的 main.js 實例(模組快取會清掉),
 * 所以每個測試情境之間不會互相影響。 */
const assert = require('assert');
const Module = require('module');
const EventEmitter = require('events');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { pathToFileURL } = require('url');

const ROOT = path.resolve(__dirname, '..', '..');
const MAIN = path.join(ROOT, 'main.js');

process.setMaxListeners(100); // 每個 main.js 實例都會掛自己的 uncaughtException / unhandledRejection 處理器;一個測試會建立很多個實例
let current = null; // 目前這個情境用的 electron 假物件
const origLoad = Module._load;
Module._load = function (req) {
  return req === 'electron' && current ? current : origLoad.apply(this, arguments);
};

let wcSeq = 1;
class FakeWC extends EventEmitter {
  constructor() {
    super();
    this.id = wcSeq++;
    this._url = ''; this._title = ''; this._loading = false; this._destroyed = false;
    this.executed = []; this.sent = []; this.loaded = []; this.zoom = 0; this.reloads = 0; this.nextResult = undefined;
    this.onSend = null;
    this.navigationHistory = { canGoBack: () => false, canGoForward: () => false, goBack() {}, goForward() {} };
  }
  isDestroyed() { return this._destroyed; }
  getURL() { return this._url; } getTitle() { return this._title; } isLoading() { return this._loading; }
  loadURL(u) { this._url = u; this._loading = true; this.loaded.push(u); return Promise.resolve(); }
  loadFile(f) { this._url = pathToFileURL(f).href; this._loading = true; this.loaded.push(f); return Promise.resolve(); }
  setWindowOpenHandler(fn) { this.openHandler = fn; }
  executeJavaScript(code) { this.executed.push(code); return Promise.resolve(this.nextResult); }
  focus() { this.focused = true; this.emit('focus'); }
  close() { this._destroyed = true; }
  send(ch, payload) { this.sent.push([ch, payload]); if (this.onSend) this.onSend(ch, payload); }
  setZoomLevel(z) { this.zoom = z; } getZoomLevel() { return this.zoom; }
  reload() { this.reloads++; } reloadIgnoringCache() { this.reloads++; } stop() {}
  setVisualZoomLevelLimits() { return Promise.resolve(); }
  isCurrentlyAudible() { return !!this._audible; } isAudioMuted() { return !!this._muted; } setAudioMuted(v) { this._muted = !!v; }
  isDevToolsOpened() { return !!this.devtools; } openDevTools() { this.devtools = true; } closeDevTools() { this.devtools = false; }
  inspectElement() {} copy() {} cut() {} paste() {} undo() {} redo() {} selectAll() {} downloadURL() {}
  setUserAgent(ua) { this.ua = ua; }
}
class FakeView {
  constructor(o) { this.opts = o; this.webContents = new FakeWC(); this.bounds = null; this.visible = true; }
  setBounds(b) { this.bounds = b; } setVisible(v) { this.visible = v; }
}

/** @param {object} [opts]
 *  @param {Object<string,any>} [opts.files]  先寫進資料夾的檔案(物件會轉成 JSON)
 *  @param {string[]} [opts.argv]             額外的命令列參數(例如 '--safe-mode')
 *  @param {boolean} [opts.skipLoad]          不要自動送出介面的 did-finish-load(不還原分頁) */
async function startApp(opts = {}) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'solov-app-'));
  const appData = path.join(tmp, 'appData');
  fs.mkdirSync(appData, { recursive: true });
  const userData = path.join(tmp, 'userData');
  for (const [name, content] of Object.entries(opts.files || {})) {
    const f = path.join(tmp, name);
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, typeof content === 'string' || Buffer.isBuffer(content) ? content : JSON.stringify(content));
  }

  const windows = [];
  const ipcOn = new Map();
  const ipcHandle = new Map();
  const boxes = [];
  const dialogs = { save: { canceled: true }, open: { canceled: true, filePaths: [] }, box: { response: 0 } };
  const calls = { clearCache: 0, clearStorage: [], openPath: [], menus: [] };
  let permHandler = null;
  let permCheck = null;

  class FakeWin extends EventEmitter {
    constructor(o) {
      super();
      this.opts = o; this.webContents = new FakeWC(); this.children = []; this._size = [1400, 860]; this._destroyed = false;
      this.log = { bg: [], onTop: [], opacity: [] };
      this.contentView = {
        addChildView: (v) => this.children.push(v),
        removeChildView: (v) => { this.children = this.children.filter((c) => c !== v); },
      };
      windows.push(this);
    }
    isDestroyed() { return this._destroyed; } getContentSize() { return this._size; }
    loadFile(f) { this.loaded = f; return Promise.resolve(); }
    show() { this.shown = true; } isVisible() { return !!this.shown; }
    maximize() {} isMaximized() { return false; } isMinimized() { return !!this.min; } restore() {} focus() {}
    getNormalBounds() { return { x: 0, y: 0, width: this._size[0], height: this._size[1] }; }
    setTitle(t) { this.title = t; } isFullScreen() { return !!this.fs; } setFullScreen(v) { this.fs = v; }
    setBackgroundColor(c) { this.bg = c; this.log.bg.push(c); }
    setAlwaysOnTop(v) { this.onTop = v; this.log.onTop.push(v); }
    setOpacity(v) { this.opacity = v; this.log.opacity.push(v); }
  }

  const ses = {
    ua: '', langs: '',
    setUserAgent(ua, langs) { this.ua = ua; this.langs = langs || ''; },
    setPermissionRequestHandler(f) { permHandler = f; },
    setPermissionCheckHandler(f) { permCheck = f; },
    clearCache() { calls.clearCache++; return Promise.resolve(); },
    clearStorageData(o) { calls.clearStorage.push(o); return Promise.resolve(); },
    clearAuthCache() { return Promise.resolve(); },
  };

  // 和真的一樣:themeSource 設成 dark / light 之後 shouldUseDarkColors 立刻跟著變;system 則看「系統偏好」(systemDark)
  const nativeTheme = new EventEmitter();
  nativeTheme.themeSource = 'system';
  nativeTheme.systemDark = false;
  Object.defineProperty(nativeTheme, 'shouldUseDarkColors', {
    get() { return this.themeSource === 'dark' || (this.themeSource === 'system' && this.systemDark); },
  });

  const electron = {
    app: Object.assign(new EventEmitter(), {
      whenReady: () => Promise.resolve(),
      getPath: (name) => ({ userData, appData, documents: path.join(tmp, 'documents') }[name] || tmp),
      getVersion: () => '9.9.9-test',
      requestSingleInstanceLock: () => true,
      quit() { this.quitted = true; }, setAppUserModelId() {}, userAgentFallback: '',
    }),
    BrowserWindow: FakeWin,
    WebContentsView: FakeView,
    ipcMain: { on: (c, f) => ipcOn.set(c, f), handle: (c, f) => ipcHandle.set(c, f) },
    Menu: {
      setApplicationMenu() {},
      buildFromTemplate: (tpl) => ({ tpl, popup() { calls.menus.push(tpl); } }),
    },
    session: { defaultSession: ses },
    shell: { openExternal: () => Promise.resolve(), openPath(p) { calls.openPath.push(p); return Promise.resolve(''); } },
    dialog: {
      showMessageBox: (...a) => { boxes.push(a[a.length - 1]); return Promise.resolve(dialogs.box); },
      showMessageBoxSync: () => 0,
      showOpenDialog: () => Promise.resolve(dialogs.open),
      showSaveDialog: () => Promise.resolve(dialogs.save),
    },
    clipboard: { copied: [], writeText(t) { this.copied.push(t); return Promise.resolve(); } },
    nativeTheme,
  };

  current = electron;
  const savedArgv = process.argv;
  process.argv = savedArgv.concat(opts.argv || []);
  delete require.cache[require.resolve(MAIN)];
  require(MAIN);
  const flush = (ms = 100) => new Promise((r) => setTimeout(r, ms));
  await flush(50);
  process.argv = savedArgv;

  const win = windows[0];
  assert(win, 'window created');

  const app = {
    tmp, userData, appData, win, windows, electron, boxes, dialogs, calls, ses, flush,
    permHandler: () => permHandler, permCheck: () => permCheck,
    send: (w, ch, ...a) => { const f = ipcOn.get(ch); assert(f, 'no ipc ' + ch); const e = { sender: w.webContents }; f(e, ...a); return e.returnValue; },
    invoke: (w, ch, ...a) => app.invokeFrom(w.webContents, ch, ...a),
    // ipcRenderer.invoke 一律回傳 Promise:處理函式丟出例外時,呼叫端看到的是被拒絕的 Promise
    invokeFrom: async (wc, ch, ...a) => { const f = ipcHandle.get(ch); assert(f, 'no ipc handler ' + ch); return f({ sender: wc }, ...a); },
    /** 以任意 webContents 當發送者(例如內建新分頁頁面) */
    sendFrom: (wc, ch, ...a) => { const f = ipcOn.get(ch); assert(f, 'no ipc ' + ch); const e = { sender: wc }; f(e, ...a); return e.returnValue; },
    lastSent: (w, ch) => { const s = w.webContents.sent.filter(([c]) => c === ch); return s.length ? s[s.length - 1][1] : null; },
    state: () => app.lastSent(win, 'state'),
    scripts: () => app.lastSent(win, 'scripts'),
    tabWC: (i) => win.children[i].webContents,
    /** 目前使用中分頁的 webContents */
    activeWC() { const st = app.state(); const i = st.tabs.findIndex((t) => t.id === st.activeId); return win.children[i].webContents; },
    settingsOnDisk: () => JSON.parse(fs.readFileSync(path.join(userData, 'settings.json'), 'utf8')),
    press(wc, input) {
      let prevented = false;
      wc.emit('before-input-event', { preventDefault() { prevented = true; } }, { type: 'keyDown', control: false, meta: false, shift: false, alt: false, ...input });
      return prevented;
    },
    /** 介面頁面一開始同步取得的設定資料(preload 的 ui:boot) */
    bootPayload: () => app.send(win, 'ui:boot'),
    /** 等到條件成立(或逾時丟錯) */
    async waitFor(fn, what = 'condition', ms = 3000) {
      const t0 = Date.now();
      for (;;) {
        let v;
        try { v = await fn(); } catch (_) { v = false; }
        if (v) return v;
        if (Date.now() - t0 > ms) throw new Error('timeout waiting for ' + what);
        await flush(25);
      }
    },
    /** 假裝某個分頁載入完成(停止轉圈圈、可以套用腳本) */
    finishLoad(wc) { wc._loading = false; wc.emit('did-stop-loading'); wc.emit('did-navigate'); wc.emit('dom-ready'); },
    /** 模擬作業系統切換深色 / 淺色模式 */
    setSystemDark(on) { nativeTheme.systemDark = !!on; nativeTheme.emit('updated'); },
    /** 介面載入完成 → 還原分頁 */
    loaded: async () => { win.webContents.emit('did-finish-load'); await flush(80); },
  };
  if (!opts.skipLoad) await app.loaded();
  return app;
}

module.exports = { startApp, ROOT, FakeWC };

'use strict';
const assert = require('assert');
const vm = require('vm');
const { computeLayout, rowPlan, splitSpan, METRICS } = require('../lib/layout');
const { normalizeInput, isNewTabUrl, isRunnableUrl } = require('../lib/urlutil');
const { wrapUserCode, ERR_PREFIX } = require('../lib/scriptwrap');
const { matchesUrl, parseUserscriptHeader } = require('../lib/match');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('  ok  ' + name); };

/* ---------- layout ---------- */
t('splitSpan fills exactly and is integer', () => {
  for (const total of [100, 997, 1920, 1333]) for (const count of [1, 2, 3, 4, 5, 7]) for (const gap of [0, 6]) {
    const parts = splitSpan(total, count, gap);
    assert.strictEqual(parts.length, count);
    const last = parts[count - 1];
    assert.strictEqual(last[0] + last[1], total, `total ${total} count ${count} gap ${gap}`);
    parts.forEach(([s, l], i) => {
      assert(Number.isInteger(s) && Number.isInteger(l) && l >= 0);
      if (i) assert.strictEqual(s, parts[i - 1][0] + parts[i - 1][1] + gap);
    });
  }
});

t('rowPlan: sums to n for every layout and window size', () => {
  for (const layout of ['grid', 'cols', 'rows']) for (let n = 1; n <= 30; n++) for (const [w, h] of [[300, 600], [800, 500], [1334, 740], [1900, 930], [3000, 1200], [10, 10]]) {
    const p = rowPlan(n, layout, w, h);
    assert.strictEqual(p.reduce((a, b) => a + b, 0), n, `${layout} ${n} ${w}x${h}`);
    assert(p.every((x) => x >= 1));
  }
});

t('rowPlan: sensible shapes on a wide window (1900x930)', () => {
  const w = 1900, h = 930;
  assert.deepStrictEqual(rowPlan(2, 'grid', w, h), [2]);
  assert.deepStrictEqual(rowPlan(3, 'grid', w, h), [2, 1]);
  assert.deepStrictEqual(rowPlan(4, 'grid', w, h), [2, 2]);
  assert.deepStrictEqual(rowPlan(5, 'grid', w, h), [3, 2]);
  assert.deepStrictEqual(rowPlan(6, 'grid', w, h), [3, 3]);
  assert.deepStrictEqual(rowPlan(9, 'grid', w, h), [3, 3, 3]);
  assert.deepStrictEqual(rowPlan(3, 'cols', w, h), [3]);
  assert.deepStrictEqual(rowPlan(3, 'rows', w, h), [1, 1, 1]);
  assert.deepStrictEqual(rowPlan(2, 'grid', 500, 900), [1, 1], 'portrait window stacks');
});

t('rowPlan: cols / rows fall back to several rows/columns when tiles would be unusably small', () => {
  // 1334 寬放 8 個:一列每個只有 ~160px,太窄 → 分成多排
  const cols = rowPlan(8, 'cols', 1334, 740);
  assert(cols.length > 1 && Math.max(...cols) * METRICS.MIN_TILE_W <= 1334, JSON.stringify(cols));
  // 540 高疊 8 個:每個只有 ~60px,太矮 → 每列放多個
  const rows = rowPlan(8, 'rows', 1000, 548);
  assert.deepStrictEqual(rows, [4, 4]);
  // 空間夠時維持使用者選的排法
  assert.deepStrictEqual(rowPlan(3, 'cols', 1334, 740), [3]);
  assert.deepStrictEqual(rowPlan(3, 'rows', 1334, 740), [1, 1, 1]);
  assert.deepStrictEqual(rowPlan(4, 'rows', 1900, 930), [1, 1, 1, 1]);
});

t('computeLayout: single / one tab = full area, no frame', () => {
  const a = computeLayout({ width: 1400, height: 880, chromeH: 82, panelW: 0, count: 1, layout: 'grid' });
  assert.strictEqual(a.split, false);
  assert.deepStrictEqual(a.tiles[0].view, { x: 0, y: 82, w: 1400, h: 798 });
  const b = computeLayout({ width: 1400, height: 880, chromeH: 82, panelW: 420, count: 3, layout: 'single' });
  assert.strictEqual(b.split, false);
  assert.strictEqual(b.tiles[0].view.w, 980);
});

t('computeLayout: tiles never overlap, stay inside area, and respect the side panel', () => {
  for (const layout of ['grid', 'cols', 'rows']) for (const count of [2, 3, 4, 5, 6, 7, 9, 12]) for (const panelW of [0, 420]) {
    const W = 1366, H = 768, chromeH = 82;
    const r = computeLayout({ width: W, height: H, chromeH, panelW, count, layout });
    assert.strictEqual(r.split, true);
    assert.strictEqual(r.tiles.length, count);
    r.tiles.forEach(({ outer, view }, i) => {
      assert(outer.x >= 0 && outer.y >= chromeH && outer.x + outer.w <= W - panelW && outer.y + outer.h <= H, `bounds ${layout} ${count}`);
      assert(view.x >= outer.x && view.y >= outer.y + METRICS.HEAD_H - 0 && view.x + view.w <= outer.x + outer.w && view.y + view.h <= outer.y + outer.h);
      assert(view.w > 0 && view.h > 0);
      r.tiles.slice(i + 1).forEach((o) => {
        const a = outer, b = o.outer;
        const overlap = a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
        assert(!overlap, `overlap ${layout} ${count}`);
      });
    });
  }
});

t('computeLayout: survives a tiny window without negative sizes', () => {
  const r = computeLayout({ width: 300, height: 120, chromeH: 82, panelW: 420, count: 6, layout: 'grid' });
  r.tiles.forEach(({ outer, view }) => { assert(outer.w >= 0 && outer.h >= 0 && view.w >= 0 && view.h >= 0); });
});

/* ---------- urlutil ---------- */
const S = 'https://s/?q=';
t('normalizeInput: urls, hosts, ports, search', () => {
  assert.strictEqual(normalizeInput('', S), null);
  assert.strictEqual(normalizeInput('   ', S), null);
  assert.strictEqual(normalizeInput('https://a.com/x?y=1', S), 'https://a.com/x?y=1');
  assert.strictEqual(normalizeInput('example.com', S), 'https://example.com');
  assert.strictEqual(normalizeInput('example.com/path?a=b#c', S), 'https://example.com/path?a=b#c');
  assert.strictEqual(normalizeInput('sub.example.co.uk:8080/x', S), 'https://sub.example.co.uk:8080/x');
  assert.strictEqual(normalizeInput('localhost:3000', S), 'http://localhost:3000');
  assert.strictEqual(normalizeInput('localhost', S), 'http://localhost');
  assert.strictEqual(normalizeInput('192.168.1.1', S), 'http://192.168.1.1');
  assert.strictEqual(normalizeInput('192.168.1.1:8080/admin', S), 'http://192.168.1.1:8080/admin');
  assert.strictEqual(normalizeInput('[::1]:8080', S), 'http://[::1]:8080');
  assert.strictEqual(normalizeInput('myserver:8080', S), 'http://myserver:8080');
  assert.strictEqual(normalizeInput('about:blank', S), 'about:blank');
  assert.strictEqual(normalizeInput('hello world', S), S + 'hello%20world');
  assert.strictEqual(normalizeInput('今天天氣', S), S + encodeURIComponent('今天天氣'));
  assert.strictEqual(normalizeInput('what is 1.5 + 2', S), S + encodeURIComponent('what is 1.5 + 2'));
  assert.strictEqual(normalizeInput('node', S), S + 'node');
  assert.strictEqual(normalizeInput('javascript:alert(1)', S), S + encodeURIComponent('javascript:alert(1)'));
  assert.strictEqual(normalizeInput('example.com is great', S), S + encodeURIComponent('example.com is great'));
});

t('isNewTabUrl / isRunnableUrl', () => {
  assert(isNewTabUrl('file:///C:/Users/x/app/resources/app.asar/renderer/newtab.html'));
  assert(isNewTabUrl('file:///home/u/SolovBrowser/renderer/newtab.html'));
  assert(!isNewTabUrl('file:///home/u/other.html'));
  assert(!isNewTabUrl('https://example.com/renderer/newtab.html'));
  assert(isRunnableUrl('https://a.com'));
  assert(isRunnableUrl('http://a.com'));
  assert(isRunnableUrl('file:///home/u/other.html'));
  assert(!isRunnableUrl('file:///home/u/SolovBrowser/renderer/newtab.html'));
  assert(!isRunnableUrl('about:blank'));
  assert(!isRunnableUrl('chrome-error://chromewebdata/'));
  assert(!isRunnableUrl(''));
  assert(!isRunnableUrl(undefined));
});

/* ---------- match ---------- */
t('matchesUrl: empty / nullish rules match everything', () => {
  for (const r of ['', '   ', null, undefined, ',', ' , ,']) assert.strictEqual(matchesUrl(r, 'https://a.com/'), true);
  assert.strictEqual(matchesUrl('*', 'https://a.com/'), true);
  assert.strictEqual(matchesUrl('<all_urls>', 'file:///x.html'), true);
});

t('matchesUrl: bare domain covers sub-domains but not look-alikes', () => {
  const r = 'youtube.com';
  assert(matchesUrl(r, 'https://youtube.com/'));
  assert(matchesUrl(r, 'https://www.youtube.com/watch?v=1'));
  assert(matchesUrl(r, 'http://m.youtube.com/'));
  assert(matchesUrl(r, 'https://YOUTUBE.com/'));
  assert(!matchesUrl(r, 'https://notyoutube.com/'));
  assert(!matchesUrl(r, 'https://youtube.com.evil.example/'));
  assert(!matchesUrl(r, 'https://example.com/?u=youtube.com'));
  assert(matchesUrl('*.example.com', 'https://a.b.example.com/x'));
  assert(matchesUrl('*.example.com', 'https://example.com/'));
  assert(!matchesUrl('*.example.com', 'https://badexample.com/'));
  assert(matchesUrl('www.*.com', 'https://www.foo.com/'));
  assert(!matchesUrl('www.*.com', 'https://foo.com/'));
});

t('matchesUrl: full URL globs (scheme and path matter)', () => {
  assert(matchesUrl('https://example.com/*', 'https://example.com/a?b=1#c'));
  assert(!matchesUrl('https://example.com/*', 'http://example.com/a'));
  assert(!matchesUrl('https://example.com/*', 'https://www.example.com/a'));
  assert(matchesUrl('https://*.example.com/*', 'https://www.example.com/a'));
  assert(matchesUrl('*://example.com/*', 'http://example.com/x'));
  assert(matchesUrl('*://example.com/*', 'https://example.com/x'));
  assert(matchesUrl('https://example.com/a.b*', 'https://example.com/a.bc'));
  assert(!matchesUrl('https://example.com/a.b*', 'https://example.com/aXb'), 'dot is literal');
  assert(matchesUrl('https://example.com/search?q=*', 'https://example.com/search?q=hi'), '? is literal');
  assert(matchesUrl('file:///*', 'file:///C:/x/y.html'));
});

t('matchesUrl: scheme-less patterns with a path match the URL without scheme', () => {
  assert(matchesUrl('example.com/docs*', 'https://example.com/docs/intro'));
  assert(matchesUrl('example.com/docs*', 'http://example.com/docs'));
  assert(!matchesUrl('example.com/docs*', 'https://example.com/blog'));
  assert(!matchesUrl('example.com/docs*', 'https://www.example.com/docs'));
});

t('matchesUrl: exclusions and multiple rules (comma, space, newline)', () => {
  const rules = 'example.com, !example.com/login*';
  assert(matchesUrl(rules, 'https://example.com/home'));
  assert(!matchesUrl(rules, 'https://example.com/login'));
  assert(!matchesUrl(rules, 'https://other.com/'));
  assert(matchesUrl('!example.com', 'https://other.com/'), 'exclusions only = everything else');
  assert(!matchesUrl('!example.com', 'https://www.example.com/'));
  assert(matchesUrl('a.com\nb.com', 'https://b.com/'));
  assert(matchesUrl('a.com b.com', 'https://a.com/'));
  assert(!matchesUrl('a.com b.com', 'https://c.com/'));
  assert(!matchesUrl('a.com, !a.com/x*, a.com/x/y*', 'https://a.com/x/y'), 'exclusions always win over includes');
});

t('matchesUrl: odd inputs do not throw', () => {
  assert.strictEqual(matchesUrl('example.com', 'not a url'), false);
  assert.strictEqual(matchesUrl('example.com', ''), false);
  assert.strictEqual(matchesUrl('example.com', undefined), false);
  assert.strictEqual(matchesUrl('*', 'not a url'), true);
  assert.strictEqual(matchesUrl('(', 'https://a.com/('), false);
  assert.strictEqual(matchesUrl('https://a.com/(*', 'https://a.com/(x'), true, 'regex specials are escaped');
});

t('parseUserscriptHeader: name, @match/@include and @exclude', () => {
  const code = [
    '\uFEFF// ==UserScript==', '// @name         我的腳本', '// @namespace    x', '// @match        https://*.example.com/*',
    '// @include      https://example.org/*', '// @include      /^https://regex\\.example/', '// @exclude      https://example.com/login*',
    '// @grant        none', '// ==/UserScript==', 'console.log(1)'].join('\n');
  const r = parseUserscriptHeader(code);
  assert.strictEqual(r.name, '我的腳本');
  assert.strictEqual(r.match, 'https://*.example.com/*, https://example.org/*, !https://example.com/login*');
  assert(matchesUrl(r.match, 'https://www.example.com/a'));
  assert(!matchesUrl(r.match, 'https://example.com/login'));
});

t('parseUserscriptHeader: no header → only a bare // @name is used; match lines outside a header are ignored', () => {
  assert.deepStrictEqual(parseUserscriptHeader('// @name  Hello\nconsole.log(1)'), { name: 'Hello', match: '' });
  assert.deepStrictEqual(parseUserscriptHeader('// @match https://a.com/*\nx()'), { name: '', match: '' });
  assert.deepStrictEqual(parseUserscriptHeader(''), { name: '', match: '' });
  assert.deepStrictEqual(parseUserscriptHeader(null), { name: '', match: '' });
  const crlf = '// ==UserScript==\r\n// @name A\r\n// @match *://x.com/*\r\n// ==/UserScript==\r\n';
  assert.deepStrictEqual(parseUserscriptHeader(crlf), { name: 'A', match: '*://x.com/*' });
});

/* ---------- scriptwrap ---------- */
async function run(code, extra = {}) {
  const ctx = vm.createContext({ location: { protocol: 'https:', href: 'https://x/' }, console, ...extra });
  return vm.runInContext(wrapUserCode(code), ctx);
}
(async () => {
  await (async () => {
    assert.strictEqual(await run('globalThis.__x = 1;'), undefined);
    n++; console.log('  ok  wrapUserCode: normal code resolves undefined');
    const r1 = await run('throw new Error("boom")');
    assert(typeof r1 === 'string' && r1.startsWith(ERR_PREFIX) && r1.includes('boom'));
    n++; console.log('  ok  wrapUserCode: runtime error is reported via marker');
    const r2 = await run('await Promise.reject(new TypeError("late"))');
    assert(r2.startsWith(ERR_PREFIX) && r2.includes('late'));
    n++; console.log('  ok  wrapUserCode: awaited rejection is reported');
    assert.strictEqual(await run('const a = 1; return;'), undefined);
    assert.strictEqual(await run('const a = 1; const a2 = a + 1; // trailing comment, no newline'), undefined);
    n++; console.log('  ok  wrapUserCode: return and trailing line comment are fine');
    let hits = 0;
    await run('hits(); const k = 1;', { hits: () => hits++ });
    await run('hits(); const k = 1;', { hits: () => hits++ });
    assert.strictEqual(hits, 2);
    n++; console.log('  ok  wrapUserCode: const redeclaration across runs is fine (separate scopes)');
    await assert.rejects(() => run('this is not js'), (e) => e && e.name === 'SyntaxError');
    n++; console.log('  ok  wrapUserCode: syntax errors reject (main process reports them)');
    let ran = false;
    const r3 = await run('ran();', { location: { protocol: 'chrome-error:' }, ran: () => { ran = true; } });
    assert.strictEqual(r3, undefined); assert.strictEqual(ran, false);
    n++; console.log('  ok  wrapUserCode: skipped on chrome-error: pages');
    console.log(`\n${n} checks passed`);
  })();
})().catch((e) => { console.error(e); process.exit(1); });

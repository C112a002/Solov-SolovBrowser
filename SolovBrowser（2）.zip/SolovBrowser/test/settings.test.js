'use strict';
/* 設定系統的純函式:快速鍵、主題、設定驗證 / 合併、搜尋關鍵字、可調整的版面參數。不需要 Electron。 */
const assert = require('assert');
const Keys = require('../lib/keys');
const Theme = require('../lib/theme');
const Settings = require('../lib/settings');
const { normalizeInput, buildSearchUrl } = require('../lib/urlutil');
const { computeLayout, rowPlan, resolveMetrics, METRICS } = require('../lib/layout');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('  ok  ' + name); };
const clone = (o) => JSON.parse(JSON.stringify(o));

/* ───────── 快速鍵 ───────── */
t('keys: accelerator strings are normalized (case, modifier order, aliases, shifted symbols)', () => {
  assert.strictEqual(Keys.normalizeAccel('ctrl+shift+g'), 'Ctrl+Shift+G');
  assert.strictEqual(Keys.normalizeAccel('Shift + Ctrl + g'), 'Ctrl+Shift+G');
  assert.strictEqual(Keys.normalizeAccel('Cmd+T'), 'Ctrl+T');
  assert.strictEqual(Keys.normalizeAccel('CmdOrCtrl+Option+Left'), 'Ctrl+Alt+ArrowLeft');
  assert.strictEqual(Keys.normalizeAccel('f12'), 'F12');
  assert.strictEqual(Keys.normalizeAccel('Ctrl+Plus'), 'Ctrl+Shift+=');
  assert.strictEqual(Keys.normalizeAccel('Ctrl++'), 'Ctrl+Shift+=');
  assert.strictEqual(Keys.normalizeAccel('Ctrl+,'), 'Ctrl+,');
  assert.strictEqual(Keys.normalizeAccel('Ctrl+Space'), 'Ctrl+Space');
  for (const bad of ['', '   ', 'Ctrl+', 'Ctrl+Shift', 'Ctrl+中', 'Ctrl+F25', 'Banana', null, undefined]) {
    assert.strictEqual(Keys.normalizeAccel(bad), '', String(bad));
  }
});

t('keys: key events become accelerators (Electron input and DOM KeyboardEvent shapes)', () => {
  assert.strictEqual(Keys.accelFromInput({ key: 't', control: true }), 'Ctrl+T');
  assert.strictEqual(Keys.accelFromInput({ key: 'T', control: true, shift: true }), 'Ctrl+Shift+T');
  assert.strictEqual(Keys.accelFromInput({ key: 'T', ctrlKey: true, shiftKey: true }), 'Ctrl+Shift+T');
  assert.strictEqual(Keys.accelFromInput({ key: 't', meta: true }), 'Ctrl+T', 'Cmd counts as Ctrl');
  assert.strictEqual(Keys.accelFromInput({ key: 'ArrowLeft', alt: true }), 'Alt+ArrowLeft');
  assert.strictEqual(Keys.accelFromInput({ key: 'F5' }), 'F5');
  assert.strictEqual(Keys.accelFromInput({ key: '+', control: true, shift: true }), 'Ctrl+Shift+=');
  assert.strictEqual(Keys.accelFromInput({ key: '=', control: true }), 'Ctrl+=');
  assert.strictEqual(Keys.accelFromInput({ key: '_', control: true, shift: true }), 'Ctrl+Shift+-');
  assert.strictEqual(Keys.accelFromInput({ key: '!', control: true, shift: true }), 'Ctrl+Shift+1');
  assert.strictEqual(Keys.accelFromInput({ key: ' ', control: true }), 'Ctrl+Space');
  assert.strictEqual(Keys.accelFromInput({ key: 'Enter', control: true, shift: true }), 'Ctrl+Shift+Enter');
  for (const k of ['Control', 'Shift', 'Alt', 'Meta', 'CapsLock', 'Process', 'Dead', 'Unidentified']) {
    assert.strictEqual(Keys.accelFromInput({ key: k, control: true }), '', k + ' alone is not a shortcut');
  }
  assert.strictEqual(Keys.accelFromInput({ key: '中', control: true }), '');
  assert.strictEqual(Keys.accelFromInput(null), '');
});

t('keys: only combinations that do not eat normal typing can be bound', () => {
  for (const ok of ['Ctrl+T', 'Alt+Q', 'Ctrl+Shift+Alt+K', 'F5', 'Shift+F5', 'Ctrl+F12', 'Alt+ArrowLeft', 'Ctrl+,', 'Ctrl+Tab']) {
    assert(Keys.isValidBinding(ok), ok);
  }
  for (const bad of ['T', 'Shift+T', 'Enter', 'Tab', 'Escape', 'ArrowLeft', 'Ctrl+C', 'Ctrl+V', 'Ctrl+X', 'Ctrl+A', 'Ctrl+Z', 'Ctrl+Y',
    'Alt+F4', '', 'nonsense']) {
    assert(!Keys.isValidBinding(bad), bad);
  }
});

t('keys: the action catalogue is consistent and the defaults are conflict-free', () => {
  const ids = Keys.ACTIONS.map((a) => a.id);
  assert.strictEqual(new Set(ids).size, ids.length, 'unique ids');
  const cats = new Set(Keys.CATEGORIES.map((c) => c.id));
  for (const a of Keys.ACTIONS) {
    assert(cats.has(a.cat), a.id + ' has a known category');
    assert(a.label && typeof a.label === 'string');
    for (const k of a.keys) {
      assert.strictEqual(Keys.normalizeAccel(k), k, `${a.id} default ${k} is canonical`);
      assert(Keys.isValidBinding(k), `${a.id} default ${k} is a valid binding`);
    }
  }
  const km = Keys.buildKeymap({});
  assert.deepStrictEqual(km.conflicts, []);
  // 沿用舊版的預設快速鍵
  const expect = {
    'Ctrl+T': 'tab.new', 'Ctrl+Shift+T': 'tab.reopen', 'Ctrl+W': 'tab.close', 'Ctrl+F4': 'tab.close', 'Ctrl+Tab': 'tab.next',
    'Ctrl+Shift+Tab': 'tab.prev', 'Ctrl+PageDown': 'tab.next', 'Ctrl+PageUp': 'tab.prev', 'Ctrl+1': 'tab.goto1', 'Ctrl+8': 'tab.goto8',
    'Ctrl+9': 'tab.last', 'Ctrl+L': 'nav.address', 'F6': 'nav.address', 'Alt+D': 'nav.address', 'F5': 'nav.reload', 'Ctrl+R': 'nav.reload',
    'Ctrl+F5': 'nav.reloadHard', 'Ctrl+Shift+R': 'nav.reloadHard', 'Alt+ArrowLeft': 'nav.back', 'Alt+ArrowRight': 'nav.forward',
    'Ctrl+=': 'zoom.in', 'Ctrl+Shift+=': 'zoom.in', 'Ctrl+-': 'zoom.out', 'Ctrl+0': 'zoom.reset', 'Ctrl+Shift+G': 'layout.cycle',
    'Ctrl+Shift+X': 'panel.scripts', 'Ctrl+Shift+Enter': 'view.maximize', 'F12': 'devtools', 'Ctrl+Shift+I': 'devtools', 'F11': 'window.fullscreen',
    'Ctrl+,': 'panel.settings',
  };
  for (const [k, id] of Object.entries(expect)) assert.strictEqual(km.map.get(k), id, k);
});

t('keys: overrides replace defaults; an empty list unbinds; duplicates are reported, first action wins', () => {
  const km = Keys.buildKeymap({ 'tab.new': ['Ctrl+Shift+N'], 'tab.close': [] });
  assert.strictEqual(km.map.get('Ctrl+Shift+N'), 'tab.new');
  assert(!km.map.has('Ctrl+T'), 'old key is free');
  assert(!km.map.has('Ctrl+W') && !km.map.has('Ctrl+F4'), 'unbound action has no keys');
  assert.deepStrictEqual(km.byAction['tab.close'], []);
  const dup = Keys.buildKeymap({ 'tab.mute': ['Ctrl+T'] });
  assert.strictEqual(dup.map.get('Ctrl+T'), 'tab.new', 'earlier action keeps it');
  assert.deepStrictEqual(dup.conflicts, [{ accel: 'Ctrl+T', a: 'tab.new', b: 'tab.mute' }]);
  assert.strictEqual(Keys.prettyAccel('Alt+ArrowLeft'), 'Alt+←');
});

/* ───────── 主題 ───────── */
t('theme: default appearance produces no CSS at all (the look is exactly the old one)', () => {
  assert.strictEqual(Theme.buildThemeCss(Settings.defaults().appearance), '');
  assert.strictEqual(Theme.buildThemeCss(null), '');
  assert.strictEqual(Theme.buildThemeCss({}), '');
});

t('theme: base tokens in the theme module match renderer/tokens.css', () => {
  const css = require('fs').readFileSync(require('path').join(__dirname, '..', 'renderer', 'tokens.css'), 'utf8');
  const grab = (block) => {
    const out = {};
    for (const m of block.matchAll(/--([a-z0-9-]+):\s*([^;]+);/g)) out[m[1]] = m[2].trim();
    return out;
  };
  const dark = /@media \(prefers-color-scheme: dark\)\s*\{\s*:root\s*\{([\s\S]*?)\}\s*\}/.exec(css);
  assert(dark, 'dark block exists in tokens.css');
  const light = grab(css.replace(dark[0], ''));
  const darkVars = grab(dark[1]);
  for (const [k, v] of Object.entries(Theme.BASE.light)) assert.strictEqual(light[k.replace(/(\d)$/, '-$1')], v, 'light ' + k);
  for (const [k, v] of Object.entries(Theme.BASE.dark)) assert.strictEqual(darkVars[k.replace(/(\d)$/, '-$1')], v, 'dark ' + k);
});

t('theme: every palette keeps text readable (WCAG contrast) in both modes', () => {
  for (const id of Theme.PALETTE_ORDER) {
    for (const mode of ['light', 'dark']) {
      const s = Theme.paletteSurfaces(id, mode);
      const c = (a, b) => Theme.contrast(Theme.parseHex(a), Theme.parseHex(b));
      for (const bg of ['bar', 'stage', 'field', 'strip']) {
        assert(c(s.ink, s[bg]) >= 7, `${id}/${mode}: ink on ${bg} = ${c(s.ink, s[bg]).toFixed(2)}`);
        assert(c(s.ink2, s[bg]) >= 4, `${id}/${mode}: ink-2 on ${bg} = ${c(s.ink2, s[bg]).toFixed(2)}`);
      }
      assert(c(s.ink3, s.field) >= 2.4, `${id}/${mode}: ink-3 (placeholders) on field`);
      assert(c(s.line, s.bar) >= 1.1 && c(s.line, s.bar) < 3, `${id}/${mode}: border is visible but quiet`);
    }
  }
});

t('theme: accent derivation keeps text on the accent and the accent as text readable', () => {
  for (const hex of ['#0b7f8c', '#2f6fed', '#db2777', '#d97706', '#facc15', '#111827', '#ffffff', '#00ff00']) {
    for (const dark of [false, true]) {
      const surf = dark ? Theme.BASE.dark.bar : Theme.BASE.light.bar;
      const d = Theme.deriveAccent(hex, dark, surf);
      const c = (a, b) => Theme.contrast(Theme.parseHex(a), Theme.parseHex(b));
      assert(c(d.accent, d.onAccent) >= 4.4, `${hex}/${dark}: text on accent ${c(d.accent, d.onAccent).toFixed(2)}`);
      assert(c(d.accentFg, surf) >= 3.5, `${hex}/${dark}: accent as text ${c(d.accentFg, surf).toFixed(2)}`);
      if (dark) assert(c(d.accent, surf) >= 1.7, `${hex}: solid accent is distinguishable from the dark surface`);
    }
  }
});

t('theme: user choices turn into CSS variables; light and dark are scoped to their own media query', () => {
  const css = Theme.buildThemeCss({
    palette: 'default', accent: '#db2777', colors: { light: { bar: '#fffaf0' }, dark: { ink: '#ffeedd' } },
    fontUi: '"Noto Sans TC"', fontMono: 'Consolas', fontSize: 15, radius: 'sharp', tabWidth: 260,
  });
  const light = /@media \(prefers-color-scheme: light\)\{:root\{([^}]*)\}\}/.exec(css);
  const dark = /@media \(prefers-color-scheme: dark\)\{:root\{([^}]*)\}\}/.exec(css);
  assert(light && dark);
  assert(light[1].includes('--bar:#fffaf0') && !dark[1].includes('--bar:'), 'the light override does not leak into dark');
  assert(dark[1].includes('--ink:#ffeedd') && dark[1].includes('--hover:') && !light[1].includes('--ink:'), 'ink override → dark only (+ derived hover)');
  assert(light[1].includes('--accent:#db2777') && dark[1].includes('--accent:#db2777'));
  assert(/--sans:"Noto Sans TC", "Segoe UI Variable Text"/.test(css), 'custom font keeps the default stack as fallback');
  assert(css.includes('--fs:15px') && css.includes('--round:0') && css.includes('--tab-w:260px'));
  assert(css.includes('--mono:Consolas, "Cascadia Code"'));
  // 只改文字色 → 次要 / 提示文字跟著推導
  const s = Theme.surfaces({ palette: 'default', colors: { light: { ink: '#000000' }, dark: {} } }, 'light');
  assert.strictEqual(s.ink, '#000000');
  assert(s.ink2 !== Theme.BASE.light.ink2 && s.ink3 !== Theme.BASE.light.ink3);
  assert.strictEqual(Theme.windowBackground({ palette: 'ocean', colors: {} }, false), Theme.PALETTES.ocean.light.stage);
  assert.strictEqual(Theme.windowBackground({ palette: 'default', colors: { dark: { stage: '#010203' } } }, true), '#010203');
});

/* ───────── 設定驗證 ───────── */
t('settings: defaults are complete, stable and idempotent', () => {
  const d = Settings.defaults();
  assert.deepStrictEqual(Settings.sanitize(d), d);
  assert.deepStrictEqual(Settings.sanitize(undefined), d);
  assert.deepStrictEqual(Settings.sanitize('junk'), d);
  assert.deepStrictEqual(Settings.sanitize([1, 2]), d);
  assert.strictEqual(d.browsing.defaultEngine, 'google');
  assert.strictEqual(Settings.searchTemplate(d), 'https://www.google.com/search?q=%s');
  assert.deepStrictEqual(d.browsing.refreshChoices, [10, 30, 60, 300, 900]);
  assert.strictEqual(d.layout.gap, METRICS.GAP);
  assert.strictEqual(d.layout.pad, METRICS.PAD);
  assert.strictEqual(d.layout.headH, METRICS.HEAD_H);
  assert.strictEqual(d.layout.frame, METRICS.FRAME);
  assert.strictEqual(d.layout.minTileW, METRICS.MIN_TILE_W);
  assert.strictEqual(d.layout.minTileH, METRICS.MIN_TILE_H);
  assert.strictEqual(d.layout.panelWidth, 420);
  assert.strictEqual(d.appearance.fontSize, 13);
  assert.strictEqual(d.appearance.tabWidth, 200);
  assert.strictEqual(Theme.DENSITY[d.appearance.density].tabH + Theme.DENSITY[d.appearance.density].barH, 82, 'same chrome height as before');
  const messy = Settings.sanitize({ appearance: { theme: 'dark', fontSize: 99, evil: 1 }, bogus: true, layout: { gap: -5, toolbar: { nav: 'yes' } } });
  assert.deepStrictEqual(Settings.sanitize(messy), messy, 'idempotent after cleaning');
  assert(!('bogus' in messy) && !('evil' in messy.appearance), 'unknown keys are dropped');
});

t('settings: numbers are clamped / rounded, enums and booleans fall back to the default', () => {
  const s = Settings.sanitize({
    appearance: { theme: 'neon', fontSize: 99, density: 'huge', radius: 'cube', tabWidth: '240.6' },
    layout: { gap: -3, pad: 999, frame: 0, headH: '35', gridColumns: 20, minTileW: 1, minTileH: 'abc', panelWidth: 5000, showHead: 'no', startLayout: 'diagonal' },
    window: { opacity: 5, alwaysOnTop: 1 },
    browsing: { startup: 'x', newTab: 'y', defaultZoom: 7000 },
  });
  assert.strictEqual(s.appearance.theme, 'system');
  assert.strictEqual(s.appearance.fontSize, 18);
  assert.strictEqual(s.appearance.density, 'normal');
  assert.strictEqual(s.appearance.radius, 'normal');
  assert.strictEqual(s.appearance.tabWidth, 241);
  assert.deepStrictEqual([s.layout.gap, s.layout.pad, s.layout.frame, s.layout.headH], [0, 24, 1, 35]);
  assert.deepStrictEqual([s.layout.gridColumns, s.layout.minTileW, s.layout.minTileH, s.layout.panelWidth], [8, 160, 190, 760]);
  assert.strictEqual(s.layout.showHead, true);
  assert.strictEqual(s.layout.startLayout, 'last');
  assert.deepStrictEqual([s.window.opacity, s.window.alwaysOnTop], [30, false]);
  assert.deepStrictEqual([s.browsing.startup, s.browsing.newTab, s.browsing.defaultZoom], ['restore', 'builtin', 500]);
});

t('settings: colours, fonts, URLs and free text are sanitized (nothing that can break out of CSS or run script)', () => {
  const s = Settings.sanitize({
    appearance: {
      accent: '#ABC', palette: 'nope', fontUi: 'Evil; } body{display:none', fontMono: '"Unclosed',
      colors: { light: { bar: 'red', stage: '#112233', bogus: '#000000' }, dark: { ink: '#FFF' }, sepia: { bar: '#000000' } },
    },
    browsing: {
      homepage: 'javascript:alert(1)', userAgent: 'Mozilla/5.0\r\nX-Evil: 1', acceptLanguages: 'zh-TW,zh;q=0.9,en;q=0.8',
      engines: [{ id: 'A b!', name: 'X', keyword: 'Ky wd:', url: 'https://x.test/?q=%s' }, { name: 'bad', url: 'javascript:1' }, { name: 'ftp', url: 'ftp://x/%s' }, 5],
    },
    newtab: { links: [{ name: 'ok', url: 'https://a.test/' }, { name: 'js', url: 'javascript:1' }, { url: 'file:///C:/x.html' }, { url: 'https://sp ace/' }], bg: { image: 'data:image/png;base64,AAAA', color: 'zzz' } },
  });
  assert.strictEqual(s.appearance.accent, '#aabbcc');
  assert.strictEqual(s.appearance.palette, 'default');
  assert.strictEqual(s.appearance.fontUi, '', 'font names with ; or } are rejected');
  assert.strictEqual(s.appearance.fontMono, '', 'unbalanced quotes are rejected');
  assert.deepStrictEqual(s.appearance.colors, { light: { stage: '#112233' }, dark: { ink: '#ffffff' } });
  assert.strictEqual(s.browsing.homepage, '');
  assert.strictEqual(s.browsing.userAgent, 'Mozilla/5.0X-Evil: 1', 'control characters (CR/LF) are removed');
  assert.strictEqual(s.browsing.acceptLanguages, 'zh-TW,zh;q=0.9,en;q=0.8');
  assert.deepStrictEqual(s.browsing.engines, [{ id: 'a-b', name: 'X', keyword: 'kywd', url: 'https://x.test/?q=%s' }]);
  assert.strictEqual(s.browsing.defaultEngine, 'a-b', 'a default engine that does not exist falls back to the first');
  assert.deepStrictEqual(s.newtab.links, [{ name: 'ok', url: 'https://a.test/' }, { name: 'C:', url: 'file:///C:/x.html' }]
    .map((x) => ({ ...x, name: x.url.startsWith('file:') ? Settings.hostName(x.url) : x.name })));
  assert.strictEqual(s.newtab.bg.image, '', 'data: URLs are not accepted as wallpaper');
  assert.strictEqual(s.newtab.bg.color, '#1c2a33');
});

t('settings: engines / links / refresh choices — empty or invalid lists fall back, ids stay unique', () => {
  const s = Settings.sanitize({
    browsing: {
      engines: [{ name: 'Same', url: 'https://a.test/%s' }, { name: 'Same', url: 'https://b.test/%s' }, { name: '百度', url: 'https://c.test/%s' }],
      defaultEngine: 'same-2', refreshChoices: [3, '45', 45, 7.5, 86401, 600, 'x', 10],
    },
    newtab: { links: [] },
  });
  assert.deepStrictEqual(s.browsing.engines.map((e) => e.id), ['same', 'same-2', 'engine']);
  assert.strictEqual(s.browsing.defaultEngine, 'same-2');
  assert.strictEqual(Settings.searchTemplate(s), 'https://b.test/%s');
  assert.deepStrictEqual(s.browsing.refreshChoices, [10, 45, 600], 'out-of-range / non-integer values are dropped, sorted, unique');
  assert.deepStrictEqual(s.newtab.links, [], 'an empty quick-link list is allowed');
  const none = Settings.sanitize({ browsing: { engines: [{ url: 'nope' }], refreshChoices: [1] } });
  assert.deepStrictEqual(none.browsing.engines, Settings.DEFAULT_ENGINES, 'no valid engine → defaults');
  assert.deepStrictEqual(none.browsing.refreshChoices, [10, 30, 60, 300, 900]);
  const many = Settings.sanitize({ browsing: { engines: Array.from({ length: 50 }, (_, i) => ({ name: 'e' + i, url: 'https://e.test/' + i })) } });
  assert.strictEqual(many.browsing.engines.length, 30);
});

t('settings: shortcuts keep only valid, canonical, known bindings; unchanged defaults are not stored', () => {
  const s = Settings.sanitize({
    shortcuts: {
      'tab.new': ['ctrl+shift+n', 'Ctrl+Shift+N', 'T', 'Ctrl+C', 'nonsense'],
      'tab.close': ['Ctrl+W', 'Ctrl+F4'],
      'tab.reopen': [],
      'tab.mute': [],
      'not.an.action': ['Ctrl+K'],
      'nav.home': 'Ctrl+H',
      'tab.duplicate': ['Ctrl+Alt+1', 'Ctrl+Alt+2', 'Ctrl+Alt+3', 'Ctrl+Alt+4', 'Ctrl+Alt+5'],
      'zoom.in': ['x', 'Ctrl+C', 'banana'],
    },
  });
  assert(!('zoom.in' in s.shortcuts), 'a hand-written list in which nothing is valid is ignored — it does not silently unbind the action');
  assert.deepStrictEqual(s.shortcuts['tab.new'], ['Ctrl+Shift+N']);
  assert(!('tab.close' in s.shortcuts), 'same as the default → not an override');
  assert.deepStrictEqual(s.shortcuts['tab.reopen'], [], 'an empty list is kept (explicit unbind of an action that has default keys)');
  assert(!('tab.mute' in s.shortcuts), 'an empty list for an action that has no default keys is just the default');
  assert(!('not.an.action' in s.shortcuts) && !('nav.home' in s.shortcuts));
  assert.strictEqual(s.shortcuts['tab.duplicate'].length, 4, 'at most four keys per action');
});

t('settings: Accept-Language only takes plain header characters (no CR / LF)', () => {
  const al = (v) => Settings.sanitize({ browsing: { acceptLanguages: v } }).browsing.acceptLanguages;
  assert.strictEqual(al('zh-TW,zh;q=0.9,en;q=0.8'), 'zh-TW,zh;q=0.9,en;q=0.8');
  assert.strictEqual(al('zh-TW\r\nX-Evil: 1'), '');
  assert.strictEqual(al('zh-TW\nen'), '', 'a line break in the middle is rejected');
  assert.strictEqual(al('zh-TW\ten'), '', 'so is a tab');
  assert.strictEqual(al('zh-TW<script>'), '', 'and angle brackets');
  assert.strictEqual(al('  zh-TW,en  '), 'zh-TW,en', 'surrounding spaces are trimmed');
  assert.strictEqual(al('x'.repeat(101)), '', 'too long');
});

t('settings: permissions, window, new tab page and custom CSS', () => {
  const s = Settings.sanitize({
    browsing: { permissions: { media: 'allow', geolocation: 'block', notifications: 'maybe', usb: 'allow' } },
    window: { opacity: 80, alwaysOnTop: true },
    newtab: { title: '  我的首頁  ', subtitle: 'x'.repeat(500), showClock: true, bg: { mode: 'image', image: 'https://img.test/a.jpg', dim: 90 } },
    customCss: '#toolbar { background: red }',
  });
  assert.deepStrictEqual(s.browsing.permissions, { media: 'allow', geolocation: 'block', notifications: 'ask', 'clipboard-read': 'ask', 'display-capture': 'ask' });
  assert.deepStrictEqual(s.window, { alwaysOnTop: true, opacity: 80 });
  assert.strictEqual(s.newtab.title, '我的首頁');
  assert.strictEqual(s.newtab.subtitle.length, 80);
  assert.strictEqual(s.newtab.showClock, true);
  assert.deepStrictEqual(s.newtab.bg, { mode: 'image', color: '#1c2a33', image: 'https://img.test/a.jpg', dim: 80 });
  assert.strictEqual(s.customCss, '#toolbar { background: red }');
  assert.strictEqual(Settings.sanitize({ customCss: 'a'.repeat(200000) }).customCss.length, 100000);
});

t('settings: merge — nested objects merge, arrays replace, null resets a key', () => {
  const base = Settings.sanitize({ appearance: { theme: 'dark', fontSize: 16 }, layout: { gap: 10 }, shortcuts: { 'tab.new': ['Ctrl+Shift+N'] } });
  const m1 = Settings.sanitize(Settings.merge(base, { appearance: { accent: '#ff0000' }, layout: { toolbar: { home: true } } }));
  assert.strictEqual(m1.appearance.theme, 'dark', 'untouched keys survive');
  assert.strictEqual(m1.appearance.accent, '#ff0000');
  assert.strictEqual(m1.layout.gap, 10);
  assert.strictEqual(m1.layout.toolbar.home, true);
  assert.strictEqual(m1.layout.toolbar.nav, true, 'sibling toolbar flags survive');
  const m2 = Settings.sanitize(Settings.merge(base, { appearance: { fontSize: null } }));
  assert.strictEqual(m2.appearance.fontSize, 13, 'null → back to the default');
  assert.strictEqual(m2.appearance.theme, 'dark');
  const m3 = Settings.sanitize(Settings.merge(base, { shortcuts: { 'tab.new': null } }));
  assert.deepStrictEqual(m3.shortcuts, {}, 'null removes an override');
  const m4 = Settings.sanitize(Settings.merge(base, { layout: null }));
  assert.deepStrictEqual(m4.layout, Settings.defaults().layout, 'null on a whole section resets that section');
  assert.strictEqual(m4.appearance.theme, 'dark');
  const m5 = Settings.sanitize(Settings.merge(base, { browsing: { refreshChoices: [15, 45] } }));
  assert.deepStrictEqual(m5.browsing.refreshChoices, [15, 45]);
  const evil = JSON.parse('{"__proto__":{"polluted":true},"appearance":{"__proto__":{"polluted":true}}}');
  Settings.merge(base, evil);
  assert.strictEqual({}.polluted, undefined, 'prototype pollution is ignored');
  assert.deepStrictEqual(base.appearance.theme, 'dark', 'merge does not mutate its input');
});

/* ───────── 搜尋 ───────── */
t('search: templates with %s, legacy prefixes, and keywords', () => {
  assert.strictEqual(buildSearchUrl('https://g.test/?q=%s&hl=zh', '貓 咪'), 'https://g.test/?q=%E8%B2%93%20%E5%92%AA&hl=zh');
  assert.strictEqual(buildSearchUrl('https://g.test/?q=', 'a b'), 'https://g.test/?q=a%20b');
  assert.strictEqual(buildSearchUrl('https://g.test/%s/%s', 'x'), 'https://g.test/x/x');
  assert.strictEqual(buildSearchUrl('https://g.test/?q=%s', '$&'), 'https://g.test/?q=%24%26', 'no replacement-pattern surprises');
  const G = 'https://www.google.com/search?q=%s';
  const E = Settings.DEFAULT_ENGINES;
  assert.strictEqual(normalizeInput('hello world', G, E), 'https://www.google.com/search?q=hello%20world');
  assert.strictEqual(normalizeInput('@yt 貓咪', G, E), 'https://www.youtube.com/results?search_query=' + encodeURIComponent('貓咪'));
  assert.strictEqual(normalizeInput('@YT  two words ', G, E), 'https://www.youtube.com/results?search_query=two%20words', 'case-insensitive, trims');
  assert.strictEqual(normalizeInput('@w 臺灣', G, E), 'https://zh.wikipedia.org/w/index.php?search=' + encodeURIComponent('臺灣'));
  assert.strictEqual(normalizeInput('@nope cats', G, E), 'https://www.google.com/search?q=%40nope%20cats', 'unknown keyword = a normal search');
  assert.strictEqual(normalizeInput('d major scale', G, E), 'https://www.google.com/search?q=d%20major%20scale', 'bare letters are not keywords by default');
  assert.strictEqual(normalizeInput('@yt', G, E), 'https://www.google.com/search?q=%40yt', 'a keyword with no query is just text');
  assert.strictEqual(normalizeInput('example.com', G, E), 'https://example.com');
  assert.strictEqual(normalizeInput('https://x.test/', G, E), 'https://x.test/');
  const custom = [{ keyword: 'mdn', url: 'https://developer.mozilla.org/search?q=%s' }, { keyword: '', url: 'https://nokw.test/%s' }];
  assert.strictEqual(normalizeInput('mdn fetch', G, custom), 'https://developer.mozilla.org/search?q=fetch');
  assert.strictEqual(normalizeInput('x y', G, custom), 'https://www.google.com/search?q=x%20y');
});

/* ───────── 版面 ───────── */
t('layout: default metrics give exactly the old geometry; resolveMetrics scales the top gutter with PAD', () => {
  assert.deepStrictEqual(resolveMetrics(), { ...METRICS });
  assert.strictEqual(resolveMetrics({ PAD: 0 }).TOP, 0);
  assert.strictEqual(resolveMetrics({ PAD: 12 }).TOP, 8);
  assert.strictEqual(resolveMetrics({ PAD: 12, TOP: 1 }).TOP, 1, 'an explicit TOP wins');
  const a = computeLayout({ width: 1400, height: 860, chromeH: 82, panelW: 0, count: 2, layout: 'grid' });
  const b = computeLayout({ width: 1400, height: 860, chromeH: 82, panelW: 0, count: 2, layout: 'grid', metrics: { ...METRICS }, gridColumns: 0 });
  assert.deepStrictEqual(a, b);
  assert.deepStrictEqual(a.tiles[0].view, { x: 8, y: 82 + 4 + 30, w: (1400 - 12 - 6) / 2 - 4, h: 860 - 82 - 4 - 6 - 30 - 2 });
});

t('layout: gap / padding / frame / header height are honoured and tiles stay exact', () => {
  const m = { GAP: 0, PAD: 0, FRAME: 1, HEAD_H: 24 };
  const r = computeLayout({ width: 1200, height: 800, chromeH: 80, panelW: 0, count: 4, layout: 'grid', metrics: m });
  assert.strictEqual(r.tiles.length, 4);
  assert.deepStrictEqual(r.tiles[0].outer, { x: 0, y: 80, w: 600, h: 360 });
  assert.deepStrictEqual(r.tiles[3].outer, { x: 600, y: 440, w: 600, h: 360 });
  assert.deepStrictEqual(r.tiles[0].view, { x: 1, y: 104, w: 598, h: 335 });
  const big = computeLayout({ width: 1200, height: 800, chromeH: 80, count: 2, layout: 'cols', metrics: { GAP: 20, PAD: 20 } });
  assert.strictEqual(big.tiles[1].outer.x - (big.tiles[0].outer.x + big.tiles[0].outer.w), 20, 'gap between tiles');
  assert.strictEqual(big.tiles[0].outer.x, 20, 'left padding');
});

t('layout: HEAD_H = 0 hides the header — the page starts right under the top border', () => {
  const r = computeLayout({ width: 1000, height: 700, chromeH: 80, count: 2, layout: 'cols', metrics: { HEAD_H: 0, FRAME: 3 } });
  r.tiles.forEach(({ outer, view }) => {
    assert.strictEqual(view.y, outer.y + 3);
    assert.strictEqual(view.x, outer.x + 3);
    assert.strictEqual(view.h, outer.h - 6);
    assert(view.w > 0 && view.h > 0);
  });
});

t('layout: fixed grid columns, and the cols / rows wrap thresholds are configurable', () => {
  assert.deepStrictEqual(rowPlan(5, 'grid', 1900, 930, METRICS, 2), [2, 2, 1]);
  assert.deepStrictEqual(rowPlan(5, 'grid', 1900, 930, METRICS, 3), [3, 2]);
  assert.deepStrictEqual(rowPlan(5, 'grid', 1900, 930, METRICS, 1), [1, 1, 1, 1, 1]);
  assert.deepStrictEqual(rowPlan(3, 'grid', 1900, 930, METRICS, 8), [3], 'more columns than tabs = one row');
  assert.deepStrictEqual(rowPlan(5, 'grid', 1900, 930), rowPlan(5, 'grid', 1900, 930, METRICS, 0), 'default = auto');
  const narrow = resolveMetrics({ MIN_TILE_W: 600 });
  assert(rowPlan(4, 'cols', 1334, 740, narrow).length > rowPlan(4, 'cols', 1334, 740, resolveMetrics({ MIN_TILE_W: 200 })).length);
  assert.deepStrictEqual(rowPlan(4, 'cols', 1334, 740, resolveMetrics({ MIN_TILE_W: 200 })), [4]);
  const tall = resolveMetrics({ MIN_TILE_H: 400 });
  assert(rowPlan(4, 'rows', 1000, 740, tall).length < 4, 'taller minimum → fewer stacked rows');
  for (const cols of [0, 1, 2, 3, 5]) for (let k = 1; k <= 14; k++) {
    const p = rowPlan(k, 'grid', 1500, 800, METRICS, cols);
    assert.strictEqual(p.reduce((x, y) => x + y, 0), k);
  }
});

console.log(`\n${n} checks passed`);

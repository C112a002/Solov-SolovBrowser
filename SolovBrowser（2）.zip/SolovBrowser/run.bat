@echo off
setlocal
cd /d "%~dp0"
title Solov Browser

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found.
  echo         Install the LTS version from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)

if not exist "node_modules\electron\package.json" (
  echo Installing dependencies ^(first run only, roughly 250 MB^)...
  call npm install
  if errorlevel 1 (
    pause
    exit /b 1
  )
)

rem Extra arguments are passed on to the browser, e.g.  run.bat --safe-mode
rem (safe mode starts without your custom CSS, in case it made the window unusable)
call npm start -- %*
if errorlevel 1 pause

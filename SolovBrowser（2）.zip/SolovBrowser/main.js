'use strict';

/**
 * 索洛夫瀏覽器 (Solov Browser) — 主程序
 *
 * 每個分頁都是一個獨立的 WebContentsView(原生檢視,不是 iframe / <webview>),
 * 直接疊在視窗上,所以同一個畫面可以真正同時顯示多個分頁。
 * 分頁列、工具列、方塊標題列、側邊面板(擴充功能 / 設定)則畫在視窗本身的 UI 頁面(renderer/)。
 *
 * 使用者設定(外觀、版面、搜尋引擎、快速鍵…)集中在一個 settings 物件:
 *   讀檔 / 匯入 / 介面送來的修改 → Settings.sanitize() 驗證 → applySettings() 套用 → 存檔,並推送給介面與新分頁頁面。
 */

const {
  app, BrowserWindow, WebContentsView, ipcMain, Menu, session, shell, dialog, clipboard, nativeTheme,
} = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

const { computeLayout } = require('./lib/layout');
const { normalizeInput, buildSearchUrl, isNewTabUrl, isRunnableUrl } = require('./lib/urlutil');
const { wrapUserCode, ERR_PREFIX } = require('./lib/scriptwrap');
const { matchesUrl, parseUserscriptHeader } = require('./lib/match');
const Settings = require('./lib/settings');
const Keys = require('./lib/keys');
const Theme = require('./lib/theme');

/* ───────────────────────── 固定值 ───────────────────────── */
const APP_TITLE = '索洛夫瀏覽器';
const MAX_RESTORE_TABS = 40;
const LAYOUTS = Settings.LAYOUT_IDS;            // single | grid | cols | rows(依序切換的順序)
const NEWTAB_FILE = path.join(__dirname, 'renderer', 'newtab.html');
const INDEX_FILE = path.join(__dirname, 'renderer', 'index.html');
const PRELOAD_UI = path.join(__dirname, 'preload-ui.js');
const PRELOAD_TAB = path.join(__dirname, 'preload-tab.js');
const ICON_FILE = path.join(__dirname, 'assets', 'icon.png');
const SETTINGS_PANEL_MIN_W = 480;               // 設定面板比腳本面板需要更多空間
const IMAGE_EXTS = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.avif', '.svg'];
const LEGACY_DATA_DIRS = ['MultiViewBrowser', 'multiview-browser']; // 舊版(MultiView)的資料夾名稱

const DEMO_SCRIPT = {
  id: 'demo-badge',
  name: '範例:在每個分頁右下角顯示網域標籤',
  enabled: false,
  code:
    '// 範例腳本:啟用後,畫面上每個分頁的右下角都會出現一個標籤。\n' +
    '// 這段程式可以重複執行,不會產生重複的標籤。\n' +
    "const ID = '__solov_demo_badge';\n" +
    'document.getElementById(ID)?.remove();\n' +
    "const badge = document.createElement('div');\n" +
    'badge.id = ID;\n' +
    "badge.textContent = '✔ ' + location.hostname;\n" +
    "badge.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:2147483647;padding:6px 10px;" +
    "border-radius:8px;background:#0b7f8c;color:#fff;font:600 13px system-ui,sans-serif;" +
    "box-shadow:0 2px 8px rgba(0,0,0,.35);pointer-events:none';\n" +
    'document.documentElement.appendChild(badge);\n',
};

/* ───────────────────────── 狀態 ───────────────────────── */
let win = null;
let tabs = [];            // 依分頁列順序
let nextTabId = 1;
let activeId = null;
let layout = 'grid';      // single | grid | cols | rows
let panelOpen = false;
let panelMode = 'scripts'; // 側邊面板顯示什麼:scripts | settings
let maximized = false;    // 暫時只顯示使用中的分頁(放大單一方塊),配置本身不變
let audioTimer = null;    // 定時檢查各分頁是否正在發出聲音
let scripts = [];         // { id, name, code, enabled, rev, status }
let lastTiles = [];       // 傳給 UI 畫方塊外框 / 標題列用
let config = {};
let closedTabs = [];      // 供「重新開啟已關閉的分頁」
let settings = Settings.defaults();
let keymap = Keys.buildKeymap({});
let recordingKeys = false; // 設定頁正在錄製快速鍵:這段時間所有按鍵都原封不動交給介面
let recordTimer = null;
let heldCss = null;       // 安全模式下暫時拿掉的自訂 CSS(存檔時要還原回去,免得被清掉)
let zoomManaged = new Map(); // 網站主機 → 「預設縮放」自動設定的縮放等級(使用者自己調過的不在這裡)
let USER_DATA = '';
let CONFIG_FILE = '';
let SCRIPTS_FILE = '';
let SETTINGS_FILE = '';
const settingsInfo = {
  loadError: '',
  safeMode: process.argv.includes('--safe-mode'),
  migratedFrom: '',
};

process.on('uncaughtException', (err) => console.error('[uncaughtException]', err));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));

/* ───────────────────────── 小工具 ───────────────────────── */
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const alive = (w) => !!w && !w.isDestroyed();
const uiAlive = () => alive(win) && alive(win.webContents);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function writeJson(file, data) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  } catch (err) {
    console.error('[save]', err.message);
  }
}

/** 呼叫某個 Electron API;不存在(版本差異)或丟出例外時只記錄、不影響其他功能 */
function tryCall(obj, name, ...args) {
  try {
    if (obj && typeof obj[name] === 'function') {
      const ret = obj[name](...args);
      if (ret && typeof ret.catch === 'function') ret.catch(() => {});
      return ret;
    }
  } catch (err) {
    console.error(`[${name}]`, err && err.message);
  }
  return undefined;
}

function copyText(text) {
  try {
    // Electron 44 起 clipboard 的寫入變成非同步;包一層 Promise 讓新舊版本都能用
    Promise.resolve(clipboard.writeText(String(text))).catch(() => {});
  } catch (_) { /* ignore */ }
}

function buildUserAgent() {
  const major = String(process.versions.chrome || '140').split('.')[0];
  let platform = 'X11; Linux x86_64';
  if (process.platform === 'win32') platform = 'Windows NT 10.0; Win64; x64';
  else if (process.platform === 'darwin') platform = 'Macintosh; Intel Mac OS X 10_15_7';
  // 拿掉預設 UA 裡的 "Electron/x.y.z" 與應用程式名稱,讓網站把它當成一般 Chrome
  return `Mozilla/5.0 (${platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Safari/537.36`;
}

const appVersion = () => String(tryCall(app, 'getVersion') || '');

function dialogCall(name, options) {
  return alive(win) ? dialog[name](win, options) : dialog[name](options);
}

function showBox(options) {
  return dialogCall('showMessageBox', options);
}

/* ───────────────────────── 使用者設定 ───────────────────────── */
let settingsTimer = null;

function loadSettings() {
  let raw = null;
  settingsInfo.loadError = '';
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      raw = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8').replace(/^﻿/, ''));
    }
  } catch (err) {
    settingsInfo.loadError = `settings.json 讀取失敗,這次改用預設設定(原檔已另存為 settings.bad.json):${err.message}`;
    try {
      fs.copyFileSync(SETTINGS_FILE, path.join(USER_DATA, 'settings.bad.json'));
    } catch (_) { /* ignore */ }
  }
  settings = Settings.sanitize(raw);
  if (settingsInfo.safeMode && settings.customCss) {
    // 安全模式:這次執行不套用自訂 CSS(萬一 CSS 把介面弄壞了,還有辦法開起來修)
    heldCss = settings.customCss;
    settings.customCss = '';
  }
  keymap = Keys.buildKeymap(settings.shortcuts);
}

function saveSettingsSoon() {
  clearTimeout(settingsTimer);
  settingsTimer = setTimeout(saveSettings, 300);
}

function saveSettings() {
  clearTimeout(settingsTimer);
  settingsTimer = null;
  if (!SETTINGS_FILE) return;
  writeJson(SETTINGS_FILE, heldCss !== null ? Object.assign({}, settings, { customCss: heldCss }) : settings);
}

/** 結束前,只有「有尚未寫入的修改」才存檔 */
function flushSettings() {
  if (settingsTimer) saveSettings();
}

/**
 * 修改設定的唯一入口。
 * @param {object} patch  要合併進去的修改(Settings.merge 規則;null = 還原該項預設值);opts.replace 時是整份設定
 * @returns 介面要用的設定資料
 */
function commitSettings(patch, opts = {}) {
  const raw = opts.replace ? patch : Settings.merge(settings, patch);
  const next = Settings.sanitize(raw);
  if (opts.replace || (patch && Object.prototype.hasOwnProperty.call(patch, 'customCss'))) heldCss = null;
  if (same(settings, next)) return settingsPayload(false);

  const prev = settings;
  settings = next;
  if (!same(prev.shortcuts, next.shortcuts)) keymap = Keys.buildKeymap(next.shortcuts);
  applySettings(prev, next);
  saveSettingsSoon();
  pushSettings();
  return settingsPayload(false);
}

/** 把「和上一份不同」的部分實際套用到視窗、分頁與 session */
function applySettings(prev, next) {
  const ch = (k) => !same(prev[k], next[k]);
  if (ch('appearance')) applyAppearance();
  if (ch('window')) applyWindowFlags();
  if (ch('browsing')) applyBrowsing(prev.browsing);
  if (ch('layout') || ch('appearance')) relayout(); // 間距、標題列、面板寬度、介面密度都會影響版面
}

/** 視窗底色:網頁還沒畫出來之前看到的顏色,要和目前的淺色 / 深色一致,才不會閃一下白邊 */
function applyWindowBackground() {
  if (alive(win)) {
    tryCall(win, 'setBackgroundColor', Theme.windowBackground(settings.appearance, !!nativeTheme.shouldUseDarkColors));
  }
}

function applyAppearance() {
  try {
    nativeTheme.themeSource = settings.appearance.theme;
  } catch (_) { /* ignore */ }
  applyWindowBackground();
}

function applyWindowFlags() {
  if (!alive(win)) return;
  tryCall(win, 'setAlwaysOnTop', !!settings.window.alwaysOnTop);
  tryCall(win, 'setOpacity', settings.window.opacity / 100); // 只有 Windows / macOS 有效
}

function applyBrowsing(prev) {
  const b = settings.browsing;
  if (prev.userAgent !== b.userAgent || prev.acceptLanguages !== b.acceptLanguages) applyUserAgent();
  if (!same(prev.permissions, b.permissions)) permissionMemory.clear();
  if (!same(prev.refreshChoices, b.refreshChoices)) {
    for (const t of tabs) if (t.refreshSec && !b.refreshChoices.includes(t.refreshSec)) setAutoRefresh(t.id, 0);
  }
  if (prev.defaultZoom !== b.defaultZoom) for (const t of tabs) syncDefaultZoom(t);
}

const currentUserAgent = () => settings.browsing.userAgent || buildUserAgent();

function applyUserAgent() {
  const ua = currentUserAgent();
  const langs = settings.browsing.acceptLanguages;
  app.userAgentFallback = ua;
  const ses = session.defaultSession;
  // 沒指定語言時不傳第二個參數,Electron 會還原成系統語言的預設值
  if (langs) tryCall(ses, 'setUserAgent', ua, langs);
  else tryCall(ses, 'setUserAgent', ua);
  for (const t of tabs) if (alive(t.wc)) tryCall(t.wc, 'setUserAgent', ua); // 已開啟的分頁:下次載入時生效
}

function panelWidth() {
  const w = settings.layout.panelWidth;
  return panelMode === 'settings' ? Math.max(w, SETTINGS_PANEL_MIN_W) : w;
}

/** 介面(分頁列、工具列、方塊標題列、面板)用的尺寸 */
function uiMetrics() {
  const a = settings.appearance;
  const l = settings.layout;
  const d = Theme.DENSITY[a.density] || Theme.DENSITY.normal;
  const tabH = l.showTabStrip ? d.tabH : 0;
  return {
    tabH,
    barH: d.barH,
    chromeH: tabH + d.barH, // 網頁區域從這個高度開始
    ctl: d.ctl,
    panelW: panelWidth(),
    headH: l.showHead ? l.headH : 0,
    frame: l.frame,
  };
}

/** 傳給 computeLayout 的方塊間距等參數 */
function tileMetrics() {
  const l = settings.layout;
  return {
    PAD: l.pad,
    GAP: l.gap,
    HEAD_H: l.showHead ? l.headH : 0,
    FRAME: l.frame,
    MIN_TILE_W: l.minTileW,
    MIN_TILE_H: l.minTileH,
  };
}

/** 介面要用的設定資料(full = 第一次載入,多帶預設值給「還原預設」比對用) */
function settingsPayload(full) {
  const p = {
    settings,
    themeCss: Theme.buildThemeCss(settings.appearance),
    keymap: { byAction: keymap.byAction, conflicts: keymap.conflicts },
    metrics: uiMetrics(),
    info: {
      dataDir: USER_DATA,
      version: appVersion(),
      safeMode: settingsInfo.safeMode,
      loadError: settingsInfo.loadError,
      migratedFrom: settingsInfo.migratedFrom,
      platform: process.platform,
    },
  };
  if (full) p.defaults = Settings.defaults();
  return p;
}

function pushSettings() {
  if (uiAlive()) win.webContents.send('settings:changed', settingsPayload(false));
  pushNewTabs();
}

/* ───────────────────────── 內建新分頁頁面 ───────────────────────── */
const NEWTAB_PATH = (() => {
  try {
    return decodeURIComponent(new URL(pathToFileURL(NEWTAB_FILE).href).pathname).toLowerCase();
  } catch (_) {
    return '';
  }
})();

/** 這個網址是不是「我們自己的」新分頁頁面(而不是別處同名的檔案) */
function isBuiltinNewTab(url) {
  if (typeof url !== 'string' || !isNewTabUrl(url)) return false;
  try {
    return decodeURIComponent(new URL(url).pathname).toLowerCase() === NEWTAB_PATH;
  } catch (_) {
    return false;
  }
}

function newtabPayload() {
  const n = settings.newtab;
  const km = keymap.byAction;
  const first = (id) => Keys.prettyAccel((km[id] && km[id][0]) || '');
  const engine = settings.browsing.engines.find((e) => e.id === settings.browsing.defaultEngine)
    || settings.browsing.engines[0];
  return {
    themeCss: Theme.buildThemeCss(settings.appearance),
    customCss: settings.customCss,
    title: n.title,
    subtitle: n.subtitle,
    showSearch: n.showSearch,
    showLinks: n.showLinks,
    showTips: n.showTips,
    showClock: n.showClock,
    links: n.links,
    bg: n.bg,
    search: {
      template: engine.url,
      name: engine.name,
      engines: settings.browsing.engines.filter((e) => e.keyword).map((e) => ({ keyword: e.keyword, url: e.url, name: e.name })),
    },
    keys: {
      newTab: first('tab.new'),
      layoutCycle: first('layout.cycle'),
      maximize: first('view.maximize'),
      scripts: first('panel.scripts'),
      settings: first('panel.settings'),
    },
  };
}

/** 把最新設定推給所有開著新分頁頁面的分頁 */
function pushNewTabs() {
  let payload = null;
  for (const t of tabs) {
    if (!alive(t.wc) || !isBuiltinNewTab(t.wc.getURL())) continue;
    payload = payload || newtabPayload();
    t.wc.send('newtab:update', payload);
  }
}

/** 新分頁要開什麼:null = 內建新分頁頁面 */
function newTabTarget() {
  const b = settings.browsing;
  if (b.newTab === 'blank') return 'about:blank';
  if (b.newTab === 'home' && b.homepage) return b.homepage;
  return null;
}

/* ───────────────────────── 設定檔 / 工作階段 ───────────────────────── */
let saveTimer = null;

function saveConfigSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveConfig, 600);
}

function saveConfig() {
  clearTimeout(saveTimer);
  saveTimer = null;
  if (!alive(win) || !CONFIG_FILE) return;
  const b = win.getNormalBounds();
  // 只存「下次開啟能還原」的分頁(新分頁頁面與 http/https/file),「使用中」的索引也以過濾後的清單為準
  const keep = tabs.filter((t) => t.internal || !t.url || /^(https?|file):/i.test(t.url));
  config = {
    layout,
    window: { width: b.width, height: b.height, maximized: win.isMaximized() },
    tabs: keep.map((t) => ({ url: t.internal ? '' : t.url, shown: t.shown, refresh: t.refreshSec || 0 })),
    active: Math.max(0, keep.findIndex((t) => t.id === activeId)),
  };
  if (zoomManaged.size) config.zoom = Object.fromEntries(Array.from(zoomManaged).slice(-500));
  writeJson(CONFIG_FILE, config);
}

function persistScripts() {
  if (!SCRIPTS_FILE) return;
  writeJson(SCRIPTS_FILE, scripts.map((s) => ({
    id: s.id, name: s.name, code: s.code, enabled: s.enabled, match: s.match,
  })));
}

/** 第一次用新名稱開啟時,把舊版(MultiView)的視窗狀態與腳本搬過來。網站登入狀態不搬。 */
function migrateLegacyData() {
  if (['config.json', 'scripts.json', 'settings.json'].some((f) => fs.existsSync(path.join(USER_DATA, f)))) return;
  const appData = tryCall(app, 'getPath', 'appData');
  if (!appData) return;
  for (const name of LEGACY_DATA_DIRS) {
    const dir = path.join(appData, name);
    if (path.resolve(dir) === path.resolve(USER_DATA)) continue;
    const files = ['config.json', 'scripts.json'].filter((f) => fs.existsSync(path.join(dir, f)));
    if (!files.length) continue;
    for (const f of files) {
      try {
        fs.copyFileSync(path.join(dir, f), path.join(USER_DATA, f));
      } catch (_) { /* ignore */ }
    }
    settingsInfo.migratedFrom = dir;
    return;
  }
}

/* ───────────────────────── 權限(相機 / 麥克風 / 定位…) ───────────────────────── */
const PERMISSION_ALLOW = new Set(['fullscreen', 'pointerLock', 'keyboardLock', 'clipboard-sanitized-write']);
const PERMISSION_ASK = {
  media: '使用你的攝影機或麥克風',
  geolocation: '取得你的位置',
  notifications: '傳送通知給你',
  'clipboard-read': '讀取你的剪貼簿',
  'display-capture': '擷取你的螢幕畫面',
};
const permissionMemory = new Map(); // "host|permission" → boolean(只在本次執行期間記住)
const permissionPending = new Map();

function hostOf(url) {
  try {
    return new URL(url).host || '';
  } catch (_) {
    return '';
  }
}

/** 設定裡每種權限的處理方式:ask(每次詢問,同一個網站只問一次)/ allow / block */
const permissionPolicy = (permission) => settings.browsing.permissions[permission] || 'ask';

function setupPermissions(ses) {
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    if (PERMISSION_ALLOW.has(permission)) return callback(true);
    const what = PERMISSION_ASK[permission];
    if (!what) return callback(false);

    const policy = permissionPolicy(permission);
    if (policy === 'allow') return callback(true);
    if (policy === 'block') return callback(false);

    const host = hostOf((details && details.requestingUrl) || (wc && wc.getURL()) || '') || '此網站';
    const key = `${host}|${permission}`;
    if (permissionMemory.has(key)) return callback(permissionMemory.get(key));

    let pending = permissionPending.get(key);
    if (!pending) {
      pending = showBox({
        type: 'question',
        buttons: ['允許', '封鎖'],
        defaultId: 1,
        cancelId: 1,
        noLink: true,
        title: '網站權限要求',
        message: `${host} 想要${what}`,
      })
        .then((r) => r.response === 0)
        .catch(() => false)
        .finally(() => permissionPending.delete(key));
      permissionPending.set(key, pending);
    }
    pending.then((allowed) => {
      permissionMemory.set(key, allowed);
      callback(allowed);
    });
    return undefined;
  });

  ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
    if (PERMISSION_ALLOW.has(permission)) return true;
    if (!PERMISSION_ASK[permission]) return false;
    const policy = permissionPolicy(permission);
    if (policy === 'allow') return true;
    if (policy === 'block') return false;
    return permissionMemory.get(`${hostOf(requestingOrigin)}|${permission}`) === true;
  });
}

/* ───────────────────────── 使用者腳本引擎 ───────────────────────── */
const freshStatus = () => ({ runs: 0, errors: 0, lastAt: 0, lastOk: null, lastError: '', lastTab: '' });

function hydrateScript(s) {
  return {
    id: String(s.id || crypto.randomUUID()),
    name: String(s.name || '未命名腳本').slice(0, 120),
    code: String(s.code == null ? '' : s.code).slice(0, 1000000),
    enabled: !!s.enabled,
    match: String(s.match == null ? '' : s.match).trim().slice(0, 2000), // 網址限定規則;空白 = 所有分頁
    rev: 1,                 // 程式碼或網址限定改變 / 重新啟用時 +1,代表「需要重新套用」
    status: freshStatus(),
  };
}

function publicScripts() {
  return scripts.map((s) => ({
    id: s.id, name: s.name, code: s.code, enabled: s.enabled, match: s.match, status: s.status,
  }));
}

let scriptsTimer = null;
function sendScripts(immediate = false) {
  if (!uiAlive()) return;
  const push = () => {
    scriptsTimer = null;
    if (uiAlive()) win.webContents.send('scripts', publicScripts());
  };
  if (immediate) {
    clearTimeout(scriptsTimer);
    push();
  } else if (!scriptsTimer) {
    scriptsTimer = setTimeout(push, 120);
  }
}

function note(text) {
  if (uiAlive()) win.webContents.send('note', String(text));
}

/** 在單一分頁執行單一腳本;不會拋出例外 */
async function execOnTab(tab, script) {
  const result = { ok: false, skipped: false, error: '' };
  const wc = tab.wc;
  const url = alive(wc) ? wc.getURL() : '';
  if (!alive(wc) || !tab.domReady || !isRunnableUrl(url) || !matchesUrl(script.match, url)) {
    result.skipped = true; // 還沒載入完成、不是一般網頁,或不符合這個腳本的網址限定
    return result;
  }
  try {
    const ret = await wc.executeJavaScript(wrapUserCode(script.code), false);
    if (typeof ret === 'string' && ret.startsWith(ERR_PREFIX)) {
      result.error = ret.slice(ERR_PREFIX.length).split('\n')[0] || '腳本執行時發生錯誤';
    } else {
      result.ok = true;
    }
  } catch (err) {
    result.error = String((err && err.message) || err).split('\n')[0];
  }
  return result;
}

function record(script, tab, res) {
  if (res.skipped) return;
  const st = script.status;
  st.runs += 1;
  st.lastAt = Date.now();
  st.lastOk = res.ok;
  if (!res.ok) {
    st.errors += 1;
    st.lastError = res.error;
    st.lastTab = tab.title || tab.url || '';
  }
  sendScripts();
}

/** 只套用「已啟用、而且這次載入還沒套用過目前版本」的腳本 */
function applyScripts(tab) {
  if (!alive(tab.wc) || !tab.domReady) return;
  for (const s of scripts) {
    if (!s.enabled || tab.applied.get(s.id) === s.rev) continue;
    tab.applied.set(s.id, s.rev);
    execOnTab(tab, s).then((res) => record(s, tab, res));
  }
}

function applyScriptsToDisplayed() {
  if (!scripts.some((s) => s.enabled)) return;
  for (const tab of displayedTabs()) applyScripts(tab);
}

/** 手動「立即執行」:忽略已套用紀錄,對畫面上所有顯示中的分頁各跑一次 */
function runScriptNow(script) {
  script.status = freshStatus();
  const jobs = displayedTabs().map((tab) => {
    tab.applied.set(script.id, script.rev);
    return execOnTab(tab, script).then((res) => {
      record(script, tab, res);
      return res;
    });
  });
  sendScripts(true);
  Promise.all(jobs).then((results) => {
    if (!results.some((r) => !r.skipped)) {
      note(script.match
        ? '畫面上沒有符合這個腳本網址限定、且已載入完成的分頁。'
        : '畫面上沒有已載入完成的網頁分頁可以執行。');
    }
  });
}

/* ───────────────────────── 分頁 ───────────────────────── */
function getTab(id) {
  return tabs.find((t) => t.id === id) || null;
}

const activeTab = () => getTab(activeId);

function tabByWebContentsId(id) {
  return tabs.find((t) => alive(t.wc) && t.wc.id === id) || null;
}

function shownCount() {
  return tabs.filter((t) => t.shown).length;
}

/** 目前畫面上實際顯示的分頁(依分頁列順序) */
function displayedTabs() {
  const act = getTab(activeId);
  if (!act) return [];
  if (layout === 'single' || maximized) return [act];
  return tabs.filter((t) => t.shown);
}

function isDisplayed(tab) {
  return displayedTabs().includes(tab);
}

function navCan(wc, dir) {
  try {
    const nh = wc.navigationHistory;
    if (nh) return dir === 'back' ? nh.canGoBack() : nh.canGoForward();
    return dir === 'back' ? wc.canGoBack() : wc.canGoForward();
  } catch (_) {
    return false;
  }
}

function navGo(wc, dir) {
  try {
    const nh = wc.navigationHistory;
    if (nh) {
      if (dir === 'back') nh.goBack(); else nh.goForward();
    } else if (dir === 'back') wc.goBack();
    else wc.goForward();
  } catch (_) { /* ignore */ }
}

function syncMeta(tab) {
  const wc = tab.wc;
  if (!alive(wc)) return;
  tab.url = wc.getURL();
  tab.internal = isNewTabUrl(tab.url) || tab.url === 'about:blank'; // 新分頁頁面與空白頁:網址列留空
  tab.canGoBack = navCan(wc, 'back');
  tab.canGoForward = navCan(wc, 'forward');
  tab.loading = wc.isLoading();
}

function ensureInvariants() {
  if (!tabs.length) {
    activeId = null;
    return;
  }
  let act = getTab(activeId);
  if (!act) {
    act = tabs[0];
    activeId = act.id;
  }
  act.shown = true; // 使用中的分頁一定會顯示
  if (maximized && (layout === 'single' || shownCount() < 2)) maximized = false; // 只剩一個:沒有東西可以還原了
}

function focusAddress() {
  if (!uiAlive()) return;
  win.webContents.focus();
  win.webContents.send('focus-address');
}

function createTab(target, opts = {}) {
  const { activate = true, afterId = null, shown = true, focus = true } = opts;

  const view = new WebContentsView({
    webPreferences: {
      preload: PRELOAD_TAB,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  const wc = view.webContents;
  const tab = {
    id: nextTabId++,
    view,
    wc,
    title: '',
    url: '',
    favicon: '',
    loading: false,
    canGoBack: false,
    canGoForward: false,
    shown,
    internal: false,
    domReady: false,
    applied: new Map(),
    fullscreen: false,
    audible: false,       // 正在發出聲音
    muted: false,         // 已被靜音
    refreshSec: 0,        // 自動重新整理間隔(秒),0 = 關閉
    refreshTimer: null,
  };

  let at = tabs.length;
  if (afterId != null) {
    const i = tabs.findIndex((t) => t.id === afterId);
    if (i >= 0) at = i + 1;
  }
  tabs.splice(at, 0, tab);

  win.contentView.addChildView(view);
  view.setVisible(false);
  wireTab(tab);
  if (settings.browsing.userAgent) tryCall(wc, 'setUserAgent', settings.browsing.userAgent);

  const builtin = !target;
  const blank = builtin || target === 'about:blank'; // 新分頁(內建頁或空白頁):游標移到網址列
  if (builtin) wc.loadFile(NEWTAB_FILE).catch(() => {});
  else wc.loadURL(target).catch(() => {});
  syncMeta(tab); // 立刻帶入「待載入」的網址,位址列不用等頁面提交導覽才更新

  if (activate || activeId == null) setActive(tab.id, { force: true });
  else relayout();

  if (activate && blank) focusAddress();
  else if (activate && focus) wc.focus();
  return tab;
}

/** 依「新分頁要開什麼」的設定開新分頁 */
function createNewTab(opts) {
  return createTab(newTabTarget(), opts);
}

function setActive(id, opts = {}) {
  const tab = getTab(id);
  if (!tab) return;
  const same2 = activeId === id && tab.shown;
  activeId = id;
  tab.shown = true;
  if (!same2 || opts.force) relayout();
  if (opts.focus && alive(tab.wc)) tab.wc.focus();
}

/** 使用者直接點到網頁內容時(由 preload / focus 事件觸發) */
function activateByPage(tab) {
  if (!tabs.includes(tab)) return;
  if (activeId === tab.id && tab.shown) return;
  setActive(tab.id);
}

/** 從 rightStart 往右、leftStart 往左,依距離交錯找出最近的「顯示中」分頁 */
function nearestShown(rightStart, leftStart) {
  for (let d = 0; d < tabs.length; d++) {
    const r = tabs[rightStart + d];
    if (r && r.shown) return r;
    const l = tabs[leftStart - d];
    if (l && l.shown) return l;
  }
  return null;
}

function closeTab(id) {
  const index = tabs.findIndex((t) => t.id === id);
  if (index < 0) return;
  const tab = tabs[index];

  if (!tab.internal && tab.url) {
    closedTabs.push({ url: tab.url, shown: tab.shown });
    if (closedTabs.length > 20) closedTabs.shift();
  }

  tabs.splice(index, 1);
  clearInterval(tab.refreshTimer);
  if (tab.fullscreen && alive(win) && win.isFullScreen()) win.setFullScreen(false);
  try {
    win.contentView.removeChildView(tab.view);
  } catch (_) { /* ignore */ }
  if (alive(tab.wc)) {
    try {
      tab.wc.close();
    } catch (_) { /* ignore */ }
  }

  if (!tabs.length) {
    activeId = null;
    createNewTab();
    return;
  }
  if (activeId === id) {
    // 關掉後,tabs[index] 就是原本右邊的鄰居:優先右邊,其次左邊
    const next = nearestShown(index, index - 1) || tabs[Math.min(index, tabs.length - 1)];
    activeId = next.id;
    next.shown = true;
    relayout();
    if (alive(next.wc)) next.wc.focus();
  } else {
    relayout();
  }
}

function reopenClosedTab() {
  const last = closedTabs.pop();
  if (last) createTab(last.url, { shown: last.shown });
}

function toggleShown(id) {
  const tab = getTab(id);
  if (!tab) return;
  if (tab.shown) {
    if (shownCount() <= 1) return; // 至少要留一個
    tab.shown = false;
    if (activeId === id) {
      const pos = tabs.indexOf(tab);
      const next = nearestShown(pos + 1, pos - 1) || tabs.find((t) => t.shown);
      if (next) activeId = next.id;
    }
  } else {
    tab.shown = true;
  }
  relayout();
}

function showAllTabs() {
  tabs.forEach((t) => { t.shown = true; });
  relayout();
}

function cycleTab(dir) {
  let pool = layout === 'single' ? tabs : displayedTabs();
  if (pool.length < 2) pool = tabs;
  if (pool.length < 2) return;
  const i = pool.findIndex((t) => t.id === activeId);
  const next = pool[(i + dir + pool.length) % pool.length];
  setActive(next.id, { focus: true });
}

function gotoTabNumber(n) {
  if (!tabs.length) return;
  const target = n >= 9 ? tabs[tabs.length - 1] : tabs[n - 1];
  if (target) setActive(target.id, { focus: true });
}

function navigateActive(text) {
  const tab = getTab(activeId);
  if (!tab || !alive(tab.wc)) return;
  const b = settings.browsing;
  const target = normalizeInput(text, Settings.searchTemplate(settings), b.engines);
  if (!target) return;
  tab.wc.loadURL(target).catch(() => {});
  syncMeta(tab); // 位址列馬上顯示輸入的網址,不會先閃回舊網址
  scheduleState(true);
  tab.wc.focus();
}

function goHome() {
  const tab = getTab(activeId);
  if (!tab || !alive(tab.wc)) return;
  const home = settings.browsing.homepage;
  if (home) tab.wc.loadURL(home).catch(() => {});
  else tab.wc.loadFile(NEWTAB_FILE).catch(() => {});
  syncMeta(tab);
  scheduleState(true);
}

/* ── 縮放 ──
 * 「預設縮放」只動沒被使用者手動調過的網站:網站原本沒有自己的縮放(等級 0)才會套用預設;
 * 預設縮放自己設定過的主機記在 zoomManaged,日後預設值改了,這些網站會跟著改;使用者用 Ctrl+± 調過的網站不再被動。 */
const ZOOM_STEP = 0.5;
const zoomLevelOf = (percent) => Math.log(percent / 100) / Math.log(1.2); // Chromium:每一級放大 20%
const defaultZoomLevel = () => zoomLevelOf(settings.browsing.defaultZoom);
const nearZoom = (a, b) => Math.abs(a - b) < 0.01;

function zoomHostOf(tab) {
  try {
    const u = new URL(tab.url);
    return /^https?:$/.test(u.protocol) ? u.hostname : '';
  } catch (_) {
    return '';
  }
}

function syncDefaultZoom(tab) {
  const wc = tab.wc;
  if (!alive(wc) || tab.internal) return;
  const host = zoomHostOf(tab);
  if (!host) return;
  const want = defaultZoomLevel();
  const cur = wc.getZoomLevel();
  let dirty = false;
  if (zoomManaged.has(host)) {
    if (!nearZoom(cur, zoomManaged.get(host))) { // 之後被使用者調過:交還給使用者
      zoomManaged.delete(host);
      saveConfigSoon();
      return;
    }
  } else if (!nearZoom(cur, 0)) {
    return;                                       // 網站有自己記住的縮放
  }
  if (!nearZoom(cur, want)) wc.setZoomLevel(want);
  if (nearZoom(want, 0)) {
    dirty = zoomManaged.delete(host);
  } else {
    dirty = zoomManaged.get(host) !== want;
    zoomManaged.set(host, want);
  }
  if (dirty) saveConfigSoon();
}

function zoomActive(delta) {
  const tab = getTab(activeId);
  if (!tab || !alive(tab.wc)) return;
  const wc = tab.wc;
  const host = zoomHostOf(tab);
  if (delta === 0) { // 還原 = 回到「預設縮放」
    const want = defaultZoomLevel();
    wc.setZoomLevel(want);
    if (host) {
      if (nearZoom(want, 0)) zoomManaged.delete(host);
      else zoomManaged.set(host, want);
      saveConfigSoon();
    }
    return;
  }
  wc.setZoomLevel(clamp(wc.getZoomLevel() + delta, -5, 5));
  if (host && zoomManaged.delete(host)) saveConfigSoon();
}

function toggleDevTools(tab) {
  if (!tab || !alive(tab.wc)) return;
  if (tab.wc.isDevToolsOpened()) tab.wc.closeDevTools();
  else tab.wc.openDevTools({ mode: 'detach' });
}

function setLayout(next) {
  if (!LAYOUTS.includes(next)) return;
  if (next === layout && !maximized) return;
  layout = next;
  maximized = false; // 明確選了配置 → 離開「放大」
  relayout();
}

/** 放大 / 還原:暫時只顯示使用中的分頁(滿版),再按一次回到原本的並排 */
function toggleMaximize(force) {
  const next = typeof force === 'boolean' ? force : !maximized;
  if (next === maximized) return;
  if (next && (layout === 'single' || shownCount() < 2)) return; // 沒有東西可以放大
  maximized = next;
  relayout();
}

/* ───────────────────────── 聲音:靜音與播放指示 ───────────────────────── */
function readAudio(tab) {
  const wc = tab.wc;
  if (!alive(wc)) return false;
  let audible = false;
  let muted = false;
  try {
    audible = !!wc.isCurrentlyAudible();
    muted = !!wc.isAudioMuted();
  } catch (_) { /* ignore */ }
  const changed = audible !== tab.audible || muted !== tab.muted;
  tab.audible = audible;
  tab.muted = muted;
  return changed;
}

function pollAudio() {
  let changed = false;
  for (const tab of tabs) if (readAudio(tab)) changed = true;
  if (changed) scheduleState();
}

function toggleMute(id) {
  const tab = getTab(id);
  if (!tab || !alive(tab.wc)) return;
  tab.wc.setAudioMuted(!tab.wc.isAudioMuted());
  readAudio(tab);
  scheduleState(true);
}

/** 只讓這個分頁出聲,其他分頁全部靜音 */
function soloAudio(id) {
  for (const t of tabs) {
    if (!alive(t.wc)) continue;
    t.wc.setAudioMuted(t.id !== id);
    readAudio(t);
  }
  scheduleState(true);
}

function unmuteAll() {
  for (const t of tabs) {
    if (!alive(t.wc)) continue;
    t.wc.setAudioMuted(false);
    readAudio(t);
  }
  scheduleState(true);
}

/* ───────────────────────── 自動重新整理 ───────────────────────── */
const refreshText = (sec) => {
  if (sec < 60) return `${sec} 秒`;
  if (sec < 3600) return sec % 60 === 0 ? `${sec / 60} 分鐘` : `${Math.round(sec / 6) / 10} 分鐘`;
  return sec % 3600 === 0 ? `${sec / 3600} 小時` : `${Math.round(sec / 360) / 10} 小時`;
};

function setAutoRefresh(id, sec) {
  const tab = getTab(id);
  if (!tab) return;
  clearInterval(tab.refreshTimer);
  tab.refreshTimer = null;
  tab.refreshSec = settings.browsing.refreshChoices.includes(sec) ? sec : 0;
  if (tab.refreshSec) {
    tab.refreshTimer = setInterval(() => tickRefresh(tab), tab.refreshSec * 1000);
    if (tab.refreshTimer.unref) tab.refreshTimer.unref();
  }
  scheduleState(true);
}

/** 時間到:只重新整理「畫面上顯示中、沒在載入、不是全螢幕」的分頁(收起來的分頁不浪費流量) */
function tickRefresh(tab) {
  if (!tabs.includes(tab) || !alive(tab.wc)) {
    clearInterval(tab.refreshTimer);
    return;
  }
  if (tab.internal || tab.fullscreen || tab.wc.isLoading() || !isDisplayed(tab)) return;
  if (alive(win) && win.isMinimized()) return;
  tab.wc.reload();
}

/* ───────────────────────── 側邊面板(擴充功能 / 設定) ───────────────────────── */
function setPanel(open, mode) {
  const m = mode === 'settings' || mode === 'scripts' ? mode : panelMode;
  if (panelOpen === open && panelMode === m) return;
  panelOpen = open;
  panelMode = m;
  if (!open) stopRecording();
  relayout();
}

function togglePanel(mode) {
  setPanel(!(panelOpen && panelMode === mode), mode);
}

/** 設定頁錄製快速鍵時,主程序暫時不攔截任何按鍵;60 秒沒完成就自動結束,避免快速鍵永遠失效 */
function startRecording() {
  recordingKeys = true;
  clearTimeout(recordTimer);
  recordTimer = setTimeout(stopRecording, 60000);
  if (recordTimer.unref) recordTimer.unref();
}

function stopRecording() {
  recordingKeys = false;
  clearTimeout(recordTimer);
  recordTimer = null;
}

/* ───────────────────────── 版面 / 狀態推送 ───────────────────────── */
function relayout() {
  if (!alive(win)) return;
  ensureInvariants();

  const [W, H] = win.getContentSize();
  const fsTab = tabs.find((t) => t.fullscreen);

  if (fsTab) {
    // 網頁進入 HTML 全螢幕(例如影片):該分頁鋪滿整個視窗,其餘隱藏
    for (const t of tabs) {
      if (t === fsTab) {
        t.view.setBounds({ x: 0, y: 0, width: W, height: H });
        t.view.setVisible(true);
      } else {
        t.view.setVisible(false);
      }
    }
    lastTiles = [];
  } else {
    const displayed = displayedTabs();
    const lay = computeLayout({
      width: W,
      height: H,
      chromeH: uiMetrics().chromeH,
      panelW: panelOpen ? panelWidth() : 0,
      count: displayed.length,
      layout,
      metrics: tileMetrics(),
      gridColumns: settings.layout.gridColumns,
    });
    const visible = new Set();
    displayed.forEach((t, i) => {
      const r = lay.tiles[i].view;
      t.view.setBounds({ x: r.x, y: r.y, width: r.w, height: r.h });
      t.view.setVisible(true);
      visible.add(t.id);
    });
    for (const t of tabs) if (!visible.has(t.id)) t.view.setVisible(false);

    lastTiles = lay.split
      ? lay.tiles.map((tile, i) => ({
        id: displayed[i].id,
        x: tile.outer.x,
        y: tile.outer.y,
        w: tile.outer.w,
        h: tile.outer.h,
      }))
      : [];
  }

  applyScriptsToDisplayed();
  scheduleState(true);
}

function buildState() {
  return {
    tabs: tabs.map((t) => ({
      id: t.id,
      title: t.title,
      url: t.internal ? '' : t.url,
      favicon: t.favicon,
      loading: t.loading,
      shown: t.shown,
      internal: t.internal,
      canGoBack: t.canGoBack,
      canGoForward: t.canGoForward,
      audible: t.audible,
      muted: t.muted,
      refreshSec: t.refreshSec,
    })),
    activeId,
    layout,
    maximized,
    panelOpen,
    panelMode,
    tiles: lastTiles,
    displayedCount: displayedTabs().length,
    metrics: uiMetrics(),
  };
}

let stateTimer = null;
function scheduleState(immediate = false) {
  if (!uiAlive()) return;
  if (immediate) {
    clearTimeout(stateTimer);
    stateTimer = null;
    sendState();
  } else if (!stateTimer) {
    stateTimer = setTimeout(() => {
      stateTimer = null;
      sendState();
    }, 40);
  }
}

function sendState() {
  if (!uiAlive()) return;
  win.webContents.send('state', buildState());
  const act = getTab(activeId);
  win.setTitle(act && act.title ? `${act.title} - ${APP_TITLE}` : APP_TITLE);
  saveConfigSoon();
}

/* ───────────────────────── 動作與快速鍵 ───────────────────────── */
/** 每個動作(lib/keys.js 的 ACTIONS)的實際作用。快速鍵、介面按鈕、設定頁的「試試看」都走這裡。 */
const ACTION_RUN = {
  'tab.new': () => createNewTab(),
  'tab.reopen': () => reopenClosedTab(),
  'tab.close': () => { const t = activeTab(); if (t) closeTab(t.id); },
  'tab.closeOthers': () => { tabs.filter((t) => t.id !== activeId).forEach((t) => closeTab(t.id)); },
  'tab.duplicate': () => {
    const t = activeTab();
    if (t && !t.internal && t.url) createTab(t.url, { afterId: t.id });
  },
  'tab.next': () => cycleTab(1),
  'tab.prev': () => cycleTab(-1),
  'tab.last': () => gotoTabNumber(9),
  'tab.toggleShown': () => { const t = activeTab(); if (t) toggleShown(t.id); },
  'tab.mute': () => { const t = activeTab(); if (t) toggleMute(t.id); },

  'nav.address': () => focusAddress(),
  'nav.reload': () => { const t = activeTab(); if (t && alive(t.wc)) t.wc.reload(); },
  'nav.reloadHard': () => { const t = activeTab(); if (t && alive(t.wc)) t.wc.reloadIgnoringCache(); },
  'nav.stop': () => { const t = activeTab(); if (t && alive(t.wc)) t.wc.stop(); },
  'nav.back': () => { const t = activeTab(); if (t) navGo(t.wc, 'back'); },
  'nav.forward': () => { const t = activeTab(); if (t) navGo(t.wc, 'forward'); },
  'nav.home': () => goHome(),
  'zoom.in': () => zoomActive(ZOOM_STEP),
  'zoom.out': () => zoomActive(-ZOOM_STEP),
  'zoom.reset': () => zoomActive(0),
  devtools: () => toggleDevTools(activeTab()),

  'layout.cycle': () => setLayout(LAYOUTS[(LAYOUTS.indexOf(layout) + 1) % LAYOUTS.length]),
  'layout.single': () => setLayout('single'),
  'layout.grid': () => setLayout('grid'),
  'layout.cols': () => setLayout('cols'),
  'layout.rows': () => setLayout('rows'),
  'view.maximize': () => toggleMaximize(),
  'view.showAll': () => showAllTabs(),
  'view.header': () => commitSettings({ layout: { showHead: !settings.layout.showHead } }),
  'view.tabstrip': () => commitSettings({ layout: { showTabStrip: !settings.layout.showTabStrip } }),

  'panel.scripts': () => togglePanel('scripts'),
  'panel.settings': () => togglePanel('settings'),
  'window.fullscreen': () => { if (alive(win)) win.setFullScreen(!win.isFullScreen()); },
  'window.alwaysOnTop': () => commitSettings({ window: { alwaysOnTop: !settings.window.alwaysOnTop } }),
};
for (let n = 1; n <= 8; n++) ACTION_RUN[`tab.goto${n}`] = () => gotoTabNumber(n);

function runAction(id) {
  const fn = ACTION_RUN[id];
  if (typeof fn !== 'function') return false;
  try {
    fn();
  } catch (err) {
    console.error(`[action ${id}]`, err);
  }
  return true;
}

/** 按鍵 → 快速鍵字串 → 動作。沒有綁定的按鍵原封不動交給網頁 / 介面。 */
function handleShortcut(event, input) {
  if (!input || input.type !== 'keyDown' || recordingKeys) return;
  const accel = Keys.accelFromInput(input);
  if (!accel) return;
  const id = keymap.map.get(accel);
  if (!id || typeof ACTION_RUN[id] !== 'function') return;
  event.preventDefault();
  runAction(id);
}

function setupMenu() {
  if (process.platform === 'darwin') {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' },
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }
}

function showTabMenu(id) {
  const tab = getTab(id);
  if (!tab) return;
  const index = tabs.indexOf(tab);
  const split = layout !== 'single';
  const tpl = [];

  if (split) {
    tpl.push({
      label: tab.shown ? '從畫面隱藏這個分頁' : '顯示在畫面上',
      enabled: !tab.shown || shownCount() > 1,
      click: () => toggleShown(id),
    });
    tpl.push({
      label: '只顯示這個分頁',
      enabled: shownCount() > 1 || !tab.shown,
      click: () => {
        tabs.forEach((t) => { t.shown = t === tab; });
        activeId = id;
        relayout();
      },
    });
    tpl.push({
      label: '顯示所有分頁',
      enabled: shownCount() < tabs.length,
      click: () => showAllTabs(),
    });
    tpl.push({
      label: maximized ? '還原並排顯示' : '放大這個分頁',
      enabled: maximized || shownCount() + (tab.shown ? 0 : 1) >= 2,
      click: () => {
        if (maximized) {
          toggleMaximize(false);
        } else {
          setActive(id);
          toggleMaximize(true);
        }
      },
    });
    tpl.push({ type: 'separator' });
  }
  tpl.push(
    { label: tab.muted ? '取消靜音' : '靜音這個分頁', click: () => toggleMute(id) },
    { label: '只播放這個分頁的聲音', enabled: tabs.length > 1, click: () => soloAudio(id) },
    { label: '取消所有分頁的靜音', enabled: tabs.some((t) => t.muted), click: () => unmuteAll() },
    {
      label: '自動重新整理',
      enabled: !tab.internal,
      submenu: [
        { label: '關閉', type: 'radio', checked: !tab.refreshSec, click: () => setAutoRefresh(id, 0) },
        ...settings.browsing.refreshChoices.map((sec) => ({
          label: `每 ${refreshText(sec)}`,
          type: 'radio',
          checked: tab.refreshSec === sec,
          click: () => setAutoRefresh(id, sec),
        })),
      ],
    },
    { type: 'separator' },
    { label: '重新整理', click: () => alive(tab.wc) && tab.wc.reload() },
    {
      label: '複製分頁',
      enabled: !tab.internal && !!tab.url,
      click: () => createTab(tab.url, { afterId: id }),
    },
    {
      label: '複製網址',
      enabled: !tab.internal && !!tab.url,
      click: () => copyText(tab.url),
    },
    { type: 'separator' },
    { label: '關閉分頁', click: () => closeTab(id) },
    {
      label: '關閉其他分頁',
      enabled: tabs.length > 1,
      click: () => tabs.filter((t) => t.id !== id).forEach((t) => closeTab(t.id)),
    },
    {
      label: '關閉右側分頁',
      enabled: index < tabs.length - 1,
      click: () => tabs.slice(index + 1).forEach((t) => closeTab(t.id)),
    },
  );
  Menu.buildFromTemplate(tpl).popup({ window: win });
}

function showPageContextMenu(tab, params) {
  const wc = tab.wc;
  const flags = params.editFlags || {};
  const tpl = [];

  if (params.linkURL) {
    tpl.push(
      { label: '在新分頁開啟連結', click: () => createTab(params.linkURL, { afterId: tab.id }) },
      { label: '複製連結網址', click: () => copyText(params.linkURL) },
      { type: 'separator' },
    );
  }
  if (params.mediaType === 'image' && params.srcURL) {
    tpl.push(
      { label: '在新分頁開啟圖片', click: () => createTab(params.srcURL, { afterId: tab.id }) },
      { label: '另存圖片…', click: () => wc.downloadURL(params.srcURL) },
      { label: '複製圖片網址', click: () => copyText(params.srcURL) },
      { type: 'separator' },
    );
  }
  if (params.isEditable) {
    tpl.push(
      { label: '復原', enabled: !!flags.canUndo, click: () => wc.undo() },
      { label: '重做', enabled: !!flags.canRedo, click: () => wc.redo() },
      { type: 'separator' },
      { label: '剪下', enabled: !!flags.canCut, click: () => wc.cut() },
      { label: '複製', enabled: !!flags.canCopy, click: () => wc.copy() },
      { label: '貼上', enabled: !!flags.canPaste, click: () => wc.paste() },
      { label: '全選', enabled: !!flags.canSelectAll, click: () => wc.selectAll() },
      { type: 'separator' },
    );
  } else if (params.selectionText) {
    const text = params.selectionText.trim();
    const short = text.length > 18 ? `${text.slice(0, 18)}…` : text;
    tpl.push(
      { label: '複製', click: () => wc.copy() },
      {
        label: `搜尋「${short}」`,
        click: () => createTab(buildSearchUrl(Settings.searchTemplate(settings), text), { afterId: tab.id }),
      },
      { type: 'separator' },
    );
  }
  tpl.push(
    { label: '返回', enabled: navCan(wc, 'back'), click: () => navGo(wc, 'back') },
    { label: '前進', enabled: navCan(wc, 'forward'), click: () => navGo(wc, 'forward') },
    { label: '重新整理', click: () => wc.reload() },
    { type: 'separator' },
    { label: '檢查元素', click: () => wc.inspectElement(params.x, params.y) },
  );
  Menu.buildFromTemplate(tpl).popup({ window: win });
}

/* ───────────────────────── 分頁事件綁定 ───────────────────────── */
function wireTab(tab) {
  const wc = tab.wc;

  // window.open / target=_blank / Ctrl+點擊 → 一律開成本瀏覽器的新分頁
  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (/^(https?|file):/i.test(url)) {
      createTab(url, { activate: disposition !== 'background-tab', afterId: tab.id });
    } else if (/^(mailto|tel):/i.test(url)) {
      shell.openExternal(url).catch(() => {});
    }
    return { action: 'deny' };
  });

  wc.on('page-title-updated', (_e, title) => {
    tab.title = title;
    scheduleState();
  });
  wc.on('page-favicon-updated', (_e, favicons) => {
    tab.favicon = (favicons && favicons[0]) || '';
    scheduleState();
  });
  wc.on('audio-state-changed', () => {
    if (readAudio(tab)) scheduleState();
  });
  wc.on('did-start-loading', () => {
    tab.loading = true;
    scheduleState();
  });
  wc.on('did-stop-loading', () => {
    syncMeta(tab);
    scheduleState();
  });
  wc.on('did-navigate', () => {
    tab.domReady = false;
    tab.favicon = '';
    syncMeta(tab);
    syncDefaultZoom(tab);
    scheduleState();
  });
  wc.on('did-navigate-in-page', (_e, _url, isMainFrame) => {
    if (isMainFrame === false) return;
    syncMeta(tab);
    scheduleState();
  });
  wc.on('did-fail-load', (_e, code, _desc, _url, isMainFrame) => {
    if (isMainFrame === false || code === -3) return; // -3 = 使用者自己中止載入
    syncMeta(tab);
    scheduleState();
  });
  wc.on('dom-ready', () => {
    tab.domReady = true;
    tab.applied = new Map(); // 新的文件:之前的套用紀錄作廢
    syncMeta(tab);
    if (isDisplayed(tab)) applyScripts(tab);
    scheduleState();
  });
  wc.on('render-process-gone', () => {
    tab.domReady = false;
    tab.loading = false;
    scheduleState();
  });

  // 點到哪個分頁,哪個就成為使用中的分頁
  wc.on('focus', () => activateByPage(tab));

  wc.on('before-input-event', handleShortcut);
  wc.on('context-menu', (_e, params) => showPageContextMenu(tab, params));

  // 網頁要求 HTML 全螢幕(例如 YouTube 全螢幕)
  wc.on('enter-html-full-screen', () => {
    tab.fullscreen = true;
    relayout();
  });
  wc.on('leave-html-full-screen', () => {
    tab.fullscreen = false;
    relayout();
  });

  // 頁面的 beforeunload 會擋住導覽;沒有處理的話使用者會無法離開該頁
  wc.on('will-prevent-unload', (event) => {
    const choice = dialog.showMessageBoxSync(alive(win) ? win : undefined, {
      type: 'question',
      buttons: ['離開', '留在這一頁'],
      defaultId: 1,
      cancelId: 1,
      noLink: true,
      title: '要離開這個頁面嗎?',
      message: '這個網站可能不會儲存你所做的變更。',
    });
    if (choice === 0) event.preventDefault();
  });
}

/* ───────────────────────── 視窗 ───────────────────────── */
function createWindow() {
  const saved = config.window || {};
  win = new BrowserWindow({
    width: clamp(Number(saved.width) || 1440, 760, 10000),
    height: clamp(Number(saved.height) || 880, 520, 10000),
    minWidth: 760,
    minHeight: 520,
    show: false,
    title: APP_TITLE,
    backgroundColor: Theme.windowBackground(settings.appearance, !!nativeTheme.shouldUseDarkColors),
    icon: ICON_FILE,
    autoHideMenuBar: true,
    alwaysOnTop: !!settings.window.alwaysOnTop,
    webPreferences: {
      preload: PRELOAD_UI,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  if (saved.maximized) win.maximize();
  applyWindowFlags();

  const ui = win.webContents;
  try {
    // 介面層不可縮放(Ctrl+滾輪),否則方塊外框會和網頁對不齊
    Promise.resolve(ui.setVisualZoomLevelLimits(1, 1)).catch(() => {});
  } catch (_) { /* ignore */ }
  ui.setWindowOpenHandler(() => ({ action: 'deny' }));
  ui.on('will-navigate', (e) => e.preventDefault()); // 把檔案拖進工具列時,不要讓 UI 頁面被導走
  ui.on('before-input-event', handleShortcut);
  win.on('page-title-updated', (e) => e.preventDefault());
  win.on('blur', stopRecording);

  win.once('ready-to-show', () => win.show());
  setTimeout(() => { if (alive(win) && !win.isVisible()) win.show(); }, 2500);

  let resizeTimer = null;
  const later = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(relayout, 60);
  };
  win.on('resize', relayout);
  win.on('maximize', later);
  win.on('unmaximize', later);
  win.on('enter-full-screen', later);
  win.on('leave-full-screen', later);
  win.on('restore', later);

  win.on('close', () => {
    saveConfig();
    flushSettings();
  });
  win.on('closed', () => {
    for (const t of tabs) {
      if (alive(t.wc)) {
        try {
          t.wc.close();
        } catch (_) { /* ignore */ }
      }
    }
    clearInterval(audioTimer);
    for (const t of tabs) clearInterval(t.refreshTimer);
    tabs = [];
    win = null;
  });

  win.loadFile(INDEX_FILE);
  if (process.env.SOLOV_DEBUG) ui.openDevTools({ mode: 'detach' });
}

function restoreSession(extraUrl) {
  const mode = settings.browsing.startup;
  if (mode === 'restore') {
    const saved = Array.isArray(config.tabs) ? config.tabs.slice(0, MAX_RESTORE_TABS) : [];
    for (const s of saved) {
      const url = s && typeof s.url === 'string' ? s.url : '';
      if (url && !/^(https?|file):/i.test(url)) continue;
      const tab = url
        ? createTab(url, { activate: false, shown: !s || s.shown !== false, focus: false })
        : createNewTab({ activate: false, shown: !s || s.shown !== false, focus: false });
      if (s && settings.browsing.refreshChoices.includes(s.refresh)) setAutoRefresh(tab.id, s.refresh);
    }
    if (tabs.length) {
      const idx = clamp(Number.isInteger(config.active) ? config.active : 0, 0, tabs.length - 1);
      setActive(tabs[idx].id, { force: true });
    }
  } else if (mode === 'home' && settings.browsing.homepage) {
    createTab(settings.browsing.homepage);
  } else {
    createNewTab();
  }
  if (extraUrl) createTab(extraUrl);
  else if (!tabs.length) createNewTab();
}

/* ───────────────────────── 匯出 / 匯入 / 清除資料 ───────────────────────── */
const SETTINGS_FILTER = [{ name: '索洛夫瀏覽器設定 (JSON)', extensions: ['json'] }, { name: '所有檔案', extensions: ['*'] }];

function documentsDir() {
  return tryCall(app, 'getPath', 'documents') || USER_DATA;
}

async function exportSettings(withScripts) {
  const res = await dialogCall('showSaveDialog', {
    title: '匯出設定',
    defaultPath: path.join(documentsDir(), 'solov-settings.json'),
    filters: SETTINGS_FILTER,
  });
  if (res.canceled || !res.filePath) return { canceled: true };
  const data = {
    app: 'solov-browser',
    format: 1,
    version: appVersion(),
    exportedAt: new Date().toISOString(),
    settings: heldCss !== null ? Object.assign({}, settings, { customCss: heldCss }) : settings,
  };
  if (withScripts) data.scripts = scripts.map((s) => ({ name: s.name, code: s.code, match: s.match }));
  fs.writeFileSync(res.filePath, JSON.stringify(data, null, 2), 'utf8');
  return { ok: true, file: res.filePath, scripts: withScripts ? scripts.length : 0 };
}

async function importSettings() {
  const res = await dialogCall('showOpenDialog', {
    title: '匯入設定',
    properties: ['openFile'],
    filters: SETTINGS_FILTER,
  });
  if (res.canceled || !res.filePaths || !res.filePaths.length) return { canceled: true };

  const file = res.filePaths[0];
  if (fs.statSync(file).size > 4 * 1024 * 1024) throw new Error('檔案太大,看起來不是設定檔。');
  let obj;
  try {
    obj = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''));
  } catch (_) {
    throw new Error('這不是有效的 JSON 檔案。');
  }
  const raw = obj && typeof obj.settings === 'object' && obj.settings ? obj.settings : obj;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)
    || !Settings.SECTIONS.some((k) => Object.prototype.hasOwnProperty.call(raw, k))) {
    throw new Error('檔案裡找不到任何可以匯入的設定。');
  }

  const next = Settings.sanitize(raw);
  const current = heldCss !== null ? heldCss : settings.customCss;
  if (next.customCss.trim() && next.customCss !== current) {
    // 自訂 CSS 能改變(甚至藏起)整個介面:來路不明的檔案要讓使用者決定
    const r = await showBox({
      type: 'warning',
      buttons: ['匯入(含自訂 CSS)', '匯入,但不要自訂 CSS', '取消'],
      defaultId: 1,
      cancelId: 2,
      noLink: true,
      title: '匯入設定',
      message: '這個檔案含有自訂 CSS',
      detail: '自訂 CSS 會改變介面的外觀,也可能把按鈕藏起來或讓介面難以操作。只匯入你信任的檔案。',
    });
    if (r.response === 2) return { canceled: true };
    if (r.response === 1) next.customCss = current;
  }
  commitSettings(next, { replace: true });

  let imported = 0;
  if (obj && Array.isArray(obj.scripts)) {
    for (const s of obj.scripts.slice(0, 50)) {
      if (!s || typeof s !== 'object' || typeof s.code !== 'string' || s.code.length > 1000000) continue;
      scripts.push(hydrateScript({ name: s.name, code: s.code, match: s.match, enabled: false })); // 一律先停用
      imported += 1;
    }
    if (imported) {
      persistScripts();
      sendScripts(true);
    }
  }
  return { ok: true, scripts: imported, payload: settingsPayload(false) };
}

function resetSettings(section) {
  if (section == null) return commitSettings({}, { replace: true });
  if (!Settings.SECTIONS.includes(section)) throw new Error('unknown section');
  const def = Settings.defaults();
  return commitSettings(Object.assign({}, settings, { [section]: def[section] }), { replace: true });
}

async function clearBrowsingData(kinds) {
  const want = new Set(Array.isArray(kinds) ? kinds : []);
  const parts = [];
  if (want.has('cache')) parts.push('快取');
  if (want.has('cookies')) parts.push('Cookie(網站登入狀態)');
  if (want.has('storage')) parts.push('網站儲存資料');
  if (want.has('permissions')) parts.push('已記住的網站權限');
  if (!parts.length) return { cleared: [] };

  const r = await showBox({
    type: 'warning',
    buttons: ['清除', '取消'],
    defaultId: 1,
    cancelId: 1,
    noLink: true,
    title: '清除瀏覽資料',
    message: `要清除:${parts.join('、')}?`,
    detail: want.has('cookies') || want.has('storage') ? '所有網站會被登出,這個動作無法復原。' : '',
  });
  if (r.response !== 0) return { canceled: true };

  const ses = session.defaultSession;
  if (want.has('cache')) await Promise.resolve(tryCall(ses, 'clearCache'));
  if (want.has('cookies')) {
    await Promise.resolve(tryCall(ses, 'clearStorageData', { storages: ['cookies'] }));
    tryCall(ses, 'clearAuthCache');
  }
  if (want.has('storage')) {
    await Promise.resolve(tryCall(ses, 'clearStorageData', {
      storages: ['localstorage', 'indexdb', 'websql', 'filesystem', 'serviceworkers', 'cachestorage', 'shadercache'],
    }));
  }
  if (want.has('permissions')) permissionMemory.clear();
  return { cleared: parts };
}

/** 讓使用者挑一張圖當新分頁背景:複製進資料夾,之後原檔搬走也不會壞掉 */
async function pickBackgroundImage() {
  const res = await dialogCall('showOpenDialog', {
    title: '選擇背景圖片',
    properties: ['openFile'],
    filters: [{ name: '圖片', extensions: IMAGE_EXTS.map((e) => e.slice(1)) }, { name: '所有檔案', extensions: ['*'] }],
  });
  if (res.canceled || !res.filePaths || !res.filePaths.length) return { canceled: true };

  const src = res.filePaths[0];
  const ext = path.extname(src).toLowerCase();
  if (!IMAGE_EXTS.includes(ext)) throw new Error('不支援這種圖片格式。');
  if (fs.statSync(src).size > 40 * 1024 * 1024) throw new Error('圖片太大了(上限 40 MB)。');

  const dir = path.join(USER_DATA, 'backgrounds');
  fs.mkdirSync(dir, { recursive: true });
  for (const f of fs.readdirSync(dir)) {
    if (f.startsWith('newtab-bg-')) {
      try {
        fs.unlinkSync(path.join(dir, f));
      } catch (_) { /* ignore */ }
    }
  }
  const dest = path.join(dir, `newtab-bg-${Date.now()}${ext}`);
  fs.copyFileSync(src, dest);
  return { url: pathToFileURL(dest).href };
}

async function importScripts() {
  const options = {
    title: '匯入 JavaScript 腳本',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'JavaScript', extensions: ['js'] }, { name: '所有檔案', extensions: ['*'] }],
  };
  const res = await dialogCall('showOpenDialog', options);
  if (res.canceled || !res.filePaths.length) return;

  let count = 0;
  for (const file of res.filePaths.slice(0, 20)) {
    try {
      const code = fs.readFileSync(file, 'utf8').replace(/^﻿/, '');
      if (code.length > 1000000) continue;
      const meta = parseUserscriptHeader(code);
      scripts.push(hydrateScript({ name: meta.name || path.basename(file), code, enabled: false, match: meta.match }));
      count += 1;
    } catch (_) { /* 略過讀不到的檔案 */ }
  }
  persistScripts();
  sendScripts(true);
  note(count ? `已匯入 ${count} 個腳本(預設停用,確認內容後再啟用)` : '沒有匯入任何腳本');
}

/* ───────────────────────── IPC ───────────────────────── */
function onUI(channel, fn) {
  ipcMain.on(channel, (event, ...args) => {
    if (!uiAlive() || event.sender !== win.webContents) return;
    try {
      fn(...args);
    } catch (err) {
      console.error(`[ipc ${channel}]`, err);
    }
  });
}

function handleUI(channel, fn) {
  ipcMain.handle(channel, (event, ...args) => {
    if (!uiAlive() || event.sender !== win.webContents) throw new Error('forbidden');
    return fn(...args);
  });
}

/** 同步呼叫(sendSync):不管發生什麼事都一定要設定 returnValue,否則呼叫端會卡住 */
function syncUI(channel, fn) {
  ipcMain.on(channel, (event) => {
    let out = null;
    try {
      out = fn(event);
    } catch (err) {
      console.error(`[ipc ${channel}]`, err);
    }
    event.returnValue = out === undefined ? null : out;
  });
}

/** 只有我們自己的新分頁頁面可以讀取設定 */
function builtinNewTabTab(event) {
  const tab = tabByWebContentsId(event.sender.id);
  return tab && alive(tab.wc) && isBuiltinNewTab(tab.wc.getURL()) ? tab : null;
}

function registerIpc() {
  handleUI('ui:ready', () => ({ state: buildState(), scripts: publicScripts(), settings: settingsPayload(true) }));

  // 介面頁面載入的第一刻就要用到主題與尺寸(避免閃一下預設的顏色),所以用同步呼叫
  syncUI('ui:boot', (event) => (uiAlive() && event.sender === win.webContents ? settingsPayload(true) : null));

  // 來自網頁分頁(preload):使用者點到了這個分頁
  ipcMain.on('tab:interact', (event) => {
    const tab = tabByWebContentsId(event.sender.id);
    if (tab) activateByPage(tab);
  });

  // 來自內建新分頁頁面
  syncUI('newtab:boot', (event) => (builtinNewTabTab(event) ? newtabPayload() : null));
  ipcMain.on('newtab:open-settings', (event) => {
    if (builtinNewTabTab(event)) setPanel(true, 'settings');
  });

  onUI('tab:new', () => createNewTab());
  onUI('tab:close', (id) => closeTab(id));
  onUI('tab:activate', (id, toggle) => {
    const tab = getTab(id);
    if (!tab) return;
    if (toggle && layout !== 'single') {
      toggleShown(id);
      if (getTab(id) && getTab(id).shown) setActive(id, { focus: true });
      return;
    }
    setActive(id, { focus: true });
  });
  onUI('tab:toggle-shown', (id) => toggleShown(id));
  onUI('tab:menu', (id) => showTabMenu(id));

  onUI('nav:go', (text) => navigateActive(text));
  onUI('nav:back', () => { const t = getTab(activeId); if (t) navGo(t.wc, 'back'); });
  onUI('nav:forward', () => { const t = getTab(activeId); if (t) navGo(t.wc, 'forward'); });
  onUI('nav:reload', () => { const t = getTab(activeId); if (t && alive(t.wc)) t.wc.reload(); });
  onUI('nav:stop', () => { const t = getTab(activeId); if (t && alive(t.wc)) t.wc.stop(); });

  onUI('layout:set', (next) => setLayout(next));
  onUI('panel:set', (open, mode) => setPanel(!!open, mode));
  onUI('panel:toggle', (mode) => togglePanel(mode === 'settings' ? 'settings' : 'scripts'));
  onUI('view:maximize', (id) => {
    if (typeof id === 'number' && getTab(id)) setActive(id); // 雙擊哪個方塊的標題列,就放大哪一個
    toggleMaximize();
  });
  onUI('tab:mute', (id) => toggleMute(id));
  onUI('tab:auto-refresh', (id, sec) => setAutoRefresh(id, Number(sec) || 0));
  onUI('action:run', (id) => { if (typeof id === 'string' && Keys.ACTION_BY_ID[id]) runAction(id); });
  onUI('keys:record', (on) => { if (on) startRecording(); else stopRecording(); });

  // 設定
  handleUI('settings:get', () => settingsPayload(true));
  handleUI('settings:update', (patch) => {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('invalid patch');
    if (JSON.stringify(patch).length > 400000) throw new Error('patch too large');
    return commitSettings(patch);
  });
  handleUI('settings:reset', (section) => resetSettings(section == null ? null : String(section)));
  handleUI('settings:export', (withScripts) => exportSettings(!!withScripts));
  handleUI('settings:import', () => importSettings());
  handleUI('settings:clear-data', (kinds) => clearBrowsingData(kinds));
  handleUI('settings:pick-image', () => pickBackgroundImage());
  onUI('settings:open-folder', () => { tryCall(shell, 'openPath', USER_DATA); });

  // 使用者腳本
  handleUI('scripts:save', (payload) => {
    const p = payload || {};
    const name = String(p.name || '').trim().slice(0, 120) || '未命名腳本';
    const code = String(p.code == null ? '' : p.code).slice(0, 1000000);
    let s = p.id ? scripts.find((x) => x.id === p.id) : null;
    const match = String(p.match == null ? (s ? s.match : '') : p.match).trim().slice(0, 2000);

    if (!s) {
      s = hydrateScript({ name, code, enabled: p.enabled !== false, match });
      scripts.push(s);
    } else {
      const changed = s.code !== code || s.match !== match;
      s.name = name;
      s.code = code;
      s.match = match;
      if (typeof p.enabled === 'boolean') s.enabled = p.enabled;
      if (changed) {
        s.rev += 1; // 程式碼或網址限定改了:已啟用的話會重新套用到畫面上的分頁
        s.status = freshStatus();
      }
    }
    persistScripts();
    sendScripts(true);
    applyScriptsToDisplayed();
    return { id: s.id, enabled: s.enabled };
  });

  onUI('scripts:remove', (id) => {
    scripts = scripts.filter((s) => s.id !== id);
    for (const t of tabs) t.applied.delete(id);
    persistScripts();
    sendScripts(true);
  });

  onUI('scripts:toggle', (id, enabled) => {
    const s = scripts.find((x) => x.id === id);
    if (!s) return;
    s.enabled = !!enabled;
    if (s.enabled) {
      s.rev += 1; // 重新啟用 → 重新套用
      s.status = freshStatus();
    } else {
      for (const t of tabs) t.applied.delete(id);
    }
    persistScripts();
    sendScripts(true);
    if (s.enabled) applyScriptsToDisplayed();
  });

  onUI('scripts:run', (id) => {
    const s = scripts.find((x) => x.id === id);
    if (s) runScriptNow(s);
  });

  onUI('scripts:import', () => {
    importScripts().catch((err) => note(`匯入失敗:${err.message}`));
  });

  onUI('tabs:reload-shown', () => {
    for (const t of displayedTabs()) if (alive(t.wc)) t.wc.reload();
  });
}

/* ───────────────────────── 啟動 ───────────────────────── */
function urlFromArgv(argv) {
  return (argv || []).find((a) => /^https?:\/\//i.test(a)) || null;
}

function start() {
  app.setAppUserModelId('local.solov.browser');

  USER_DATA = app.getPath('userData');
  try {
    fs.mkdirSync(USER_DATA, { recursive: true });
  } catch (_) { /* ignore */ }
  CONFIG_FILE = path.join(USER_DATA, 'config.json');
  SCRIPTS_FILE = path.join(USER_DATA, 'scripts.json');
  SETTINGS_FILE = path.join(USER_DATA, 'settings.json');

  migrateLegacyData();
  config = readJson(CONFIG_FILE, {}) || {};
  loadSettings();

  if (config.zoom && typeof config.zoom === 'object' && !Array.isArray(config.zoom)) {
    for (const [host, lvl] of Object.entries(config.zoom).slice(0, 500)) {
      if (typeof lvl === 'number' && Number.isFinite(lvl) && Math.abs(lvl) <= 5) zoomManaged.set(host, lvl);
    }
  }

  const startLayout = settings.layout.startLayout;
  if (LAYOUTS.includes(startLayout)) layout = startLayout;
  else if (LAYOUTS.includes(config.layout)) layout = config.layout;

  const stored = readJson(SCRIPTS_FILE, null);
  if (Array.isArray(stored)) {
    scripts = stored.filter((s) => s && typeof s === 'object').map(hydrateScript);
  } else {
    scripts = [hydrateScript(DEMO_SCRIPT)]; // 第一次執行:放一個(停用的)範例腳本
    persistScripts();
  }

  applyAppearance();
  tryCall(nativeTheme, 'on', 'updated', applyWindowBackground); // 主題是「跟隨系統」時,系統切換深淺色後底色也要跟著換
  applyUserAgent();
  setupPermissions(session.defaultSession);
  setupMenu();
  registerIpc();
  createWindow();
  audioTimer = setInterval(pollAudio, 1500);
  if (audioTimer.unref) audioTimer.unref();
  win.webContents.once('did-finish-load', () => restoreSession(urlFromArgv(process.argv.slice(1))));
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_event, argv) => {
    if (!alive(win)) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    const url = urlFromArgv(argv);
    if (url) createTab(url);
    else createNewTab();
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => {
    saveConfig();
    flushSettings();
  });
  app.whenReady().then(start);
}

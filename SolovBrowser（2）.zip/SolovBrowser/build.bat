@echo off
setlocal
cd /d "%~dp0"
title Solov Browser - build exe

echo ==================================================
echo   Solov Browser - build a Windows exe
echo ==================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found.
  echo         Install the LTS version from https://nodejs.org/ and run this file again.
  goto :fail
)

if not exist "node_modules\electron\package.json" (
  echo [1/3] Installing dependencies ^(first run downloads roughly 250 MB^)...
  call npm install
  if errorlevel 1 goto :fail
) else (
  echo [1/3] Dependencies already installed.
)

echo.
echo [2/3] Building a single-file exe with electron-builder...
call npm run dist
if not errorlevel 1 goto :ok_builder

echo.
echo [!] electron-builder failed. Falling back to electron-packager...
echo.
echo [3/3] Packaging with electron-packager...
call npm run pack
if errorlevel 1 goto :fail
echo.
echo DONE.  Run:  dist-packager\SolovBrowser-win32-x64\SolovBrowser.exe
echo        ^(keep the whole folder together^)
goto :end

:ok_builder
echo.
echo DONE.  Single-file exe:  dist\SolovBrowser.exe
goto :end

:fail
echo.
echo Build failed. Please read the messages above.
echo If you see a "symbolic link" error, turn on Windows Developer Mode
echo ^(Settings - For developers^) or run this file as Administrator.
echo.
pause
exit /b 1

:end
echo.
pause
exit /b 0

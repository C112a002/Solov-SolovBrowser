'use strict';

/**
 * 在畫面第一次繪製之前,先把使用者的主題色與自訂 CSS 套上去(做法同 renderer/boot.js),
 * 避免新分頁先閃一下預設的顏色。資料來自 preload 同步取得的 window.solovNewTab.boot。
 * 沒有 preload 的環境(直接用瀏覽器開這個檔案)就維持預設外觀。
 */
(function () {
  const nt = window.solovNewTab;
  const p = nt && nt.boot;
  if (!p) return;
  const set = (id, css) => {
    const el = document.getElementById(id);
    if (el) el.textContent = css || '';
  };
  set('solov-theme', p.themeCss);
  set('solov-user-css', p.customCss);
}());

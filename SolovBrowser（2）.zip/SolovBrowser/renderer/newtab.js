'use strict';

/**
 * 內建新分頁頁面。內容(標題、搜尋引擎、快速連結、背景…)全部來自使用者的設定,
 * 由主程序經 preload 提供(window.solovNewTab);設定一改,主程序會推送更新,這裡就地重畫。
 * 沒有 preload 的環境(直接用瀏覽器開這個檔案)會用下面的預設內容。
 * 整個頁面用 DOM API 建立,不使用 innerHTML。
 */
(function () {
  const Url = window.SolovUrl;
  const Theme = window.SolovTheme;
  const nt = window.solovNewTab || null;

  const FALLBACK = {
    themeCss: '',
    customCss: '',
    title: '索洛夫瀏覽器',
    subtitle: '同一個畫面,同時看很多個分頁。',
    showSearch: true,
    showLinks: true,
    showTips: true,
    showClock: false,
    links: [
      { name: 'Google', url: 'https://www.google.com/' },
      { name: 'YouTube', url: 'https://www.youtube.com/' },
      { name: '維基百科', url: 'https://zh.wikipedia.org/' },
      { name: 'GitHub', url: 'https://github.com/' },
    ],
    bg: { mode: 'default', color: '#1c2a33', image: '', dim: 25 },
    search: { template: 'https://www.google.com/search?q=%s', name: 'Google', engines: [] },
    keys: { newTab: 'Ctrl+T', layoutCycle: 'Ctrl+Shift+G', maximize: 'Ctrl+Shift+Enter', scripts: 'Ctrl+Shift+X', settings: 'Ctrl+,' },
  };

  const $ = (id) => document.getElementById(id);
  let current = (nt && nt.boot) || FALLBACK;
  let clockTimer = 0;
  let bgToken = 0;

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const k of Object.keys(attrs)) {
        if (attrs[k] == null || attrs[k] === false) continue;
        if (k === 'class') el.className = attrs[k];
        else el.setAttribute(k, attrs[k] === true ? '' : String(attrs[k]));
      }
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.appendChild(typeof kid === 'object' ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  /* ───────── 主題與背景 ───────── */
  function applyCss(p) {
    const set = (id, css) => {
      const el = $(id);
      const text = css || '';
      if (el && el.textContent !== text) el.textContent = text;
    };
    set('solov-theme', p.themeCss);
    set('solov-user-css', p.customCss);
  }

  /** 底色深(要用淺色字)回傳 tone-dark,否則 tone-light */
  function toneOf(hex) {
    const c = Theme && Theme.parseHex(hex);
    if (!c) return 'tone-dark';
    return Theme.contrast(c, [255, 255, 255]) >= Theme.contrast(c, [16, 22, 26]) ? 'tone-dark' : 'tone-light';
  }

  /** 放進 CSS url("…") 之前,把會破壞字串的字元編碼掉 */
  const cssUrl = (u) => String(u).replace(/["\\\n\r\f]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'));

  function applyBackground(bg) {
    const body = document.body;
    const layer = $('bg');
    const token = ++bgToken;
    body.classList.remove('bg-color', 'bg-image', 'tone-dark', 'tone-light');
    body.style.removeProperty('--nt-bg');
    body.style.removeProperty('--nt-dim');
    layer.style.backgroundImage = '';

    if (bg.mode === 'color') {
      body.classList.add('bg-color', toneOf(bg.color));
      body.style.setProperty('--nt-bg', bg.color);
    } else if (bg.mode === 'image' && bg.image) {
      body.classList.add('bg-image', 'tone-dark');
      body.style.setProperty('--nt-bg', bg.color);
      body.style.setProperty('--nt-dim', String(bg.dim / 100));
      layer.style.backgroundImage = 'url("' + cssUrl(bg.image) + '")';
      // 圖片讀不到(檔案被刪、網址失效)時,退回預設外觀
      const probe = new Image();
      probe.onerror = () => {
        if (token !== bgToken) return;
        body.classList.remove('bg-image', 'tone-dark');
        layer.style.backgroundImage = '';
      };
      probe.src = bg.image;
    }
  }

  /* ───────── 時鐘 ───────── */
  function tickClock() {
    const now = new Date();
    const time = now.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    const date = now.toLocaleDateString('zh-TW', { month: 'long', day: 'numeric', weekday: 'long' });
    if ($('time').textContent !== time) $('time').textContent = time;
    if ($('date').textContent !== date) $('date').textContent = date;
  }

  function applyClock(show) {
    $('clock').hidden = !show;
    clearInterval(clockTimer);
    clockTimer = 0;
    if (show) {
      tickClock();
      clockTimer = setInterval(tickClock, 1000);
    }
  }

  /* ───────── 搜尋 ───────── */
  function applySearch(p) {
    $('search').hidden = !p.showSearch;
    const name = p.search && p.search.name;
    $('q').placeholder = name ? `用 ${name} 搜尋,或輸入網址` : '搜尋,或輸入網址';

    // 有設定關鍵字的搜尋引擎:列成小標籤,點一下就把關鍵字填進搜尋框
    const kw = $('kw');
    kw.textContent = '';
    const engines = (p.search && p.search.engines) || [];
    for (const e of engines.slice(0, 8)) {
      const b = h('button', { type: 'button', title: `用 ${e.name} 搜尋:輸入「${e.keyword} 內容」` }, e.keyword + ' ' + e.name);
      b.addEventListener('click', () => {
        $('q').value = e.keyword + ' ';
        $('q').focus();
      });
      kw.appendChild(b);
    }
    kw.hidden = engines.length === 0;
  }

  $('search').addEventListener('submit', (e) => {
    e.preventDefault();
    const s = current.search || FALLBACK.search;
    const url = Url.normalizeInput($('q').value, s.template, s.engines);
    if (url) location.href = url;
  });

  /* ───────── 快速連結 ───────── */
  const hostOf = (u) => {
    try {
      return new URL(u).hostname.replace(/^www\./i, '') || u;
    } catch (_) {
      return u;
    }
  };

  function applyLinks(p) {
    const list = $('links');
    list.textContent = '';
    for (const l of p.links || []) {
      if (!l || !/^(https?|file):\/\//i.test(String(l.url))) continue;
      const name = String(l.name || hostOf(l.url));
      const letter = Array.from(name.trim())[0] || '?';
      list.appendChild(h('li', null,
        h('a', { href: l.url, title: l.url },
          h('span', { class: 'ico', 'aria-hidden': 'true' }, letter),
          h('span', { class: 'meta' }, h('b', null, name), h('small', null, hostOf(l.url))))));
    }
    list.hidden = !(p.showLinks && list.children.length > 0);
  }

  /* ───────── 提示(快速鍵會跟著使用者的設定變) ───────── */
  function keys(accel) {
    if (!accel) return null;
    const parts = String(accel).split(/\+(?=.)/);
    const out = [];
    parts.forEach((part, i) => {
      if (i) out.push(' + ');
      out.push(h('kbd', null, part));
    });
    return out;
  }
  const withKeys = (accel, before, after) => (accel ? [before, keys(accel), after] : []);

  function applyTips(p) {
    const k = p.keys || {};
    const items = [
      ['按 ', keys(k.newTab) || '「新增分頁」的快速鍵', ' 新增分頁,新分頁會自動排進畫面並排顯示。'],
      ['工具列右側的按鈕可以切換:單一分頁、自動網格、左右並排、上下堆疊', withKeys(k.layoutCycle, '(按 ', ' 依序切換)'), '。'],
      ['點哪個方塊,網址列與快速鍵就作用在哪個分頁。方塊標題列:雙擊可放大單一方塊', withKeys(k.maximize, '(或按 ', ')'),
        '、眼睛圖示可暫時收起來;分頁右鍵還有靜音與自動重新整理。'],
      ['拼圖圖示是擴充功能', withKeys(k.scripts, '(', ')'), ':貼上自己的 JavaScript,啟用後會套用到畫面上所有顯示中的分頁。'],
      ['滑桿圖示是設定', withKeys(k.settings, '(', ')'), ':可以改配色、字型、版面、快速鍵、搜尋引擎,還有這個頁面本身。'],
    ];
    const ul = $('tip-list');
    ul.textContent = '';
    for (const parts of items) ul.appendChild(h('li', null, parts));
    $('tips').hidden = !p.showTips;
  }

  /* ───────── 整頁 ───────── */
  function render(p) {
    if (!p) return;
    current = p;
    applyCss(p);
    applyBackground(p.bg || FALLBACK.bg);

    $('title').textContent = p.title || '';
    $('subtitle').textContent = p.subtitle || '';
    $('title').hidden = !p.title;
    $('subtitle').hidden = !p.subtitle;
    $('head').hidden = !p.title && !p.subtitle;

    applyClock(!!p.showClock);
    applySearch(p);
    applyLinks(p);
    applyTips(p);
  }

  const customize = $('customize');
  if (nt && typeof nt.openSettings === 'function') {
    customize.hidden = false;
    customize.addEventListener('click', () => nt.openSettings());
  }

  render(current);
  if (nt && typeof nt.onUpdate === 'function') nt.onUpdate(render);
}());

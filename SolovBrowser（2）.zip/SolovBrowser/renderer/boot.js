'use strict';

/**
 * 在畫面第一次繪製之前,先把使用者的外觀設定套上去(主題色、字型、尺寸、要顯示哪些按鈕),
 * 避免開啟時先閃一下預設的顏色。資料來自 preload 同步向主程序要的 window.solov.boot;
 * 之後主程序每次推送新設定,app.js 會再呼叫 SolovBoot.apply。
 */
(function () {
  const root = document.documentElement;

  function setStyle(id, css) {
    const el = document.getElementById(id);
    const text = css || '';
    if (el && el.textContent !== text) el.textContent = text;
  }

  /** 尺寸(單位 px):分頁列、工具列、控制項、面板寬度、方塊標題列、邊框 */
  function applyMetrics(m) {
    if (!m) return;
    const set = (name, value) => root.style.setProperty(name, value + 'px');
    set('--tab-h', m.tabH);
    set('--bar-h', m.barH);
    set('--chrome-h', m.chromeH);
    if (m.ctl) set('--ctl', m.ctl);
    set('--panel-w', m.panelW);
    set('--head-h', m.headH);
    set('--frame', m.frame);
    root.classList.toggle('no-head', !m.headH);
    root.classList.toggle('no-strip', !m.tabH);
  }

  /** 要顯示哪些按鈕 */
  function applyFlags(s) {
    const tb = (s && s.layout && s.layout.toolbar) || {};
    root.classList.toggle('hide-nav', tb.nav === false);
    root.classList.toggle('show-home', tb.home === true);
    root.classList.toggle('hide-layouts', tb.layouts === false);
    root.classList.toggle('hide-ext', tb.ext === false);
  }

  function apply(payload) {
    if (!payload || !payload.settings) return;
    setStyle('solov-theme', payload.themeCss);
    setStyle('solov-user-css', payload.settings.customCss);
    applyFlags(payload.settings);
    applyMetrics(payload.metrics);
  }

  window.SolovBoot = { apply, applyMetrics };
  apply(window.solov && window.solov.boot);
}());

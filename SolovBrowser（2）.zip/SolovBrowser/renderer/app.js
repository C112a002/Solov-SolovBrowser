'use strict';

/**
 * 介面端(renderer)。所有資料以主程序推送的 state / scripts / settings 為準,
 * 這裡只負責把它畫出來,以及把使用者的操作回報給主程序。
 * 網頁內容本身不在這個頁面裡 —— 它們是疊在上面的原生 WebContentsView。
 */
(function () {
  const solov = window.solov;
  if (!solov) {
    document.body.textContent = '介面載入失敗:找不到 preload 提供的 API。';
    return;
  }
  const Keys = window.SolovKeys;
  const Boot = window.SolovBoot;
  const SettingsUI = window.SolovSettingsUI;

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /* ───────── 圖示 ───────── */
  const svg = (body) =>
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + body + '</svg>';
  const ICON = {
    globe: svg('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>'),
    close: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
    eye: svg('<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    eyeOff: svg('<path d="M3 3l18 18"/><path d="M10.6 5.1A10.6 10.6 0 0 1 12 5c6.4 0 10 7 10 7a17.6 17.6 0 0 1-3.3 4.2M6.6 6.7C3.8 8.5 2 12 2 12s3.6 7 10 7c1.7 0 3.2-.4 4.5-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>'),
    reload: svg('<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>'),
    stop: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
    play: svg('<path d="M8 5.5v13l11-6.5z"/>'),
    edit: svg('<path d="M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M14.5 7.5l3 3"/>'),
    trash: svg('<path d="M4 7h16M10 7V4h4v3M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/>'),
    speaker: svg('<path d="M11 5 6 9H3v6h3l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>'),
    speakerOff: svg('<path d="M11 5 6 9H3v6h3l5 4V5z"/><path d="M22 9l-6 6M16 9l6 6"/>'),
    expand: svg('<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>'),
  };

  const NEW_SCRIPT_TEMPLATE =
    '// 這段程式會在畫面上每個分頁各執行一次。\n' +
    '// 腳本啟用中,分頁換頁、重新整理後也會自動再執行。\n' +
    '\n' +
    "console.log('索洛夫瀏覽器 腳本執行中:', location.href);\n";

  /* ───────── 狀態 ───────── */
  let state = null;          // 主程序推送的最新狀態
  let scripts = null;        // 使用者腳本清單(含程式碼)
  let settingsData = solov.boot || null; // 最近一次的設定資料(主題、快速鍵…)
  let gotSettingsPush = false;
  let editing = null;        // null = 清單畫面;{ id: string|null } = 編輯畫面
  let addrDirty = false;     // 使用者正在網址列打字
  let lastActiveId = null;
  let lastPanelKey = '';     // 目前顯示的面板內容:'' | scripts | settings
  let noteTimer = 0;

  const tabsEl = $('#tabs');
  const tilesEl = $('#tiles');
  const panelEl = $('#panel');
  const addr = $('#addr');
  const btnBack = $('#btn-back');
  const btnForward = $('#btn-forward');
  const btnReload = $('#btn-reload');
  const btnExt = $('#btn-ext');
  const btnSettings = $('#btn-settings');
  const badge = $('#ext-badge');
  const btnRestore = $('#btn-restore');

  /* 並排顯示中?(單一分頁配置、或暫時放大單一方塊時不是) */
  const isSplit = () => state.layout !== 'single' && !state.maximized;
  // 間隔的文字(和主程序右鍵選單的寫法一致):90 秒 → 1.5 分鐘
  const refreshLong = (sec) => {
    if (sec < 60) return sec + ' 秒';
    if (sec < 3600) return (sec % 60 === 0 ? sec / 60 : Math.round(sec / 6) / 10) + ' 分鐘';
    return (sec % 3600 === 0 ? sec / 3600 : Math.round(sec / 360) / 10) + ' 小時';
  };
  const refreshShort = (sec) => refreshLong(sec).replace(' 秒', '秒').replace(' 分鐘', '分').replace(' 小時', '時');

  /* ───────── 快速鍵提示:滑鼠移上去時顯示「功能 (目前的快速鍵)」 ───────── */
  function keyOf(actionId) {
    const map = settingsData && settingsData.keymap && settingsData.keymap.byAction;
    const list = map && map[actionId];
    return list && list.length && Keys ? Keys.prettyAccel(list[0]) : '';
  }
  function withKey(text, actionId) {
    const k = keyOf(actionId);
    return k ? text + ' (' + k + ')' : text;
  }

  function setReloadButton(mode) {
    btnReload.dataset.mode = mode;
    btnReload.innerHTML = mode === 'stop' ? ICON.stop : ICON.reload;
    btnReload.title = mode === 'stop' ? withKey('停止載入', 'nav.stop') : withKey('重新整理', 'nav.reload');
    btnReload.setAttribute('aria-label', mode === 'stop' ? '停止載入' : '重新整理');
  }

  function applyTooltips() {
    const set = (el, text, actionId) => { el.title = withKey(text, actionId); };
    set($('#btn-newtab'), '新增分頁', 'tab.new');
    set(btnBack, '上一頁', 'nav.back');
    set(btnForward, '下一頁', 'nav.forward');
    set($('#btn-home'), '首頁', 'nav.home');
    set(btnExt, '擴充功能與使用者腳本', 'panel.scripts');
    set(btnSettings, '設定', 'panel.settings');
    set(btnRestore, '還原並排顯示', 'view.maximize');
    const layoutAction = { single: 'layout.single', grid: 'layout.grid', cols: 'layout.cols', rows: 'layout.rows' };
    const layoutName = { single: '單一分頁', grid: '自動網格', cols: '左右並排', rows: '上下堆疊' };
    $$('.layouts button').forEach((b) => set(b, layoutName[b.dataset.layout] || '', layoutAction[b.dataset.layout]));
    setReloadButton(btnReload.dataset.mode === 'stop' ? 'stop' : 'reload');
  }

  /** 主程序推來新的設定:套用主題與尺寸、更新提示、同步設定頁 */
  function applySettings(payload) {
    if (!payload || !payload.settings) return;
    settingsData = payload;
    if (Boot) Boot.apply(payload);
    applyTooltips();
    if (SettingsUI) SettingsUI.update(payload);
  }

  /** 喇叭按鈕:有聲音或已靜音才會顯示(顯示與否由 CSS 的 .audio 決定) */
  function setSound(root, tab) {
    root.classList.toggle('audio', !!(tab.audible || tab.muted));
    const btn = $('.sound', root);
    const mode = tab.muted ? 'off' : 'on';
    if (btn.dataset.mode !== mode) {
      btn.dataset.mode = mode;
      btn.innerHTML = tab.muted ? ICON.speakerOff : ICON.speaker;
    }
    btn.classList.toggle('live', !!tab.audible && !tab.muted);
    btn.title = tab.muted ? '取消靜音' : '靜音這個分頁(正在播放聲音)';
    btn.setAttribute('aria-label', btn.title);
  }

  /* ───────── 小工具:依 key 重複利用 DOM 節點,避免每次推送都重畫(否則點擊會漏掉) ───────── */
  function reconcile(parent, items, getKey, create, update) {
    const existing = new Map();
    for (const el of Array.from(parent.children)) existing.set(el.dataset.key, el);
    const seen = new Set();
    let prev = null;
    for (const item of items) {
      const key = String(getKey(item));
      let el = existing.get(key);
      if (!el) {
        el = create(item);
        el.dataset.key = key;
      }
      update(el, item);
      seen.add(key);
      const slot = prev ? prev.nextSibling : parent.firstChild;
      if (el !== slot) parent.insertBefore(el, slot);
      prev = el;
    }
    for (const [key, el] of existing) if (!seen.has(key)) el.remove();
  }

  const labelOf = (tab) => tab.title || (tab.internal ? '新分頁' : tab.url || '載入中…');

  /** 網站圖示:有圖就顯示圖,圖壞了或沒有就顯示預設的地球 */
  function setFavicon(root, tab) {
    const img = $('img', root);
    const ico = $('.fav-ico', root);
    const url = tab.favicon || '';
    if (url && img.dataset.bad !== url) {
      if (img.dataset.src !== url) {
        img.dataset.src = url;
        img.src = url;
      }
      img.hidden = false;
      ico.hidden = true;
    } else {
      img.hidden = true;
      ico.hidden = false;
    }
  }

  const FAV_HTML =
    '<span class="fav"><img alt="" draggable="false" hidden>' +
    '<span class="fav-ico">' + ICON.globe + '</span><span class="spin"></span></span>';

  function bindFaviconError(root) {
    const img = $('img', root);
    img.addEventListener('error', () => {
      img.dataset.bad = img.dataset.src || '';
      img.hidden = true;
      $('.fav-ico', root).hidden = false;
    });
  }

  /* ───────── 分頁列 ───────── */
  function createTabEl() {
    const el = document.createElement('div');
    el.className = 'tab';
    el.setAttribute('role', 'tab');
    el.innerHTML =
      FAV_HTML +
      '<span class="title"></span>' +
      '<button class="mini sound" type="button" tabindex="-1"></button>' +
      '<button class="mini eye" type="button" tabindex="-1"></button>' +
      '<button class="mini close" type="button" tabindex="-1" title="關閉分頁" aria-label="關閉分頁">' +
      ICON.close + '</button>';
    bindFaviconError(el);
    return el;
  }

  function updateTabEl(el, tab) {
    const split = isSplit();
    el.dataset.id = tab.id;
    el.classList.toggle('active', tab.id === state.activeId);
    el.classList.toggle('parked', split && !tab.shown);
    el.classList.toggle('onscreen', split && tab.shown);
    el.classList.toggle('loading', tab.loading);
    el.setAttribute('aria-selected', tab.id === state.activeId ? 'true' : 'false');

    const label = labelOf(tab);
    $('.title', el).textContent = label;
    el.title = tab.url ? label + '\n' + tab.url : label;

    const eye = $('.eye', el);
    const mode = tab.shown ? 'on' : 'off';
    if (eye.dataset.mode !== mode) {
      eye.dataset.mode = mode;
      eye.innerHTML = tab.shown ? ICON.eye : ICON.eyeOff;
    }
    eye.title = tab.shown ? '從畫面隱藏這個分頁' : '顯示在畫面上';
    eye.setAttribute('aria-label', eye.title);
    setSound(el, tab);
    setFavicon(el, tab);
  }

  /* ───────── 分頁方塊的標題列 ───────── */
  function createTileEl() {
    const el = document.createElement('div');
    el.className = 'tile';
    el.innerHTML =
      '<div class="head">' + FAV_HTML +
      '<span class="title"></span>' +
      '<button class="mini refresh" type="button" tabindex="-1">' + ICON.reload + '<span class="rf"></span></button>' +
      '<button class="mini sound" type="button" tabindex="-1"></button>' +
      '<button class="mini max" type="button" tabindex="-1" title="放大這個方塊(雙擊標題列也可以)" aria-label="放大這個方塊">' +
      ICON.expand + '</button>' +
      '<button class="mini hide" type="button" tabindex="-1" title="從畫面隱藏這個分頁" aria-label="從畫面隱藏這個分頁">' +
      ICON.eyeOff + '</button>' +
      '<button class="mini close" type="button" tabindex="-1" title="關閉分頁" aria-label="關閉分頁">' +
      ICON.close + '</button></div>';
    bindFaviconError(el);
    return el;
  }

  function updateTileEl(el, tile) {
    const tab = state.tabs.find((t) => t.id === tile.id);
    el.dataset.id = tile.id;
    el.style.left = tile.x + 'px';
    el.style.top = tile.y + 'px';
    el.style.width = tile.w + 'px';
    el.style.height = tile.h + 'px';
    el.classList.toggle('active', tile.id === state.activeId);
    if (!tab) return;
    el.classList.toggle('loading', tab.loading);
    const label = labelOf(tab);
    $('.title', el).textContent = label;
    $('.head', el).title = tab.url ? label + '\n' + tab.url : label;
    setFavicon(el, tab);
    $('.hide', el).hidden = state.displayedCount <= 1;
    $('.max', el).hidden = state.displayedCount <= 1;
    setSound(el, tab);
    el.classList.toggle('auto', tab.refreshSec > 0);
    if (tab.refreshSec > 0) {
      $('.rf', el).textContent = refreshShort(tab.refreshSec);
      const rf = $('.refresh', el);
      rf.title = '自動重新整理:每 ' + refreshLong(tab.refreshSec) + '(點一下關閉)';
      rf.setAttribute('aria-label', rf.title);
    }
  }

  /* ───────── 整體渲染 ───────── */
  function render() {
    if (!state) return;
    if (Boot) Boot.applyMetrics(state.metrics);

    document.body.classList.toggle('split', isSplit());
    btnRestore.hidden = !state.maximized;

    const act = state.tabs.find((t) => t.id === state.activeId) || null;

    reconcile(tabsEl, state.tabs, (t) => t.id, createTabEl, updateTabEl);
    if (state.activeId !== lastActiveId) {
      lastActiveId = state.activeId;
      addrDirty = false;
      const activeEl = $('.tab.active', tabsEl);
      if (activeEl) activeEl.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }

    $$('.layouts button').forEach((b) => {
      const on = b.dataset.layout === state.layout;
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });

    btnBack.disabled = !(act && act.canGoBack);
    btnForward.disabled = !(act && act.canGoForward);
    const mode = act && act.loading ? 'stop' : 'reload';
    if (btnReload.dataset.mode !== mode) setReloadButton(mode);

    const url = act ? act.url : '';
    if (!(document.activeElement === addr && addrDirty) && addr.value !== url) addr.value = url;

    reconcile(tilesEl, state.tiles, (t) => t.id, createTileEl, updateTileEl);
    renderPanel();
  }

  /* ───────── 側邊面板:擴充功能 / 設定 ───────── */
  const panelMode = () => (state && state.panelMode === 'settings' ? 'settings' : 'scripts');

  function renderPanel() {
    const open = !!state.panelOpen;
    const mode = panelMode();
    panelEl.hidden = !open;
    btnExt.classList.toggle('on', open && mode === 'scripts');
    btnExt.setAttribute('aria-pressed', open && mode === 'scripts' ? 'true' : 'false');
    btnSettings.classList.toggle('on', open && mode === 'settings');
    btnSettings.setAttribute('aria-pressed', open && mode === 'settings' ? 'true' : 'false');
    renderPanelHeader();

    // 設定頁在顯示 / 離開時要做一些事(同步控制項、停止錄製快速鍵)
    const key = open ? mode : '';
    if (key !== lastPanelKey) {
      if (lastPanelKey === 'settings' && SettingsUI) SettingsUI.hide();
      if (key === 'settings' && SettingsUI) SettingsUI.show();
      lastPanelKey = key;
    }
  }

  function renderPanelHeader() {
    if (!state) return;
    const mode = panelMode();
    const title = $('#panel-title');
    const sub = $('#panel-sub');
    if (mode === 'settings') {
      title.textContent = '設定';
      sub.textContent = '所有變更都會立刻套用,並自動儲存。';
    } else if (editing) {
      title.textContent = editing.id ? '編輯腳本' : '新增腳本';
      sub.textContent = '儲存後,啟用中的腳本會立刻套用到畫面上的分頁。';
    } else {
      title.textContent = '擴充功能';
      sub.textContent = '已啟用的腳本會套用到畫面上顯示中的 ' + state.displayedCount + ' 個分頁。';
    }
    $('#view-list').hidden = mode !== 'scripts' || !!editing;
    $('#view-edit').hidden = mode !== 'scripts' || !editing;
    $('#view-settings').hidden = mode !== 'settings';
  }

  function describeStatus(s) {
    const st = s.status || {};
    if (!st.runs) {
      const wait = s.match ? '等待符合網址限定的分頁載入' : '等待網頁載入後套用';
      return { text: s.enabled ? wait : '已停用', cls: '' };
    }
    // 只要有任何一個分頁出錯就標示為出錯(不會被後來成功的分頁蓋掉),並附上出錯的分頁
    if (st.errors > 0) {
      const where = st.lastTab ? '(' + st.lastTab + ')' : '';
      return {
        text: '出錯 ' + st.errors + '/' + st.runs + ' 次,最近一次:' + st.lastError + where,
        cls: 'err',
      };
    }
    const time = new Date(st.lastAt).toLocaleTimeString('zh-TW', { hour12: false });
    return { text: '已執行 ' + st.runs + ' 次,最近 ' + time, cls: 'ok' };
  }

  function createScriptEl() {
    const li = document.createElement('li');
    li.className = 'script';
    li.innerHTML =
      '<label class="switch" title="啟用或停用"><input class="sw" type="checkbox" aria-label="啟用或停用">' +
      '<span class="knob"></span></label>' +
      '<div class="info"><div class="name"></div><div class="scope"></div><div class="status"></div></div>' +
      '<div class="acts">' +
      '<button class="mini run" type="button" title="立即在畫面上的分頁執行一次" aria-label="立即執行">' + ICON.play + '</button>' +
      '<button class="mini edit" type="button" title="編輯" aria-label="編輯">' + ICON.edit + '</button>' +
      '<button class="mini del" type="button" title="刪除" aria-label="刪除">' + ICON.trash + '</button>' +
      '</div>';
    return li;
  }

  function updateScriptEl(li, s) {
    li.dataset.id = s.id;
    li.classList.toggle('on', s.enabled);
    const cb = $('.sw', li);
    if (cb.checked !== s.enabled) cb.checked = s.enabled;
    $('.name', li).textContent = s.name;
    $('.name', li).title = s.name;
    const scope = $('.scope', li);
    scope.hidden = !s.match;
    scope.textContent = s.match ? '限定:' + s.match : '';
    scope.title = s.match ? '只在這些網址執行:' + s.match : '';
    const info = describeStatus(s);
    const st = $('.status', li);
    st.textContent = info.text;
    st.title = info.text;
    st.className = 'status ' + info.cls;
  }

  function renderScripts() {
    if (!scripts) return;
    reconcile($('#script-list'), scripts, (s) => s.id, createScriptEl, updateScriptEl);
    $('#script-empty').hidden = scripts.length > 0;
    const n = scripts.filter((s) => s.enabled).length;
    badge.hidden = n === 0;
    badge.textContent = String(n);
  }

  function note(text) {
    const el = $('#panel-note');
    el.textContent = text;
    clearTimeout(noteTimer);
    noteTimer = setTimeout(() => { el.textContent = ''; }, 4500);
  }

  function openEditor(script) {
    editing = { id: script ? script.id : null };
    $('#edit-name').value = script ? script.name : '';
    $('#edit-match').value = script ? script.match || '' : '';
    $('#edit-code').value = script ? script.code : NEW_SCRIPT_TEMPLATE;
    renderPanelHeader();
    $('#edit-name').focus();
  }

  function closeEditor() {
    editing = null;
    renderPanelHeader();
  }

  async function saveEditor() {
    if (!editing) return;
    const payload = {
      id: editing.id,
      name: $('#edit-name').value.trim(),
      match: $('#edit-match').value.trim(),
      code: $('#edit-code').value,
    };
    if (!payload.id) payload.enabled = true; // 新腳本預設啟用,立刻套用
    try {
      const res = await solov.scripts.save(payload);
      closeEditor();
      note(res && res.enabled ? '已儲存,並套用到畫面上的分頁。' : '已儲存(目前是停用狀態)。');
    } catch (err) {
      note('儲存失敗:' + (err && err.message ? err.message : err));
    }
  }

  /* ───────── 事件:分頁列 ───────── */
  const idOf = (el) => Number(el.dataset.id);

  tabsEl.addEventListener('mousedown', (e) => {
    const tabEl = e.target.closest('.tab');
    if (!tabEl) return;
    if (e.button === 1) { e.preventDefault(); return; } // 中鍵:避免出現自動捲動圖示
    if (e.button !== 0 || e.target.closest('.mini')) return;
    solov.activateTab(idOf(tabEl), e.ctrlKey || e.metaKey);
  });
  tabsEl.addEventListener('auxclick', (e) => {
    const tabEl = e.target.closest('.tab');
    if (tabEl && e.button === 1) solov.closeTab(idOf(tabEl));
  });
  tabsEl.addEventListener('click', (e) => {
    const tabEl = e.target.closest('.tab');
    if (!tabEl) return;
    if (e.target.closest('.close')) solov.closeTab(idOf(tabEl));
    else if (e.target.closest('.eye')) solov.toggleShown(idOf(tabEl));
    else if (e.target.closest('.sound')) solov.muteTab(idOf(tabEl));
  });
  tabsEl.addEventListener('contextmenu', (e) => {
    const tabEl = e.target.closest('.tab');
    if (!tabEl) return;
    e.preventDefault();
    solov.tabMenu(idOf(tabEl));
  });
  tabsEl.addEventListener('wheel', (e) => { if (e.deltaY) tabsEl.scrollLeft += e.deltaY; }, { passive: true });
  $('#tabstrip').addEventListener('dblclick', (e) => {
    if (e.target === e.currentTarget || e.target === tabsEl) solov.newTab();
  });
  $('#btn-newtab').addEventListener('click', () => solov.newTab());

  /* ───────── 事件:方塊標題列 ───────── */
  tilesEl.addEventListener('mousedown', (e) => {
    const tileEl = e.target.closest('.tile');
    if (!tileEl || e.button !== 0 || e.target.closest('.mini')) return;
    solov.activateTab(idOf(tileEl), false);
  });
  tilesEl.addEventListener('click', (e) => {
    const tileEl = e.target.closest('.tile');
    if (!tileEl) return;
    const id = idOf(tileEl);
    if (e.target.closest('.hide')) solov.toggleShown(id);
    else if (e.target.closest('.close')) solov.closeTab(id);
    else if (e.target.closest('.max')) solov.maximize(id);
    else if (e.target.closest('.sound')) solov.muteTab(id);
    else if (e.target.closest('.refresh')) solov.autoRefresh(id, 0);
  });
  tilesEl.addEventListener('dblclick', (e) => {
    const tileEl = e.target.closest('.tile');
    if (!tileEl || e.target.closest('.mini')) return;
    solov.maximize(idOf(tileEl)); // 雙擊標題列:放大這個方塊
  });
  tilesEl.addEventListener('contextmenu', (e) => {
    const tileEl = e.target.closest('.tile');
    if (!tileEl) return;
    e.preventDefault();
    solov.tabMenu(idOf(tileEl));
  });

  /* ───────── 事件:工具列 ───────── */
  btnBack.addEventListener('click', () => solov.back());
  btnForward.addEventListener('click', () => solov.forward());
  btnReload.addEventListener('click', () => (btnReload.dataset.mode === 'stop' ? solov.stop() : solov.reload()));
  $('#btn-home').addEventListener('click', () => solov.action('nav.home'));
  $$('.layouts button').forEach((b) => b.addEventListener('click', () => solov.setLayout(b.dataset.layout)));
  btnExt.addEventListener('click', () => solov.togglePanel('scripts'));
  btnSettings.addEventListener('click', () => solov.togglePanel('settings'));
  btnRestore.addEventListener('click', () => solov.maximize(null));

  let skipRevert = false;
  let justFocused = false;
  const revertAddr = () => {
    const act = state && state.tabs.find((t) => t.id === state.activeId);
    addr.value = act ? act.url : '';
  };
  addr.addEventListener('focus', () => { justFocused = true; addr.select(); });
  addr.addEventListener('mouseup', (e) => {
    if (justFocused) { e.preventDefault(); justFocused = false; } // 第一次點擊後保持全選
  });
  addr.addEventListener('input', () => { addrDirty = true; });
  addr.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      skipRevert = true;
      addrDirty = false;
      solov.go(addr.value);
      addr.blur();
    } else if (e.key === 'Escape') {
      addrDirty = false;
      revertAddr();
      addr.blur();
    }
  });
  addr.addEventListener('blur', () => {
    justFocused = false;
    addrDirty = false;
    if (skipRevert) { skipRevert = false; return; }
    revertAddr();
  });

  /* ───────── 事件:擴充功能面板 ───────── */
  $('#panel-close').addEventListener('click', () => solov.setPanel(false));
  $('#btn-add').addEventListener('click', () => openEditor(null));
  $('#btn-import').addEventListener('click', () => solov.scripts.importFiles());
  $('#btn-reload-shown').addEventListener('click', () => solov.scripts.reloadShown());
  $('#edit-cancel').addEventListener('click', closeEditor);
  $('#edit-save').addEventListener('click', saveEditor);

  const codeEl = $('#edit-code');
  codeEl.addEventListener('keydown', (e) => {
    if (e.key === 'Tab' && !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey) {
      e.preventDefault();
      // execCommand 會保留復原(Ctrl+Z)紀錄;萬一不支援就直接改 value
      if (!document.execCommand('insertText', false, '  ')) {
        const a = codeEl.selectionStart;
        const b = codeEl.selectionEnd;
        codeEl.value = codeEl.value.slice(0, a) + '  ' + codeEl.value.slice(b);
        codeEl.selectionStart = codeEl.selectionEnd = a + 2;
      }
    } else if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveEditor();
    }
  });
  $('#edit-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); $('#edit-match').focus(); }
  });
  $('#edit-match').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); codeEl.focus(); }
  });

  const listEl = $('#script-list');
  listEl.addEventListener('change', (e) => {
    const sw = e.target.closest('.sw');
    const li = e.target.closest('.script');
    if (sw && li) solov.scripts.toggle(li.dataset.id, sw.checked);
  });
  listEl.addEventListener('click', (e) => {
    const li = e.target.closest('.script');
    if (!li) return;
    const id = li.dataset.id;
    const script = scripts && scripts.find((s) => s.id === id);

    if (e.target.closest('.run')) {
      solov.scripts.run(id);
    } else if (e.target.closest('.edit')) {
      if (script) openEditor(script);
    } else if (e.target.closest('.del')) {
      const btn = e.target.closest('.del');
      if (btn.classList.contains('armed')) {
        solov.scripts.remove(id);
      } else {
        // 兩段式刪除:第一次按會變成「確定刪除」,2.5 秒內再按一次才真的刪
        btn.classList.add('armed');
        btn.textContent = '確定刪除';
        setTimeout(() => {
          btn.classList.remove('armed');
          btn.innerHTML = ICON.trash;
        }, 2500);
      }
    }
  });

  /* ───────── 初始化 ───────── */
  if (SettingsUI) {
    SettingsUI.init({
      api: solov.settings,
      boot: solov.boot,
      note,
      recordKeys: solov.recordKeys,
      newTab: solov.newTab,
    });
  }
  applyTooltips();

  solov.onState((s) => { state = s; render(); });
  solov.onScripts((s) => { scripts = s; renderScripts(); });
  solov.onSettings((payload) => { gotSettingsPush = true; applySettings(payload); });
  solov.onFocusAddress(() => { addr.focus(); addr.select(); });
  solov.onNote(note);

  solov.ready().then((init) => {
    // 初始資料只在還沒收到主程序推送時採用,避免蓋掉較新的狀態
    if (!state) { state = init.state; render(); }
    if (!scripts) { scripts = init.scripts; renderScripts(); }
    if (!gotSettingsPush && init.settings) applySettings(init.settings);
  });
})();

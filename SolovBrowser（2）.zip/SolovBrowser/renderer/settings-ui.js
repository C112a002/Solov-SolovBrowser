'use strict';

/**
 * 設定面板(側邊面板的「設定」頁)。
 *
 * 每個控制項只做一件事:把使用者的修改變成一小段 patch,交給主程序(solov.settings.update)。
 * 主程序驗證、套用、存檔之後會推送最新設定回來,這裡再把所有控制項同步成目前的值。
 * 所以畫面上看到的永遠是「主程序實際採用的值」,不合法的輸入會自己彈回去。
 * 整個頁面用 DOM API 建立,不使用 innerHTML。
 */
(function () {
  const Keys = window.SolovKeys;
  const Theme = window.SolovTheme;

  /* ───────── 狀態 ───────── */
  let api = null;            // window.solov.settings
  let host = null;           // { note, recordKeys, newTab }
  let current = null;        // 目前生效的設定
  let defaults = null;       // 預設設定(「還原預設」比對用)
  let keymap = { byAction: {}, conflicts: [] };
  let info = {};
  let built = false;
  let focusLater = null;     // 重建清單後要把游標放回哪裡
  const controls = [];       // 每個控制項:{ sync(settings) }
  const sections = {};       // id → { tab, panel }
  let currentSection = 'appearance';
  const SECTION_LIST = [
    ['appearance', '外觀'], ['layout', '版面'], ['browsing', '瀏覽'],
    ['newtab', '新分頁'], ['shortcuts', '快速鍵'], ['advanced', '進階'],
  ];

  /* ───────── 小工具 ───────── */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const k of Object.keys(attrs)) {
        const v = attrs[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else el.setAttribute(k, v === true ? '' : String(v));
      }
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.appendChild(typeof kid === 'object' ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  const debounce = (fn, ms) => {
    let t = 0;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  };
  const getPath = (obj, path) => path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
  function patchOf(path, value) {
    const keys = path.split('.');
    const root = {};
    let cur = root;
    keys.forEach((k, i) => {
      if (i === keys.length - 1) cur[k] = value;
      else { cur[k] = {}; cur = cur[k]; }
    });
    return root;
  }
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const isDark = () => !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  const pretty = (accel) => Keys.prettyAccel(accel);
  const errText = (err) => String((err && err.message) || err).replace(/^Error invoking remote method '[^']*': (Error: )?/, '');

  function note(text) { if (host && host.note) host.note(text); }

  /** 把修改交給主程序。成功後主程序推回的設定會經由 update() 同步到畫面。 */
  function save(patch) {
    return api.update(patch)
      .then((payload) => { update(payload); return payload; })
      .catch((err) => { note('儲存失敗:' + errText(err)); return null; });
  }

  /** 兩段式確認:第一次按改成「確定?」,2.5 秒內再按一次才真的執行 */
  function confirmButton(label, armedLabel, onConfirm, cls) {
    const btn = h('button', { class: 'btn ' + (cls || ''), type: 'button' }, label);
    let timer = 0;
    btn.addEventListener('click', () => {
      if (btn.classList.contains('armed')) {
        clearTimeout(timer);
        btn.classList.remove('armed');
        btn.textContent = label;
        onConfirm();
        return;
      }
      btn.classList.add('armed');
      btn.textContent = armedLabel;
      timer = setTimeout(() => { btn.classList.remove('armed'); btn.textContent = label; }, 2500);
    });
    return btn;
  }

  /* ───────── 版面元件 ───────── */
  const group = (title, ...items) => h('section', { class: 'sgroup' }, title ? h('h3', null, title) : null, ...items);

  function row(label, hint, control, cls) {
    return h('div', { class: 'srow ' + (cls || '') },
      h('div', { class: 'lbl' }, h('b', null, label), hint ? h('small', null, hint) : null),
      h('div', { class: 'ctl' }, control));
  }

  /* ───────── 控制項 ───────── */
  function toggle(path, label, hint) {
    const input = h('input', { type: 'checkbox', 'aria-label': label });
    input.addEventListener('change', () => save(patchOf(path, input.checked)));
    controls.push({ sync: (s) => { input.checked = !!getPath(s, path); } });
    return row(label, hint, h('label', { class: 'switch' }, input, h('span', { class: 'knob' })));
  }

  function segmented(path, options, label) {
    const wrap = h('div', { class: 'seg', role: 'group', 'aria-label': label || '' });
    const buttons = options.map(([value, text]) => {
      const b = h('button', { type: 'button', 'data-value': String(value) }, text);
      b.addEventListener('click', () => save(patchOf(path, value)));
      wrap.appendChild(b);
      return [value, b];
    });
    controls.push({
      sync: (s) => {
        const cur = getPath(s, path);
        for (const [value, b] of buttons) {
          b.classList.toggle('on', value === cur);
          b.setAttribute('aria-pressed', value === cur ? 'true' : 'false');
        }
      },
    });
    return wrap;
  }

  function select(path, options, label) {
    const sel = h('select', { class: 'sel', 'aria-label': label || '' });
    for (const [value, text] of options) sel.appendChild(h('option', { value: String(value) }, text));
    sel.addEventListener('change', () => {
      const hit = options.find(([v]) => String(v) === sel.value);
      if (hit) save(patchOf(path, hit[0]));
    });
    controls.push({ sync: (s) => { sel.value = String(getPath(s, path)); } });
    return sel;
  }

  function resetButton(visible) {
    const b = h('button', { class: 'reset', type: 'button', title: '還原預設值', 'aria-label': '還原預設值' }, '↺');
    b.hidden = true;
    return { el: b, show: (v) => { b.hidden = !visible(v); } };
  }

  function slider(path, o) {
    const input = h('input', { type: 'range', min: o.min, max: o.max, step: o.step || 1, 'aria-label': o.label });
    const out = h('output', { class: 'val' });
    const fmt = (v) => (o.format ? o.format(v) : v + (o.unit || ''));
    const rst = resetButton((v) => v !== getPath(defaults, path));
    const send = debounce((v) => save(patchOf(path, v)), 90);
    input.addEventListener('input', () => {
      out.textContent = fmt(Number(input.value));
      send(Number(input.value));
    });
    rst.el.addEventListener('click', () => save(patchOf(path, null)));
    controls.push({
      sync: (s) => {
        const v = getPath(s, path);
        rst.show(v);
        if (document.activeElement === input) return; // 正在拖曳:不要被推送回來的舊值拉回去
        input.value = String(v);
        out.textContent = fmt(v);
      },
    });
    return h('div', { class: 'slider' }, input, out, rst.el);
  }

  /** 單行文字。live = 邊打邊套用;否則在 Enter / 離開欄位時才套用。 */
  function textField(path, o) {
    const input = h('input', {
      type: 'text', class: 'txt', spellcheck: 'false', autocomplete: 'off',
      placeholder: o.placeholder || '', maxlength: o.max || 200, 'aria-label': o.label,
    });
    const send = (v) => save(patchOf(path, v)).then((p) => {
      if (p && o.check && !o.check(v, getPath(p.settings, path))) note(o.checkMsg);
      input.value = String(getPath(current, path) == null ? '' : getPath(current, path));
    });
    if (o.live) {
      const later = debounce(() => send(input.value.trim()), 300);
      input.addEventListener('input', later);
    } else {
      input.addEventListener('change', () => send(input.value.trim()));
    }
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
    controls.push({
      sync: (s) => {
        if (document.activeElement === input) return;
        const v = getPath(s, path);
        input.value = v == null ? '' : String(v);
      },
    });
    return input;
  }

  function colorField(path, o) {
    const input = h('input', { type: 'color', class: 'color', 'aria-label': o.label });
    const rst = resetButton((explicit) => !!explicit);
    const send = debounce((v) => save(patchOf(path, v)), 120);
    input.addEventListener('input', () => send(input.value));
    rst.el.addEventListener('click', () => save(patchOf(path, null)));
    controls.push({
      sync: (s) => {
        rst.show(getPath(s, path));
        if (document.activeElement === input) return;
        const v = o.effective ? o.effective(s) : getPath(s, path);
        if (/^#[0-9a-f]{6}$/i.test(v || '')) input.value = v;
      },
    });
    return h('div', { class: 'colorctl' }, input, rst.el);
  }

  /** 字型:常用字型的下拉選單 + 自訂輸入 */
  function fontField(path, presets, label) {
    const sel = h('select', { class: 'sel', 'aria-label': label });
    for (const [value, text] of presets) sel.appendChild(h('option', { value }, text));
    sel.appendChild(h('option', { value: '__custom' }, '自訂…'));
    const txt = h('input', {
      type: 'text', class: 'txt', spellcheck: 'false', autocomplete: 'off', maxlength: 200,
      placeholder: '例如:"LXGW WenKai", serif', 'aria-label': label + '(自訂)',
    });
    txt.hidden = true;
    let custom = false;
    const commitText = () => {
      const typed = txt.value.trim(); // 先記下來:存檔後畫面會被同步成主程序採用的值
      return save(patchOf(path, typed)).then((p) => {
        if (p && typed && getPath(p.settings, path) !== typed) {
          note('字型名稱只能包含文字、數字、空白、逗號、點、連字號與引號(引號要成對)。');
        }
      });
    };
    sel.addEventListener('change', () => {
      if (sel.value === '__custom') {
        custom = true;
        txt.hidden = false;
        txt.focus();
      } else {
        custom = false;
        txt.hidden = true;
        save(patchOf(path, sel.value || null));
      }
    });
    txt.addEventListener('change', commitText);
    txt.addEventListener('keydown', (e) => { if (e.key === 'Enter') txt.blur(); });
    controls.push({
      sync: (s) => {
        const v = getPath(s, path) || '';
        const preset = presets.some(([value]) => value === v);
        if (preset && !custom) {
          sel.value = v;
          txt.hidden = true;
        } else if (v || custom) {
          custom = true;
          sel.value = '__custom';
          txt.hidden = false;
          if (document.activeElement !== txt) txt.value = v;
        }
      },
    });
    return h('div', { class: 'fontctl' }, sel, txt);
  }

  /* ───────── 外觀 ───────── */
  const FONT_PRESETS = Theme.FONT_PRESETS;
  const MONO_PRESETS = Theme.MONO_PRESETS;
  const DEFAULT_ACCENT = '#0b7f8c'; // 預設配色沒有指定強調色時的青綠色(同 tokens.css 的 --accent)

  function paletteBlock() {
    const wrap = h('div', { class: 'palette', role: 'group', 'aria-label': '配色' });
    const items = Theme.PALETTE_ORDER.map((id) => {
      const b = h('button', { type: 'button', class: 'pal', 'data-palette': id, title: Theme.PALETTES[id].name, 'aria-label': Theme.PALETTES[id].name },
        h('span', { class: 'sw sw-a' }), h('span', { class: 'sw sw-b' }), h('span', { class: 'sw sw-c' }),
        h('span', { class: 'pal-name' }, Theme.PALETTES[id].name));
      b.addEventListener('click', () => save({ appearance: { palette: id } }));
      wrap.appendChild(b);
      return [id, b];
    });
    controls.push({
      sync: (s) => {
        const dark = isDark();
        const mode = dark ? 'dark' : 'light';
        for (const [id, b] of items) {
          const surf = Theme.paletteSurfaces(id, mode);
          const accentHex = Theme.PALETTES[id].accent || DEFAULT_ACCENT;
          const accent = Theme.deriveAccent(accentHex, dark, surf.bar).accent;
          const [a, bb, c] = b.querySelectorAll('.sw');
          a.style.background = surf.stage;
          bb.style.background = surf.bar;
          c.style.background = accent;
          b.classList.toggle('on', s.appearance.palette === id);
          b.setAttribute('aria-pressed', s.appearance.palette === id ? 'true' : 'false');
        }
      },
    });
    return wrap;
  }

  function accentBlock() {
    const dots = h('div', { class: 'dots', role: 'group', 'aria-label': '強調色' });
    const items = Theme.ACCENT_PRESETS.map(([hex, name]) => {
      const b = h('button', { type: 'button', class: 'dot', title: name, 'aria-label': name, 'data-accent': hex });
      b.style.background = hex;
      b.addEventListener('click', () => save({ appearance: { accent: hex } }));
      dots.appendChild(b);
      return [hex, b];
    });
    const custom = colorField('appearance.accent', {
      label: '自訂強調色',
      effective: (s) => {
        const pal = Theme.PALETTES[s.appearance.palette] || Theme.PALETTES.default;
        return s.appearance.accent || pal.accent || DEFAULT_ACCENT;
      },
    });
    controls.push({
      sync: (s) => {
        for (const [hex, b] of items) {
          b.classList.toggle('on', s.appearance.accent === hex);
          b.setAttribute('aria-pressed', s.appearance.accent === hex ? 'true' : 'false');
        }
      },
    });
    return row('強調色', '使用中的方塊、按鈕與開關的顏色(留空 = 跟著配色)', h('div', { class: 'accentctl' }, dots, custom), 'wide');
  }

  function colorsBlock() {
    const body = h('div', { class: 'colorgrid' });
    for (const mode of ['light', 'dark']) {
      body.appendChild(h('h4', null, mode === 'light' ? '淺色模式' : '深色模式'));
      for (const [key, label] of Theme.COLOR_KEYS) {
        body.appendChild(row(label, '', colorField(`appearance.colors.${mode}.${key}`, {
          label: `${mode === 'light' ? '淺色' : '深色'}模式的${label}`,
          effective: (s) => Theme.surfaces(s.appearance, mode)[key],
        }), 'compact'));
      }
    }
    const clear = confirmButton('清除所有自訂顏色', '再按一次確定', () => save({ appearance: { colors: { light: null, dark: null } } }), 'small');
    body.appendChild(h('div', { class: 'actions' }, clear));
    return h('details', { class: 'more' }, h('summary', null, '逐項自訂顏色(進階)'), body);
  }

  function buildAppearance(el) {
    el.append(
      group('色彩',
        row('色彩模式', '「淺色」「深色」也會讓支援深色模式的網頁一起切換', segmented('appearance.theme', [['system', '跟隨系統'], ['light', '淺色'], ['dark', '深色']], '色彩模式'), 'wide'),
        row('配色', '', paletteBlock(), 'wide stack'),
        accentBlock(),
        colorsBlock()),
      group('字型與大小',
        row('介面字型', '分頁、工具列、面板與新分頁頁面', fontField('appearance.fontUi', FONT_PRESETS, '介面字型'), 'wide'),
        row('程式碼字型', '腳本編輯器與自訂 CSS 的輸入框', fontField('appearance.fontMono', MONO_PRESETS, '程式碼字型'), 'wide'),
        row('介面字級', '', slider('appearance.fontSize', { min: 11, max: 18, unit: ' px', label: '介面字級' }))),
      group('形狀與密度',
        row('介面密度', '分頁列與工具列的高度', segmented('appearance.density', [['compact', '緊湊'], ['normal', '標準'], ['comfortable', '寬鬆']], '介面密度'), 'wide'),
        row('圓角', '', segmented('appearance.radius', [['sharp', '直角'], ['small', '小'], ['normal', '標準'], ['large', '大'], ['round', '圓']], '圓角'), 'wide'),
        row('分頁寬度', '', slider('appearance.tabWidth', { min: 120, max: 320, step: 4, unit: ' px', label: '分頁寬度' }))),
      sectionReset(['appearance']));
  }

  /* ───────── 版面 ───────── */
  function buildLayout(el) {
    el.append(
      group('畫面配置',
        row('啟動時的配置', '', select('layout.startLayout', [
          ['last', '記住上次的'], ['single', '單一分頁'], ['grid', '自動網格'], ['cols', '左右並排'], ['rows', '上下堆疊'],
        ], '啟動時的配置')),
        row('自動網格的欄數', '0 = 依視窗形狀自動決定', slider('layout.gridColumns', {
          min: 0, max: 8, label: '自動網格的欄數', format: (v) => (v === 0 ? '自動' : v + ' 欄'),
        })),
        row('左右並排:方塊最窄', '再窄就自動換成多排', slider('layout.minTileW', { min: 160, max: 800, step: 10, unit: ' px', label: '方塊最窄寬度' })),
        row('上下堆疊:方塊最矮', '再矮就自動改成每列放多個', slider('layout.minTileH', { min: 100, max: 600, step: 10, unit: ' px', label: '方塊最矮高度' }))),
      group('方塊',
        row('方塊間距', '', slider('layout.gap', { min: 0, max: 24, unit: ' px', label: '方塊間距' })),
        row('外側留白', '方塊區與視窗邊緣的距離', slider('layout.pad', { min: 0, max: 24, unit: ' px', label: '外側留白' })),
        row('邊框粗細', '使用中的方塊會換成強調色', slider('layout.frame', { min: 1, max: 6, unit: ' px', label: '邊框粗細' })),
        toggle('layout.showHead', '顯示方塊標題列', '關閉後只剩邊框,靠快速鍵與右鍵選單操作'),
        row('標題列高度', '', slider('layout.headH', { min: 22, max: 44, unit: ' px', label: '標題列高度' }))),
      group('介面',
        toggle('layout.showTabStrip', '顯示分頁列', '關閉後用 Ctrl+Tab、Ctrl+1…9 或方塊標題列切換'),
        toggle('layout.toolbar.nav', '工具列:上一頁 / 下一頁 / 重新整理', ''),
        toggle('layout.toolbar.home', '工具列:首頁按鈕', ''),
        toggle('layout.toolbar.layouts', '工具列:畫面配置按鈕', ''),
        toggle('layout.toolbar.ext', '工具列:擴充功能按鈕', ''),
        row('側邊面板寬度', '設定面板至少 480 px', slider('layout.panelWidth', { min: 320, max: 760, step: 10, unit: ' px', label: '側邊面板寬度' }))),
      group('視窗',
        toggle('window.alwaysOnTop', '視窗永遠在最上層', ''),
        row('視窗不透明度', '只有 Windows 與 macOS 有效', slider('window.opacity', { min: 30, max: 100, step: 5, unit: '%', label: '視窗不透明度' }))),
      sectionReset(['layout', 'window']));
  }

  /* ───────── 瀏覽 ───────── */
  const UA_PRESETS = [
    ['', '預設(Chrome,依系統)'],
    ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'Chrome · Windows'],
    ['Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'Chrome · macOS'],
    ['Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 'Chrome · Linux'],
    ['Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0', 'Firefox · Windows'],
    ['Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36', '手機版 Chrome · Android'],
    ['Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1', '手機版 Safari · iPhone'],
  ];

  function uaField() {
    const sel = h('select', { class: 'sel', 'aria-label': 'User-Agent' });
    for (const [value, text] of UA_PRESETS) sel.appendChild(h('option', { value }, text));
    sel.appendChild(h('option', { value: '__custom' }, '自訂…'));
    const txt = h('input', { type: 'text', class: 'txt', spellcheck: 'false', autocomplete: 'off', maxlength: 400, placeholder: 'Mozilla/5.0 …', 'aria-label': 'User-Agent(自訂)' });
    txt.hidden = true;
    let custom = false;
    sel.addEventListener('change', () => {
      if (sel.value === '__custom') { custom = true; txt.hidden = false; txt.focus(); return; }
      custom = false;
      txt.hidden = true;
      save(patchOf('browsing.userAgent', sel.value || null));
    });
    txt.addEventListener('change', () => save(patchOf('browsing.userAgent', txt.value.trim())));
    txt.addEventListener('keydown', (e) => { if (e.key === 'Enter') txt.blur(); });
    controls.push({
      sync: (s) => {
        const v = s.browsing.userAgent || '';
        const preset = UA_PRESETS.some(([value]) => value === v);
        if (preset && !custom) { sel.value = v; txt.hidden = true; return; }
        custom = true;
        sel.value = '__custom';
        txt.hidden = false;
        if (document.activeElement !== txt) txt.value = v;
      },
    });
    return h('div', { class: 'fontctl' }, sel, txt);
  }

  function engineRow(e) {
    const name = h('input', { type: 'text', class: 'txt e-name', maxlength: 40, placeholder: '名稱', 'aria-label': '搜尋引擎名稱', spellcheck: 'false' });
    const kw = h('input', { type: 'text', class: 'txt e-kw', maxlength: 16, placeholder: '@關鍵字', 'aria-label': '搜尋關鍵字', spellcheck: 'false' });
    const url = h('input', { type: 'text', class: 'txt e-url', maxlength: 500, placeholder: 'https://…?q=%s', 'aria-label': '搜尋網址(用 %s 代表搜尋內容)', spellcheck: 'false' });
    const def = h('input', { type: 'radio', name: 'default-engine', 'aria-label': '設為預設搜尋引擎' });
    const del = h('button', { class: 'mini', type: 'button', title: '刪除這個搜尋引擎', 'aria-label': '刪除這個搜尋引擎' }, '×');
    const el = h('div', { class: 'engine', 'data-id': e.id },
      h('label', { class: 'defpick', title: '預設搜尋引擎' }, def, h('span', null, '預設')), name, kw, url, del);

    const list = () => current.browsing.engines;
    const commit = () => {
      const u = url.value.trim();
      if (!/^https?:\/\/\S+$/i.test(u) || u.indexOf('%s') < 0) {
        url.setAttribute('aria-invalid', 'true');
        note('搜尋網址要以 http:// 或 https:// 開頭,並用 %s 代表搜尋內容,例如 https://www.google.com/search?q=%s');
        return;
      }
      url.removeAttribute('aria-invalid');
      const k = kw.value.trim().replace(/\s+/g, '').toLowerCase();
      save({ browsing: { engines: list().map((x) => (x.id === e.id ? { id: x.id, name: name.value.trim() || x.name, keyword: k, url: u } : x)) } });
    };
    for (const input of [name, kw, url]) {
      input.addEventListener('change', commit);
      input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') input.blur(); });
    }
    def.addEventListener('change', () => { if (def.checked) save({ browsing: { defaultEngine: e.id } }); });
    del.addEventListener('click', () => {
      if (list().length <= 1) { note('至少要保留一個搜尋引擎。'); return; }
      save({ browsing: { engines: list().filter((x) => x.id !== e.id) } });
    });
    return {
      el,
      set: (eng, defaultId) => {
        for (const [input, v] of [[name, eng.name], [kw, eng.keyword], [url, eng.url]]) {
          if (document.activeElement !== input && input.value !== v) input.value = v;
        }
        def.checked = eng.id === defaultId;
        del.disabled = list().length <= 1;
      },
    };
  }

  function enginesBlock() {
    const listEl = h('div', { class: 'elist' });
    let sig = '';
    let rows = [];
    controls.push({
      sync: (s) => {
        const engines = s.browsing.engines;
        const next = engines.map((e) => e.id).join('|');
        if (next !== sig) {
          sig = next;
          listEl.textContent = '';
          rows = engines.map(engineRow);
          rows.forEach((r) => listEl.appendChild(r.el));
          if (focusLater === 'engine') {
            focusLater = null;
            const last = listEl.querySelector('.engine:last-child input[type=text]');
            if (last) { last.focus(); last.select(); }
          }
        }
        engines.forEach((e, i) => rows[i].set(e, s.browsing.defaultEngine));
      },
    });
    const add = h('button', { class: 'btn', type: 'button' }, '新增搜尋引擎');
    add.addEventListener('click', () => {
      if (current.browsing.engines.length >= 30) { note('搜尋引擎最多 30 個。'); return; }
      focusLater = 'engine';
      save({ browsing: { engines: current.browsing.engines.concat([{ id: '', name: '新搜尋引擎', keyword: '', url: 'https://www.example.com/search?q=%s' }]) } });
    });
    const reset = confirmButton('還原預設引擎', '再按一次確定', () => save({
      browsing: { engines: clone(defaults.browsing.engines), defaultEngine: defaults.browsing.defaultEngine },
    }));
    return h('div', { class: 'listblock' },
      listEl, h('div', { class: 'actions' }, add, reset),
      h('p', { class: 'tip' }, '在網址列輸入「關鍵字 + 空白 + 搜尋內容」就會改用那個搜尋引擎,例如 @yt 貓咪。網址裡的 %s 會換成搜尋內容。'));
  }

  function permissionsBlock() {
    const names = {
      media: ['攝影機與麥克風', ''], geolocation: ['位置', ''], notifications: ['通知', ''],
      'clipboard-read': ['讀取剪貼簿', ''], 'display-capture': ['擷取螢幕畫面', ''],
    };
    const opts = [['ask', '每次詢問'], ['allow', '一律允許'], ['block', '一律封鎖']];
    return Object.keys(names).map((k) => row(names[k][0], '', select(`browsing.permissions.${k}`, opts, names[k][0])));
  }

  function refreshField() {
    const input = h('input', { type: 'text', class: 'txt', spellcheck: 'false', autocomplete: 'off', placeholder: '10, 30, 60, 300, 900', 'aria-label': '自動重新整理可選的間隔(秒)' });
    input.addEventListener('change', () => {
      const nums = input.value.split(/[\s,、,]+/).filter(Boolean).map(Number);
      const ok = nums.length > 0 && nums.every((n) => Number.isInteger(n) && n >= 5 && n <= 86400);
      if (!ok) {
        note('請輸入 5 到 86400 之間的整數秒數,用逗號分隔,例如 10, 30, 60, 300。');
        input.value = current.browsing.refreshChoices.join(', ');
        return;
      }
      save({ browsing: { refreshChoices: nums } }).then(() => { input.value = current.browsing.refreshChoices.join(', '); });
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
    controls.push({ sync: (s) => { if (document.activeElement !== input) input.value = s.browsing.refreshChoices.join(', '); } });
    return input;
  }

  function buildBrowsing(el) {
    const zoomFmt = (v) => v + '%';
    el.append(
      group('啟動與首頁',
        row('啟動時', '', select('browsing.startup', [['restore', '還原上次開著的分頁'], ['home', '開啟首頁'], ['newtab', '開一個新分頁']], '啟動時')),
        row('首頁網址', '留空 = 內建新分頁頁面', textField('browsing.homepage', {
          label: '首頁網址', placeholder: 'https://…', max: 1000,
          check: (sent, got) => got === sent, checkMsg: '首頁網址要以 http://、https:// 或 file:// 開頭,而且不能有空白。',
        }), 'wide'),
        row('新分頁開啟', '', select('browsing.newTab', [['builtin', '內建新分頁頁面'], ['blank', '空白頁'], ['home', '首頁']], '新分頁開啟'))),
      group('搜尋', row('預設搜尋引擎', '', enginesBlock(), 'wide stack')),
      group('網頁',
        row('預設縮放', '只影響還沒有自己縮放設定的網站;Ctrl+0 回到這個值', slider('browsing.defaultZoom', { min: 25, max: 300, step: 5, format: zoomFmt, label: '預設縮放' })),
        row('自動重新整理的可選間隔', '單位:秒。分頁右鍵選單與方塊標題列會用到', refreshField(), 'wide')),
      group('網站權限', ...permissionsBlock()),
      group('瀏覽器識別',
        row('User-Agent', '告訴網站你是什麼瀏覽器;改了之後重新載入頁面才生效', uaField(), 'wide stack'),
        row('Accept-Language', '網站偏好的語言,例如 zh-TW,zh;q=0.9,en;q=0.8(留空 = 跟系統)', textField('browsing.acceptLanguages', {
          label: 'Accept-Language', placeholder: 'zh-TW,zh;q=0.9,en;q=0.8', max: 100,
          check: (sent, got) => got === sent, checkMsg: '語言格式不正確,只能用英文字母、數字、逗號、分號、等號、句點與連字號。',
        }), 'wide')),
      sectionReset(['browsing']));
  }

  /* ───────── 新分頁 ───────── */
  function linksBlock() {
    const listEl = h('div', { class: 'llist' });
    let sig = '';
    let rows = [];

    const build = (l, i) => {
      const name = h('input', { type: 'text', class: 'txt', maxlength: 30, placeholder: '名稱', 'aria-label': '連結名稱', spellcheck: 'false' });
      const url = h('input', { type: 'text', class: 'txt', maxlength: 500, placeholder: 'https://…', 'aria-label': '連結網址', spellcheck: 'false' });
      const up = h('button', { class: 'mini', type: 'button', title: '往上移', 'aria-label': '往上移' }, '↑');
      const down = h('button', { class: 'mini', type: 'button', title: '往下移', 'aria-label': '往下移' }, '↓');
      const del = h('button', { class: 'mini', type: 'button', title: '刪除', 'aria-label': '刪除' }, '×');
      const el = h('div', { class: 'link' }, name, url, up, down, del);
      const list = () => current.newtab.links;
      const commit = () => {
        const u = url.value.trim();
        if (!/^(https?|file):\/\/\S+$/i.test(u)) {
          url.setAttribute('aria-invalid', 'true');
          note('連結網址要以 http://、https:// 或 file:// 開頭,而且不能有空白。');
          return;
        }
        url.removeAttribute('aria-invalid');
        save({ newtab: { links: list().map((x, j) => (j === i ? { name: name.value.trim(), url: u } : x)) } });
      };
      name.addEventListener('change', commit);
      url.addEventListener('change', commit);
      for (const input of [name, url]) input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') input.blur(); });
      const move = (d) => {
        const a = list().slice();
        const j = i + d;
        if (j < 0 || j >= a.length) return;
        [a[i], a[j]] = [a[j], a[i]];
        save({ newtab: { links: a } });
      };
      up.addEventListener('click', () => move(-1));
      down.addEventListener('click', () => move(1));
      del.addEventListener('click', () => save({ newtab: { links: list().filter((_, j) => j !== i) } }));
      return {
        el,
        set: (link, n) => {
          for (const [input, v] of [[name, link.name], [url, link.url]]) {
            if (document.activeElement !== input && input.value !== v) input.value = v;
          }
          up.disabled = i === 0;
          down.disabled = i === n - 1;
        },
      };
    };

    controls.push({
      sync: (s) => {
        const links = s.newtab.links;
        const next = links.map((l, i) => i + ':' + l.url).join('|') + '#' + links.length;
        if (next !== sig && !(listEl.contains(document.activeElement) && rows.length === links.length)) {
          sig = next;
          listEl.textContent = '';
          rows = links.map(build);
          rows.forEach((r) => listEl.appendChild(r.el));
          if (focusLater === 'link') {
            focusLater = null;
            const last = listEl.querySelector('.link:last-child input');
            if (last) { last.focus(); last.select(); }
          }
        }
        links.forEach((l, i) => { if (rows[i]) rows[i].set(l, links.length); });
        listEl.classList.toggle('empty', links.length === 0);
      },
    });
    const add = h('button', { class: 'btn', type: 'button' }, '新增連結');
    add.addEventListener('click', () => {
      if (current.newtab.links.length >= 24) { note('快速連結最多 24 個。'); return; }
      focusLater = 'link';
      save({ newtab: { links: current.newtab.links.concat([{ name: '新連結', url: 'https://www.example.com/' }]) } });
    });
    const reset = confirmButton('還原預設連結', '再按一次確定', () => save({ newtab: { links: clone(defaults.newtab.links) } }));
    return h('div', { class: 'listblock' }, listEl, h('div', { class: 'actions' }, add, reset));
  }

  function bgBlock() {
    const mode = segmented('newtab.bg.mode', [['default', '預設'], ['color', '純色'], ['image', '圖片']], '背景');
    const color = colorField('newtab.bg.color', { label: '背景顏色' });
    const pick = h('button', { class: 'btn', type: 'button' }, '選擇圖片…');
    const clear = h('button', { class: 'btn', type: 'button' }, '移除圖片');
    const state = h('span', { class: 'bgstate' });
    pick.addEventListener('click', () => {
      api.pickImage().then((r) => {
        if (r && r.url) save({ newtab: { bg: { mode: 'image', image: r.url } } });
      }).catch((err) => note('無法使用這張圖片:' + errText(err)));
    });
    clear.addEventListener('click', () => save({ newtab: { bg: { image: null, mode: 'default' } } }));
    controls.push({
      sync: (s) => {
        const bg = s.newtab.bg;
        color.hidden = bg.mode !== 'color';
        pick.parentNode.hidden = bg.mode !== 'image';
        state.textContent = bg.image ? '已選擇圖片' : '還沒有選擇圖片';
        clear.hidden = !bg.image;
      },
    });
    return h('div', { class: 'bgctl' }, mode, color, h('div', { class: 'actions' }, pick, clear, state));
  }

  function buildNewtab(el) {
    const preview = h('button', { class: 'btn', type: 'button' }, '開一個新分頁看看');
    preview.addEventListener('click', () => { if (host.newTab) host.newTab(); });
    // 「圖片暗化」只對圖片背景有意義,其他背景模式就收起來
    const dimRow = row('圖片暗化', '壓暗背景,讓文字更清楚', slider('newtab.bg.dim', { min: 0, max: 80, step: 5, unit: '%', label: '圖片暗化' }));
    controls.push({ sync: (s) => { dimRow.hidden = s.newtab.bg.mode !== 'image'; } });
    el.append(
      group('文字',
        row('標題', '', textField('newtab.title', { label: '新分頁標題', max: 40, live: true }), 'wide'),
        row('副標題', '', textField('newtab.subtitle', { label: '新分頁副標題', max: 80, live: true }), 'wide')),
      group('顯示',
        toggle('newtab.showSearch', '搜尋框', ''),
        toggle('newtab.showLinks', '快速連結', ''),
        toggle('newtab.showTips', '使用提示', '提示裡的快速鍵會跟著你的設定變'),
        toggle('newtab.showClock', '時鐘', '')),
      group('背景',
        row('背景', '', bgBlock(), 'wide stack'),
        dimRow),
      group('快速連結', linksBlock()),
      h('div', { class: 'actions' }, preview),
      sectionReset(['newtab']));
  }

  /* ───────── 快速鍵 ───────── */
  let rec = null; // 正在錄製:{ id, row, onKey }

  /** 按鍵事件 → 快速鍵字串(Mac 的 Option 會把字母變成符號,這時改看實體按鍵) */
  function accelOf(e) {
    let accel = Keys.accelFromInput(e);
    if (!accel && !/^(Control|Shift|Alt|Meta)$/.test(e.key)) {
      const m = /^(?:Key([A-Z])|Digit([0-9]))$/.exec(e.code || '');
      if (m) accel = Keys.accelFromInput({ key: m[1] || m[2], ctrlKey: e.ctrlKey, altKey: e.altKey, shiftKey: e.shiftKey, metaKey: e.metaKey });
    }
    return accel;
  }

  function setRowMsg(rowEl, kind, text, buttons) {
    const msg = rowEl.querySelector('.kmsg');
    msg.className = 'kmsg ' + (kind || '');
    msg.textContent = text || '';
    for (const [label, fn] of buttons || []) {
      const b = h('button', { class: 'btn small', type: 'button' }, label);
      b.addEventListener('click', fn);
      msg.appendChild(b);
    }
  }

  function stopRec() {
    if (!rec) return;
    window.removeEventListener('keydown', rec.onKey, true);
    if (host.recordKeys) host.recordKeys(false);
    setRowMsg(rec.row, '', '');
    rec = null;
  }

  /** 清掉所有動作列上殘留的提示(重複、衝突詢問…),免得開始錄別的動作時舊訊息還掛在那裡 */
  function clearRowMsgs() {
    for (const m of document.querySelectorAll('.krow .kmsg')) {
      m.className = 'kmsg';
      m.textContent = '';
    }
  }

  function assign(action, accel, rowEl) {
    const mine = keymap.byAction[action.id] || [];
    if (mine.indexOf(accel) >= 0) { setRowMsg(rowEl, 'warn', '已經有這個快速鍵了。'); return; }
    const owner = Keys.ACTIONS.find((a) => a.id !== action.id && (keymap.byAction[a.id] || []).indexOf(accel) >= 0);
    const commit = (takeOver) => {
      const patch = { shortcuts: { [action.id]: mine.concat([accel]) } };
      if (takeOver) patch.shortcuts[owner.id] = keymap.byAction[owner.id].filter((k) => k !== accel);
      setRowMsg(rowEl, '', '');
      save(patch);
    };
    if (!owner) { commit(false); return; }
    setRowMsg(rowEl, 'warn', `「${owner.label}」已經在用 ${pretty(accel)}。改用在這裡?`, [
      ['改用在這裡', () => commit(true)],
      ['取消', () => setRowMsg(rowEl, '', '')],
    ]);
  }

  function startRec(action, rowEl) {
    stopRec();
    clearRowMsgs();
    setRowMsg(rowEl, 'rec', '請按下新的快速鍵…(Esc 取消)');
    if (host.recordKeys) host.recordKeys(true);
    const onKey = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === 'Escape' && !e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey) { stopRec(); return; }
      const accel = accelOf(e);
      if (!accel) return; // 只按了修飾鍵:繼續等
      if (!Keys.isValidBinding(accel)) {
        setRowMsg(rowEl, 'warn', `${pretty(accel)} 不能用:需要含 Ctrl 或 Alt(或使用 F1–F24),而且不能是複製、貼上這類文字編輯的快速鍵。`);
        return;
      }
      stopRec();
      assign(action, accel, rowEl);
    };
    window.addEventListener('keydown', onKey, true);
    rec = { id: action.id, row: rowEl, onKey };
  }

  function shortcutRow(a) {
    const chips = h('div', { class: 'chips' });
    const add = h('button', { class: 'btn small', type: 'button', 'aria-label': `為「${a.label}」新增快速鍵` }, '+ 新增');
    const rst = h('button', { class: 'reset', type: 'button', title: '還原這個動作的快速鍵', 'aria-label': '還原預設快速鍵' }, '↺');
    const msg = h('div', { class: 'kmsg', role: 'status' });
    const rowEl = h('div', { class: 'krow', 'data-action': a.id },
      h('div', { class: 'kname' }, a.label), chips, add, msg);
    add.addEventListener('click', () => startRec(a, rowEl));
    rst.addEventListener('click', () => save({ shortcuts: { [a.id]: null } }));
    controls.push({
      sync: (s) => {
        const keys = keymap.byAction[a.id] || [];
        chips.textContent = '';
        if (!keys.length) chips.appendChild(h('span', { class: 'none' }, '未設定'));
        for (const k of keys) {
          const del = h('button', { class: 'x', type: 'button', title: '移除這個快速鍵', 'aria-label': '移除 ' + pretty(k) }, '×');
          del.addEventListener('click', () => save({ shortcuts: { [a.id]: keys.filter((x) => x !== k) } }));
          const clash = keymap.conflicts.some((c) => c.b === a.id && c.accel === k);
          chips.appendChild(h('kbd', { class: 'chip' + (clash ? ' clash' : ''), title: clash ? '和前面的動作衝突,這個快速鍵不會生效' : '' }, pretty(k), del));
        }
        rst.hidden = !(s.shortcuts && Object.prototype.hasOwnProperty.call(s.shortcuts, a.id));
        chips.appendChild(rst); // 還原按鈕接在最後一個快速鍵後面
        rowEl.dataset.search = (a.label + ' ' + keys.map(pretty).join(' ') + ' ' + keys.join(' ')).toLowerCase();
      },
    });
    return rowEl;
  }

  function buildShortcuts(el) {
    const filter = h('input', { type: 'search', class: 'txt', placeholder: '搜尋動作或快速鍵…', 'aria-label': '搜尋動作或快速鍵', spellcheck: 'false' });
    const list = h('div', { class: 'klist' });
    for (const cat of Keys.CATEGORIES) {
      const g = h('section', { class: 'kgroup' }, h('h3', null, cat.label));
      for (const a of Keys.ACTIONS.filter((x) => x.cat === cat.id)) g.appendChild(shortcutRow(a));
      list.appendChild(g);
    }
    const none = h('p', { class: 'tip', hidden: true }, '沒有符合的動作。');
    filter.addEventListener('input', () => {
      const q = filter.value.trim().toLowerCase();
      let shown = 0;
      for (const r of list.querySelectorAll('.krow')) {
        const hit = !q || (r.dataset.search || '').indexOf(q) >= 0;
        r.hidden = !hit;
        if (hit) shown++;
      }
      for (const g of list.querySelectorAll('.kgroup')) g.hidden = !g.querySelector('.krow:not([hidden])');
      none.hidden = shown > 0;
    });
    const conflict = h('p', { class: 'kwarn', role: 'status', hidden: true });
    controls.push({
      sync: () => {
        const n = keymap.conflicts.length;
        conflict.hidden = n === 0;
        conflict.textContent = n ? `有 ${n} 組快速鍵重複使用,只有排在前面的動作會生效(紅色標示的那些)。` : '';
      },
    });
    el.append(
      h('p', { class: 'tip' }, '按「+ 新增」再按下想用的組合鍵。一個動作可以有好幾個快速鍵;快速鍵必須含 Ctrl 或 Alt(F1–F24 例外)。'),
      conflict, filter, list, none,
      sectionReset(['shortcuts'], '全部還原預設快速鍵'));
  }

  /* ───────── 進階 ───────── */
  function buildAdvanced(el) {
    const ta = h('textarea', {
      class: 'code', spellcheck: 'false', wrap: 'off', rows: 10, autocapitalize: 'off', 'aria-label': '自訂 CSS',
      placeholder: '/* 範例:拿掉這段前後的註解符號就會生效\n.tile.active .head { font-weight: 700; }\n#addr { font-family: var(--mono); }\n*/',
    });
    const send = debounce(() => save({ customCss: ta.value }), 500);
    ta.addEventListener('input', send);
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Tab' && !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey) {
        e.preventDefault();
        if (!document.execCommand('insertText', false, '  ')) {
          const a = ta.selectionStart;
          ta.value = ta.value.slice(0, a) + '  ' + ta.value.slice(ta.selectionEnd);
          ta.selectionStart = ta.selectionEnd = a + 2;
          send();
        }
      }
    });
    controls.push({
      sync: (s) => { if (document.activeElement !== ta && ta.value !== s.customCss) ta.value = s.customCss; },
    });
    const clearCss = confirmButton('清除自訂 CSS', '再按一次確定', () => save({ customCss: '' }), 'small');

    const withScripts = h('input', { type: 'checkbox', 'aria-label': '匯出時一併包含腳本' });
    const exportBtn = h('button', { class: 'btn', type: 'button' }, '匯出設定…');
    exportBtn.addEventListener('click', () => {
      api.exportFile(withScripts.checked).then((r) => {
        if (r && r.ok) note('已匯出到 ' + r.file);
      }).catch((err) => note('匯出失敗:' + errText(err)));
    });
    const importBtn = h('button', { class: 'btn', type: 'button' }, '匯入設定…');
    importBtn.addEventListener('click', () => {
      api.importFile().then((r) => {
        if (!r || r.canceled) return;
        if (r.payload) update(r.payload);
        note('已匯入設定' + (r.scripts ? `,另外加入 ${r.scripts} 個腳本(預設停用)` : '') + '。');
      }).catch((err) => note('匯入失敗:' + errText(err)));
    });
    const folderBtn = h('button', { class: 'btn', type: 'button' }, '開啟資料夾');
    folderBtn.addEventListener('click', () => api.openFolder());

    const kinds = [['cache', '快取'], ['cookies', 'Cookie(會登出所有網站)'], ['storage', '網站儲存資料(localStorage、IndexedDB…)'], ['permissions', '已記住的網站權限']];
    const boxes = kinds.map(([id, label]) => {
      const cb = h('input', { type: 'checkbox', 'data-kind': id });
      return [id, cb, h('label', { class: 'check' }, cb, h('span', null, label))];
    });
    const clearBtn = h('button', { class: 'btn', type: 'button' }, '清除選取的資料…');
    clearBtn.addEventListener('click', () => {
      const picked = boxes.filter(([, cb]) => cb.checked).map(([id]) => id);
      if (!picked.length) { note('先勾選要清除的項目。'); return; }
      api.clearData(picked).then((r) => {
        if (r && r.cleared && r.cleared.length) note('已清除:' + r.cleared.join('、'));
      }).catch((err) => note('清除失敗:' + errText(err)));
    });

    const resetAll = confirmButton('全部還原成預設值', '再按一次,真的要還原', () => {
      api.reset(null).then((p) => { update(p); note('已還原所有設定。'); }).catch((err) => note('還原失敗:' + errText(err)));
    }, 'danger');

    const banner = h('p', { class: 'kwarn', role: 'status', hidden: true });
    const about = h('p', { class: 'tip' });
    controls.push({
      sync: () => {
        const lines = [];
        if (info.safeMode) lines.push('安全模式:這次執行沒有套用自訂 CSS。');
        if (info.loadError) lines.push(info.loadError);
        banner.hidden = lines.length === 0;
        banner.textContent = lines.join(' ');
        about.textContent = `版本 ${info.version || ''} · 資料夾:${info.dataDir || ''}`
          + (info.migratedFrom ? ` · 已從舊版搬入設定與腳本(${info.migratedFrom})` : '');
      },
    });

    el.append(
      banner,
      group('自訂 CSS',
        h('p', { class: 'tip' }, '會套用到瀏覽器介面和新分頁頁面,改了立刻看得到。可以用的變數:--accent、--bar、--strip、--stage、--ink、--round、--fs…(完整清單與範例在說明文件 README.md 的「自訂 CSS」)。'),
        h('p', { class: 'tip' }, '請不要用 CSS 改變分頁列、工具列、方塊標題列的高度,網頁的位置會對不齊;高度請到「外觀」(介面密度)與「版面」調整。'),
        ta, h('div', { class: 'actions' }, clearCss),
        h('p', { class: 'tip' }, '如果 CSS 把介面弄壞了,用「--safe-mode」啟動(run.bat --safe-mode)就不會套用它。')),
      group('備份與分享',
        h('div', { class: 'actions' }, exportBtn, h('label', { class: 'check' }, withScripts, h('span', null, '一併匯出腳本')), importBtn, folderBtn),
        h('p', { class: 'tip' }, '設定檔是純文字 JSON。匯入含自訂 CSS 的檔案時會先請你確認;匯入的腳本一律先停用。')),
      group('清除瀏覽資料',
        h('div', { class: 'checks' }, boxes.map((b) => b[2])),
        h('div', { class: 'actions' }, clearBtn)),
      group('重設', h('div', { class: 'actions' }, resetAll), about));
  }

  /** 每個設定頁底下的「還原這一頁」 */
  function sectionReset(names, label) {
    const btn = confirmButton(label || '還原這一頁的預設值', '再按一次確定', () => {
      names.reduce((p, n) => p.then(() => api.reset(n).then(update)), Promise.resolve())
        .then(() => note('已還原。'))
        .catch((err) => note('還原失敗:' + errText(err)));
    });
    return h('div', { class: 'sreset' }, btn);
  }

  /* ───────── 組裝 ───────── */
  const BUILDERS = {
    appearance: buildAppearance, layout: buildLayout, browsing: buildBrowsing,
    newtab: buildNewtab, shortcuts: buildShortcuts, advanced: buildAdvanced,
  };

  function showSection(id) {
    if (!sections[id]) return;
    currentSection = id;
    for (const k of Object.keys(sections)) {
      const on = k === id;
      sections[k].panel.hidden = !on;
      sections[k].tab.setAttribute('aria-selected', on ? 'true' : 'false');
      sections[k].tab.tabIndex = on ? 0 : -1;
    }
    if (id !== 'shortcuts') stopRec();
    try { localStorage.setItem('solov.settings.section', id); } catch (_) { /* ignore */ }
    const body = document.getElementById('settings-body');
    if (body) body.scrollTop = 0;
  }

  function build() {
    const tabs = document.getElementById('settings-tabs');
    const body = document.getElementById('settings-body');
    if (!tabs || !body) return;
    for (const [id, label] of SECTION_LIST) {
      const tab = h('button', { type: 'button', class: 'stab', role: 'tab', 'data-section': id, 'aria-selected': 'false' }, label);
      tab.addEventListener('click', () => showSection(id));
      tabs.appendChild(tab);
      const panel = h('div', { class: 'spanel', role: 'tabpanel', 'data-section': id, hidden: true });
      BUILDERS[id](panel);
      body.appendChild(panel);
      sections[id] = { tab, panel };
    }
    tabs.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const ids = SECTION_LIST.map((s) => s[0]);
      const i = ids.indexOf(currentSection);
      const next = ids[(i + (e.key === 'ArrowRight' ? 1 : ids.length - 1)) % ids.length];
      showSection(next);
      sections[next].tab.focus();
    });
    document.addEventListener('mousedown', (e) => { if (rec && !rec.row.contains(e.target)) stopRec(); }, true);
    window.addEventListener('blur', stopRec);
    let saved = null;
    try { saved = localStorage.getItem('solov.settings.section'); } catch (_) { /* ignore */ }
    built = true;
    showSection(sections[saved] ? saved : currentSection);
  }

  function syncAll() {
    for (const c of controls) {
      try {
        c.sync(current);
      } catch (err) {
        console.error('[settings sync]', err);
      }
    }
  }

  /** 主程序推來最新設定時呼叫 */
  function update(payload) {
    if (!payload || !payload.settings) return;
    current = payload.settings;
    if (payload.defaults) defaults = payload.defaults;
    if (payload.keymap) keymap = payload.keymap;
    if (payload.info) info = payload.info;
    if (!built && defaults) build();
    if (built) syncAll();
  }

  window.SolovSettingsUI = {
    init(options) {
      api = options.api;
      host = options;
      if (options.boot) update(options.boot);
    },
    update,
    /** 面板切到「設定」時 */
    show() { if (built) syncAll(); },
    /** 面板離開「設定」或關閉時 */
    hide() { stopRec(); },
    showSection,
    get section() { return currentSection; },
  };
}());

'use strict';

/**
 * 套用在「每一個網頁分頁」的 preload。
 *
 * 對一般網頁:不公開任何 API,只在使用者按下滑鼠 / 觸控時通知主程序:
 * 「我是被點到的那個分頁」,讓主程序把它設為使用中的分頁(網址列會跟著切換)。
 *
 * 對內建的新分頁頁面(renderer/newtab.html):另外公開 window.solovNewTab,
 * 讓它拿到使用者的新分頁設定(標題、快速連結、背景…)。主程序會再檢查一次發送者確實是新分頁頁面。
 */
const { contextBridge, ipcRenderer } = require('electron');

function poke(event) {
  if (event && event.isTrusted === false) return; // 忽略網頁腳本偽造的事件
  ipcRenderer.send('tab:interact');
}

window.addEventListener('mousedown', poke, true);
window.addEventListener('touchstart', poke, { capture: true, passive: true });

const isNewTabPage = location.protocol === 'file:' && /\/renderer\/newtab\.html$/i.test(location.pathname);
if (isNewTabPage) {
  // 頁面一開始畫就要用到主題色與背景,所以同步取一次;之後的修改由 newtab:update 推送
  let boot = null;
  try {
    boot = ipcRenderer.sendSync('newtab:boot');
  } catch (_) { /* ignore */ }
  if (boot) {
    contextBridge.exposeInMainWorld('solovNewTab', {
      boot,
      onUpdate: (cb) => {
        ipcRenderer.on('newtab:update', (_event, payload) => cb(payload));
      },
      openSettings: () => ipcRenderer.send('newtab:open-settings'),
    });
  }
}

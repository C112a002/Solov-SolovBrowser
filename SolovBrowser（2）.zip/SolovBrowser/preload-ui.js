'use strict';

/**
 * 瀏覽器介面(分頁列、工具列、側邊面板)用的 preload。
 * 只公開白名單內的操作,不把 ipcRenderer 整個交給頁面。
 * 介面端用 window.solov 呼叫;主程序會檢查每個訊息是不是真的來自這個介面視窗。
 */
const { contextBridge, ipcRenderer } = require('electron');

const send = (channel, ...args) => ipcRenderer.send(channel, ...args);
const invoke = (channel, ...args) => ipcRenderer.invoke(channel, ...args);
const listen = (channel, cb) => {
  ipcRenderer.on(channel, (_event, payload) => cb(payload));
};

// 頁面一開始畫就需要主題與尺寸(不然會先閃一下預設的顏色),所以在這裡同步跟主程序要一次
let boot = null;
try {
  boot = ipcRenderer.sendSync('ui:boot');
} catch (_) { /* 取不到就用預設外觀 */ }

contextBridge.exposeInMainWorld('solov', {
  boot,

  // 初始化與主程序推送
  ready: () => invoke('ui:ready'),
  onState: (cb) => listen('state', cb),
  onScripts: (cb) => listen('scripts', cb),
  onSettings: (cb) => listen('settings:changed', cb),
  onFocusAddress: (cb) => listen('focus-address', () => cb()),
  onNote: (cb) => listen('note', cb),

  // 分頁
  newTab: () => send('tab:new'),
  closeTab: (id) => send('tab:close', id),
  activateTab: (id, toggle) => send('tab:activate', id, !!toggle),
  toggleShown: (id) => send('tab:toggle-shown', id),
  tabMenu: (id) => send('tab:menu', id),
  muteTab: (id) => send('tab:mute', id),
  autoRefresh: (id, sec) => send('tab:auto-refresh', id, Number(sec) || 0),
  maximize: (id) => send('view:maximize', typeof id === 'number' ? id : null),

  // 導覽
  go: (text) => send('nav:go', String(text == null ? '' : text)),
  back: () => send('nav:back'),
  forward: () => send('nav:forward'),
  reload: () => send('nav:reload'),
  stop: () => send('nav:stop'),

  // 版面 / 面板 / 動作
  setLayout: (layout) => send('layout:set', layout),
  setPanel: (open, mode) => send('panel:set', !!open, mode),
  togglePanel: (mode) => send('panel:toggle', mode),
  action: (id) => send('action:run', String(id)),
  recordKeys: (on) => send('keys:record', !!on), // 錄製快速鍵時,通知主程序暫時不要攔截按鍵

  // 擴充功能(使用者腳本)
  scripts: {
    save: (script) => invoke('scripts:save', script),
    remove: (id) => send('scripts:remove', id),
    toggle: (id, enabled) => send('scripts:toggle', id, !!enabled),
    run: (id) => send('scripts:run', id),
    importFiles: () => send('scripts:import'),
    reloadShown: () => send('tabs:reload-shown'),
  },

  // 使用者設定
  settings: {
    get: () => invoke('settings:get'),
    update: (patch) => invoke('settings:update', patch),
    reset: (section) => invoke('settings:reset', section == null ? null : String(section)),
    exportFile: (withScripts) => invoke('settings:export', !!withScripts),
    importFile: () => invoke('settings:import'),
    clearData: (kinds) => invoke('settings:clear-data', Array.isArray(kinds) ? kinds.map(String) : []),
    pickImage: () => invoke('settings:pick-image'),
    openFolder: () => send('settings:open-folder'),
  },
});
